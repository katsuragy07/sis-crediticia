-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-12-2019 a las 23:47:40
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `rapidito`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aperturas`
--

CREATE TABLE IF NOT EXISTS `aperturas` (
  `idapertura` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_apertura` datetime DEFAULT NULL,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_apertura` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `monto_cierre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cajas_idcaja` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  `billetaje_hist_idbilletaje` int(11) DEFAULT NULL,
  PRIMARY KEY (`idapertura`),
  KEY `fk_aperturas_cajas1_idx` (`cajas_idcaja`),
  KEY `fk_aperturas_usuarios1_idx` (`usuarios_idusuario`),
  KEY `fk_aperturas_billetaje_hist1_idx` (`billetaje_hist_idbilletaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=48 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aprobaciones`
--

CREATE TABLE IF NOT EXISTS `aprobaciones` (
  `idaprobacion` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_reg` datetime NOT NULL,
  `fecha_mod` datetime DEFAULT NULL,
  `fecha_aprob` datetime DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`idaprobacion`),
  KEY `fk_aprobaciones_creditos1_idx` (`creditos_idcredito`),
  KEY `fk_aprobaciones_usuarios1_idx` (`usuarios_idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aval`
--

CREATE TABLE IF NOT EXISTS `aval` (
  `idconyugue` int(11) NOT NULL AUTO_INCREMENT,
  `apellido_pat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dni` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `sexo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `ocupacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dir_trabajo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `parentesco` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `habilitado` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL,
  PRIMARY KEY (`idconyugue`),
  KEY `fk_aval_clientes1_idx` (`clientes_idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billetaje`
--

CREATE TABLE IF NOT EXISTS `billetaje` (
  `idbilletaje` int(11) NOT NULL AUTO_INCREMENT,
  `cant_200` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_100` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_50` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_20` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_10` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_5` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_2` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_1` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_5` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_2` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_1` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idbilletaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billetaje_hist`
--

CREATE TABLE IF NOT EXISTS `billetaje_hist` (
  `idbilletaje` int(11) NOT NULL AUTO_INCREMENT,
  `cant_200` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_100` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_50` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_20` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_10` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_5` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_2` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_1` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_5` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_2` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_1` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idbilletaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cajas`
--

CREATE TABLE IF NOT EXISTS `cajas` (
  `idcaja` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `capital` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `billetaje_reg` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  `billetaje_idbilletaje` int(11) DEFAULT NULL,
  PRIMARY KEY (`idcaja`),
  KEY `fk_cajas_usuarios1_idx` (`usuarios_idusuario`),
  KEY `fk_cajas_billetaje1_idx` (`billetaje_idbilletaje`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `idcliente` int(11) NOT NULL AUTO_INCREMENT,
  `dni` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_pat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `hijos` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `grado_ins` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado_civ` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `lugar_nac` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `referencia` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo_viv` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `distrito` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `provincia` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tiempo_viv` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `comentario` text COLLATE utf8_spanish_ci,
  `url_foto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `url_domicilio` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `inscripcion` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `habilitado` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=131 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consumo`
--

CREATE TABLE IF NOT EXISTS `consumo` (
  `idconsumo` int(11) NOT NULL AUTO_INCREMENT,
  `dedicacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tiempo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `ingreso` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `lugar_trabajo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `profesion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL,
  PRIMARY KEY (`idconsumo`),
  KEY `fk_consumo_clientes1_idx` (`clientes_idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conyugue`
--

CREATE TABLE IF NOT EXISTS `conyugue` (
  `idconyugue` int(11) NOT NULL AUTO_INCREMENT,
  `apellido_pat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dni` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `sexo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `ocupacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dir_trabajo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `parentesco` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `habilitado` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL,
  PRIMARY KEY (`idconyugue`),
  KEY `fk_conyugue_clientes1_idx` (`clientes_idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `creditos`
--

CREATE TABLE IF NOT EXISTS `creditos` (
  `idcredito` int(11) NOT NULL AUTO_INCREMENT,
  `monto_prop` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `n_cuotas` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `n_cuotas_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `interes` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `interes_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `frecuencia` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `m_cuotas` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `m_cuotas_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `m_interes` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `m_interes_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `m_total` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `m_total_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_reg` datetime NOT NULL,
  `estado` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL,
  `conyugue_id` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `aval_id` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idcredito`),
  KEY `fk_creditos_clientes1_idx` (`clientes_idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=30 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuenta_pf`
--

CREATE TABLE IF NOT EXISTS `cuenta_pf` (
  `idcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `monto_inicio` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto_fin` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime NOT NULL,
  `fecha_retiro` datetime DEFAULT NULL,
  `interes` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  PRIMARY KEY (`idcuenta`),
  KEY `fk_cuenta_corriente_clientes1_idx` (`clientes_idcliente`),
  KEY `fk_cuenta_corriente_usuarios1_idx` (`usuarios_idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=31 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `desembolso`
--

CREATE TABLE IF NOT EXISTS `desembolso` (
  `iddesembolso` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_reg` datetime NOT NULL,
  `fecha_desem` datetime DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddesembolso`),
  KEY `fk_desembolso_creditos1_idx` (`creditos_idcredito`),
  KEY `fk_desembolso_usuarios1_idx` (`usuarios_idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos`
--

CREATE TABLE IF NOT EXISTS `movimientos` (
  `idmovimiento` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `concepto` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_mov` datetime NOT NULL,
  `autoriza` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo_comprobante` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nro_comprobante` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `detalle` text COLLATE utf8_spanish_ci,
  `cajas_idcaja` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  `creditos_idcredito` int(11) DEFAULT NULL,
  PRIMARY KEY (`idmovimiento`),
  KEY `fk_movimientos_cajas1_idx` (`cajas_idcaja`),
  KEY `fk_movimientos_usuarios1_idx` (`usuarios_idusuario`),
  KEY `fk_movimientos_creditos1_idx` (`creditos_idcredito`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=92 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `negocio`
--

CREATE TABLE IF NOT EXISTS `negocio` (
  `idnegocio` int(11) NOT NULL AUTO_INCREMENT,
  `norm_tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `norm_tipo_local` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `norm_tipo_negocio` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tiempo` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `trans_tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_placa` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_empresa` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_soat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_soat_cad` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `trans_tarjeta` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_tarjeta_cad` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `url_croquis` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `clientes_idcliente` int(11) NOT NULL,
  PRIMARY KEY (`idnegocio`),
  KEY `fk_negocio_clientes1_idx` (`clientes_idcliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE IF NOT EXISTS `pagos` (
  `idpago` int(11) NOT NULL AUTO_INCREMENT,
  `n_cuota_programada` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_programada` date NOT NULL,
  `cuota_programada` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `mora` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`idpago`),
  KEY `fk_pagos_creditos1_idx` (`creditos_idcredito`),
  KEY `fk_pagos_usuarios1_idx` (`usuarios_idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=178 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE IF NOT EXISTS `solicitudes` (
  `idsolicitud` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_reg` datetime NOT NULL,
  `fecha_mod` datetime DEFAULT NULL,
  `fecha_pre` datetime DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  PRIMARY KEY (`idsolicitud`),
  KEY `fk_solicitudes_creditos1_idx` (`creditos_idcredito`),
  KEY `fk_solicitudes_usuarios1_idx` (`usuarios_idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=30 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transferencias`
--

CREATE TABLE IF NOT EXISTS `transferencias` (
  `idtransferencia` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `concepto` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_mov` datetime NOT NULL,
  `autoriza` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `detalle` text COLLATE utf8_spanish_ci,
  `usuarios_idusuario` int(11) NOT NULL,
  `cajas_idcaja` int(11) NOT NULL,
  `cajas_idcaja1` int(11) NOT NULL,
  PRIMARY KEY (`idtransferencia`),
  KEY `fk_transferencias_usuarios1_idx` (`usuarios_idusuario`),
  KEY `fk_transferencias_cajas1_idx` (`cajas_idcaja`),
  KEY `fk_transferencias_cajas2_idx` (`cajas_idcaja1`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `privilegios` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_pat` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `doc_nro` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `pass` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` date DEFAULT NULL,
  `grado` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado_civil` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `lugar_nacimiento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `comentarios` text COLLATE utf8_spanish_ci,
  `telefono` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `referencia` varchar(55) COLLATE utf8_spanish_ci DEFAULT NULL,
  `distrito` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `provincia` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(55) COLLATE utf8_spanish_ci DEFAULT NULL,
  `url_foto` varchar(55) COLLATE utf8_spanish_ci DEFAULT NULL,
  `habilitado` varchar(5) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `voucher_pago`
--

CREATE TABLE IF NOT EXISTS `voucher_pago` (
  `idvoucher` int(11) NOT NULL AUTO_INCREMENT,
  `monto_pago` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_pago` datetime NOT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  PRIMARY KEY (`idvoucher`),
  KEY `fk_voucher_pago_creditos1_idx` (`creditos_idcredito`),
  KEY `fk_voucher_pago_usuarios1_idx` (`usuarios_idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=20 ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `aperturas`
--
ALTER TABLE `aperturas`
  ADD CONSTRAINT `fk_aperturas_billetaje_hist1` FOREIGN KEY (`billetaje_hist_idbilletaje`) REFERENCES `billetaje_hist` (`idbilletaje`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_aperturas_cajas1` FOREIGN KEY (`cajas_idcaja`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_aperturas_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `aprobaciones`
--
ALTER TABLE `aprobaciones`
  ADD CONSTRAINT `fk_aprobaciones_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_aprobaciones_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `aval`
--
ALTER TABLE `aval`
  ADD CONSTRAINT `fk_aval_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cajas`
--
ALTER TABLE `cajas`
  ADD CONSTRAINT `fk_cajas_billetaje1` FOREIGN KEY (`billetaje_idbilletaje`) REFERENCES `billetaje` (`idbilletaje`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cajas_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `consumo`
--
ALTER TABLE `consumo`
  ADD CONSTRAINT `fk_consumo_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `conyugue`
--
ALTER TABLE `conyugue`
  ADD CONSTRAINT `fk_conyugue_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `creditos`
--
ALTER TABLE `creditos`
  ADD CONSTRAINT `fk_creditos_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cuenta_pf`
--
ALTER TABLE `cuenta_pf`
  ADD CONSTRAINT `fk_cuenta_corriente_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cuenta_corriente_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `desembolso`
--
ALTER TABLE `desembolso`
  ADD CONSTRAINT `fk_desembolso_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_desembolso_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `movimientos`
--
ALTER TABLE `movimientos`
  ADD CONSTRAINT `fk_movimientos_cajas1` FOREIGN KEY (`cajas_idcaja`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_movimientos_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_movimientos_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `negocio`
--
ALTER TABLE `negocio`
  ADD CONSTRAINT `fk_negocio_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `fk_pagos_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pagos_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD CONSTRAINT `fk_solicitudes_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_solicitudes_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `transferencias`
--
ALTER TABLE `transferencias`
  ADD CONSTRAINT `fk_transferencias_cajas1` FOREIGN KEY (`cajas_idcaja`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_transferencias_cajas2` FOREIGN KEY (`cajas_idcaja1`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_transferencias_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `voucher_pago`
--
ALTER TABLE `voucher_pago`
  ADD CONSTRAINT `fk_voucher_pago_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_voucher_pago_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
