-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 10.1.2.125:3306
-- Tiempo de generación: 19-12-2019 a las 15:48:37
-- Versión del servidor: 10.2.24-MariaDB
-- Versión de PHP: 7.2.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `u266553358_rapidito`
--

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idcliente`, `dni`, `apellido_pat`, `apellido_mat`, `nombre`, `nacimiento`, `hijos`, `grado_ins`, `estado_civ`, `lugar_nac`, `direccion`, `referencia`, `tipo_viv`, `distrito`, `provincia`, `tiempo_viv`, `comentario`, `url_foto`, `url_domicilio`, `inscripcion`, `telefono`, `habilitado`) VALUES
(4, '19890483', 'MEZA ', 'HUALPARUCA', 'SILVERIO', '1955-06-20', '0', 'SECUNDARIA', 'CASADO', 'HUANCAYO', 'MARISCAL CASTILLA N° 1994', '', 'PROPIA', 'CHILCA', 'HUANCAYO', '10 AÑOS', '', '', '', 'SI', '00000', 'SI'),
(5, '44393845', 'MUÑOZ', 'CASAS ', 'ROGELIO', '1987-04-29', '0', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'AV. HUANCAVELICA N°638', '', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '2', '', '', NULL, 'SI', '989890000', 'SI'),
(6, '47726338', 'PERALTA ', 'RIVEROS', 'ANDY', '1988-08-21', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR. AREQUIPA N° 473', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967656142', 'SI'),
(7, '20081139', 'RAMOS', 'JOAQUIN ', 'ROLANDO', '', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR. ALEJANDRO O. DEUSTUA N° 399', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964635110', 'SI'),
(8, '41722469', 'CHAVEZ ', 'VERASTEGUI', 'WILSON TORIBIO', '1962-12-12', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'PSJ. LAS LOMAS N°499', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(9, '41245294', 'ESPINOZA', 'ORREGO ', 'RONALD ANTHONY', '', '', 'TECNICA', 'SOLTERO', 'HUANCAYO', 'AV. PALIAN N° 840', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(10, '20115680', 'LOARDO', 'NUÑEZ', 'ORLANDO ALEX', '1978-02-15', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'JR. AREQUIPA N° 499', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999993593', 'SI'),
(11, '20115680', 'MACHUCA', 'BORJA', 'FELIX SOLANO', '1987-07-22', '', '', '', '', 'JR. PROGRESO S/N', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(12, '40625365', 'ARAUJO', 'SANTOS', 'CARLOS VICENTE', '', '', '', '', '', 'JR. ALEJANDRO O. DEUSTUA N° 943', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '975233122', 'SI'),
(13, '44279299', 'CHAVEZ', 'JACOBE', 'JOSE LUIS', '', '', '', '', '', 'JR. AREQUIPA N° 499', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924039022', 'SI'),
(14, '23265947', 'RAMOS ', 'ENRIQUE', 'PROSPERO', '', '', '', '', '', 'AV. HUANCAVELICA N°685', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(15, '41684212', 'ROJAS ', 'GAMBOA DE NOGALES', 'GLADYS MARISOL', '', '', '', '', '', 'MANCHEGO MUÑOZ N° 352', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '921377102', 'SI'),
(16, '41219351', 'YARANGA', 'QUISPE', 'LEANDRO', '', '', '', '', '', 'JR HUANCAS N° 1281', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964408872', 'SI'),
(17, '80083301', 'ARROYO ', 'HUAYNATE', 'ROSSY HAYDEE', '', '', '', '', '', 'PSJ LAS ISLAS N° 516 AA. HH.', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '920510025', 'SI'),
(18, '20550103', 'ROMERO', 'HURTADO ', 'INOCENCIA YOLANDA', '', '', '', '', '', 'CALLE CIRCUITO LOS HÉROES N° 202', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '925430862', 'SI'),
(19, '20093764', 'CAMPOS ', 'LOPEZ ', 'ROSARIO ISABEL', '', '', '', '', '', 'AV. CENTENARIO', '', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '987564466', 'SI'),
(20, '20048513', 'CAMAVILCA', 'CHAVEZ', 'JUDITH SARITA', '', '', '', '', '', 'CALLE 3 MZ C LT 16 - VILLA PERIODISTA', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '997959136', 'SI'),
(21, '43810115', 'MAITA', 'RAFAEL', 'JANED AQUILINA', '', '', '', '', '', 'JR. HUANCAS N° 1394', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '914838485', 'SI'),
(22, '47645796', 'CCENTE', 'GOMEZ', 'LIZ', '', '', '', '', '', 'JR. AREQUIPA N° 473', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967656142', 'SI'),
(23, '44639440', 'CAHUANA', 'OCHOA', 'JOSEP ANDRES', '', '', '', '', '', 'JR. LIBERTAD N° 605', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '942139239', 'SI'),
(24, '19820682', 'DE LA PEÑA', 'MARILU', 'MERCEDES', '', '', '', '', '', 'AV. CATALINA HUANCA N° 371', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '989252301', 'SI'),
(25, '19920893', 'BUENDIA ', 'YALLI', 'EPIFANIA', '', '', '', '', '', 'JR. LOS HUANCAS N°496', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '928751106', 'SI'),
(26, '44439463', 'MONTES', 'BALTAZAR ', 'JESENIA JULIZA', '', '', '', '', '', 'JR. JOSE OLAYA N° 177', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '960756995', 'SI'),
(27, '19803612', 'TORRES ', 'AVILA', 'CARLOS HUMBERTO', '', '', '', '', '', 'JR AGUIRRE MORALES N° 1188', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '949573976', 'SI'),
(28, '04011304', 'LOPE', 'MEDRANO', 'SILVIA DORIS', '', '', '', '', '', 'PSJ. CHUCUITO MZ5 LT 0 ', '', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '953671127', 'SI'),
(29, '44628543', 'RIOS ', 'ROJAS', 'KARINA', '', '', '', '', '', 'JR. DIAMANTE AZUL N° 153', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '921184887', 'SI'),
(30, '20006336', 'CALLUPE ', 'OJEDA', 'RUTH ELIANA', '', '', '', '', '', 'JR. LIBERTAD N°535', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999720255', 'SI'),
(31, '47367578', 'ROMERO', 'HERRERA', 'PILAR', '', '', '', '', '', 'JR. HIDRA MZ E LOTE 6', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '956439973', 'SI'),
(32, '19928508', 'SALVATIERRA ', 'VELIZ', 'GILDA ELIANA', '', '', '', '', '', 'JR. AREQUIPA N° 731', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964754900', 'SI'),
(33, '43480244', 'HUAROC ', 'POCOMUCHA ', 'KRISBET', '', '', '', '', '', 'JR. SANTOS CHOCANO N° 951', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '989815297', 'SI'),
(34, '47860194', 'REYMUNDO', 'CARRERA', 'CLARA', '', '', '', '', '', 'PSJ. HUGO CHAVEZ MZ O LT 22', '', '', 'PALIAN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964596957', 'SI'),
(35, '46497378', 'MARQUEZ', 'NESTARES ', 'JESSICA YANINA', '', '', '', '', '', 'JR. SEBASTIAN LORENTE N° 558', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964400100', 'SI'),
(36, '77662005', 'MARQUINA', 'DE ARMERO', 'RODRIGO ORLANDO', '', '', '', '', '', 'PSJ. GULLIVAN N° 102', '', '', 'PALIAN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '988572561', 'SI'),
(37, '20075856', 'ALCOCER', 'BARRIENTOS', 'MIRIAM', '', '', '', '', '', 'JR. NECOCHEA MZ B LT 4 - LA PRADERA', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '968920148', 'SI'),
(38, '42493451', 'CABELLO', 'GARCIA', 'LUIS FERNANDO', '', '', '', '', '', 'AV. FERROCARRIL N° 475', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '981811161', 'SI'),
(39, '19927787', 'POMA', 'CANCHUMANI', 'ESTEBAN VICTOR', '', '', '', '', '', 'AV. 12 DE OCTUBRE N° 402', '', '', 'CULLPA ALTA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '926993108', 'SI'),
(40, '06179596', 'FERNANDEZ', 'SAMANIEGO', ' MARUJA CECILIA', '', '', '', '', '', 'JR. AREQUIPA N° 658 ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '985431389', 'SI'),
(41, '44462205', 'RIOS', 'ORTIZ', 'CESAR AUGUSTO', '', '', '', '', '', 'JR. 13 DE NOVIEMBRE N° 1125', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '954600050', 'SI'),
(42, '10256859', 'ARIAS', 'TORRES', 'JOSE', '', '', '', '', '', 'JR. COLINA N° 689', '', '', 'JAUJA', 'JAUJA', '', '', NULL, NULL, 'SI', '943965936', 'SI'),
(43, '19923319', 'BAUTISTA', 'QUISPEALAYA', 'ADELAIDA CASIMIRA', '', '', '', '', '', 'JR. 1 DE MAYO ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '969244508', 'SI'),
(44, '19909471', 'SALDAÑA', 'RAMIREZ', 'JOSE LUIS', '', '', '', '', '', 'CALLE LAS QUEBRADAS N° 140', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '994775704', 'SI'),
(45, '20012238', 'TORRES', 'MARAVI', 'RODOLFO VICTOR', '', '', '', '', '', 'JR. PARRA DE RIEGO N°540', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924043748', 'SI'),
(46, '19931799', 'CARDENAS ', 'DE SORIANO ', 'SOLEDAD JULIA', '', '', '', '', '', 'PSJ. ELIAS AGUIRRE N° 220', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '949305855', 'SI'),
(47, '21249666', 'TANTAVILCA', 'MARTINEZ', 'MARIA CECILIA', '', '', '', '', '', 'JR. AREQUIPA N° 658', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '998974503', 'SI'),
(48, '42645968', 'MOLINA', 'SANCHOMA', 'ITALO RAUL', '', '', '', '', '', 'PSJ. SAN ANTONIO N° 181', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967309797', 'SI'),
(49, '19838386', 'ZARABIA', 'CONDORI', 'LEONOR', '', '', '', '', '', 'PSJ. BRASIL N° 521', '', '', 'SAÑOS CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '937169980', 'SI'),
(50, '42735885', 'VELASQUEZ ', 'CAMPODONICO', 'JUANA JACKELINE', '', '', '', '', '', 'JR. JOSE OLAYA N° 925', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '946826537', 'SI'),
(51, '19991160', 'HUAMAN', 'GARAY', 'MARIO', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 1043', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '914023283', 'SI'),
(52, '72478132', 'HUAMAN', 'VARGAS ', 'JHAMMEL ORLANDO', '', '', '', '', '', 'CALLE SANTA ROSA MZ Y LT 10 ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '953574039', 'SI'),
(53, '19861956', 'ÑAÑEZ', 'CARO', 'JUAN ANTONIO', '', '', '', '', '', 'CALLE LAS QUEBRADAS N° 140', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964998654', 'SI'),
(54, '80017198', 'POMA ', 'DE LA CRUZ ', 'HERMAN', '', '', '', '', '', 'AV. 12 DE OCTUBRE N° 402', '', '', 'CULLPA ALTA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '926993108', 'SI'),
(55, '19990234', 'GORA', 'RIVERA', 'LIDA MARITZA', '', '', '', '', '', 'CALLE LAS ORQUIDEAS MZ B-2 LT 16', '', '', 'HUAMANCACA CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '948698054', 'SI'),
(56, '19914795', 'PARRA', 'RIVERA', 'LUIS ENRIQUE ', '', '', '', '', '', 'JR. BLANDA N° 125 - MILLOTINGO', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '916730788', 'SI'),
(57, '23522393', 'PERALTA', 'CANALES', 'AGUSTIN', '', '', '', '', '', 'AV. LEONCIO PRADO N° 1179', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '064214127', 'SI'),
(58, '47923529', 'COLONIO', 'NUÑEZ', 'JHONY PAUL', '', '', '', '', '', 'JR. PANAMA N° 1048', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922312579', 'SI'),
(59, '19818737', 'MARQUEZ', 'RODRIGUEZ', 'LUIS CARLOS', '', '', '', '', '', 'PSJ. SAN CARLOS N° 474', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '935070432', 'SI'),
(60, '46155602', 'CAMPO', 'CESPEDES', 'RAQUEL ESTELA', '', '', '', '', '', 'PSJ. COCHARCAS N° 12', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '923739175', 'SI'),
(61, '77130164', 'SANCHEZ', 'DE LA CRUZ ', 'CINTHYA CONSUELO', '', '', '', '', '', 'JR. PARRA DE RIEGO N°581', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(62, '40792615', 'SANTOS', 'CRISTOBAL', 'SULEMA', '', '', '', '', '', 'JR. AMATISTA N° 160 - CIUDAD UNIVERSITARIA', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '957900973', 'SI'),
(63, '44196870', 'POMAYLLE', 'RIVERA', 'LUZ ROXANA', '', '', '', '', '', 'JR. LOS SAUCES N° S/N', '', '', 'SAN AGUSTIN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964998654', 'SI'),
(64, '48120308', 'BAQUERIZO', 'CALLUPE', 'LUIS KEVIN', '', '', '', '', '', 'CALLE LIBERTAD N° 535', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '963958011', 'SI'),
(65, '20020660', 'CORILLOCLLA ', 'PROSOPIO ', 'EULALIA JULIA', '', '', '', '', '', 'PROLONGACIÓN LIMA N° 2275', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '979606043', 'SI'),
(66, '19963613', 'PAREDES', 'VARGAS', 'YENDER JOSE', '', '', '', '', '', 'AV. SAN MARTIN N° 936', '', '', 'SAN AGUSTIN DE CAJAS', 'HUANCAYO', '', '', NULL, NULL, 'SI', '939254928', 'SI'),
(67, '20099052', 'MEDINA', 'YANCE', 'EMILIANA', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 354', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '921018107', 'SI'),
(68, '48434295', 'LAUREL', 'CASTRO', 'JOSE COOPER', '', '', '', '', '', 'JR. HUANCAS N° 1521', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934409741', 'SI'),
(69, '41675575', 'ACUÑA ', 'SOTO', 'JESSICA KARINA', '', '', '', '', '', 'JR. HUASCAR S/N ', '', '', 'HUAMANCACA CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '9473351211', 'SI'),
(70, '19986232', 'REYNOSO', 'LARA', 'ANSELMO', '', '', '', '', '', 'JR. JOSE OLAYA N° 173', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '925810884', 'SI'),
(71, '20021621', 'PALOMINO', 'SANTIAGO', 'AMELIA', '', '', '', '', '', 'AV. CENTENARIO N° 557', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '998050770', 'SI'),
(72, '62460985', 'RIOS', 'TAMARA', 'WENDY', '', '', '', '', '', 'PSJ. LOS JASMINES N° 352 SEC. 19', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '976513567', 'SI'),
(73, '20064407', 'HIDALGO', 'SEGURA', 'RONALD ALFREDO', '', '', '', '', '', 'JR. TACNA N° 630', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(74, '48192121', 'PALACIOS', 'GONZALES', 'ANGEL GABRIEL', '', '', '', '', '', 'JR. LIMA N° 681 SECTOR 17', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '957527635', 'SI'),
(75, '44411762', 'LAURA', 'CHANCAY', 'EDITH PILAR', '', '', '', '', '', 'AV. JULIO SUMAR N° 138', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '936567160', 'SI'),
(76, '41662049', 'ZAMUDIO', 'SANCHEZ', 'CARLOS ADMUNDO', '', '', '', '', '', 'JR. PATRIOTA N° 589', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '988664536', 'SI'),
(77, '71066313', 'YALICO', 'QUINTANA', 'KERLI YORDANA', '', '', '', '', '', 'AV. 26 DE JULIO N° 4156', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934142364', 'SI'),
(78, '20011679', 'HURTADO', 'DE PUCHOC', 'ALEJANDRA SABINA', '', '', '', '', '', 'JR. LOS ROBLES N° 2130', '', '', 'SAÑOS CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934142364', 'SI'),
(79, '45379197', 'QUINTANA', 'DE MARIN', 'ROSITA ELVIRA', '', '', '', '', '', 'AV. 26 DE JULIO N° 4156', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934142364', 'SI'),
(80, '20590400', 'MARIN', 'DE QUINTANILLA', 'SILVIA BERTHA', '', '', '', '', '', 'AV. 26 DE JULIO N° 4156', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(81, '19858994', 'HUAYHUA', 'DE LA CRUZ', 'RAUL LUIS', '', '', '', '', '', 'JR. OSWALDO BARRENTO N° 10', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967447282', 'SI'),
(82, '08146479', 'ROSALES', 'ROJAS', 'REYNALDA', '', '', '', '', '', 'JR. OSWALDO BARRENTO N° 1365', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '943701095', 'SI'),
(83, '47562825', 'MOLINA', 'BALVIN', 'ERLINDA', '', '', '', '', '', 'JR. OSWALDO BARRENTO N° 10', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922513231', 'SI'),
(84, '46347763', 'RAMOS', 'SANTOS', 'AMAYRA VANESSA', '', '', '', '', '', 'JR. LIMA N° 681 SECTOR 17', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924958669', 'SI'),
(85, '19931588', 'MANGO ', 'DE CONDOR', 'TEODORA', '', '', '', '', '', 'JR. JOSE OLAYA N° 458', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '978786097', 'SI'),
(86, '76234021', 'MARIN', 'ASTETE', 'JEAMPIERE FIDEL', '', '', '', '', '', 'AV. RAMON CASTILLA N° 797', '', '', 'CONCEPCION', 'CONCEPCION', '', '', NULL, NULL, 'SI', '916413228', 'SI'),
(87, '44418079', 'BARZOLA', 'BARRETO', 'JESUS RICARDO', '', '', '', '', '', 'JR. JORGE CHAVEZ BLOCK L SECTOR 19', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '986485322', 'SI'),
(88, '48216271', 'CARBAJAL', 'PALOMINO', 'GISSETT LEYDI', '', '', '', '', '', 'AV. HUANCAVELICA N° 740', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '949475807', 'SI'),
(89, '46711885', 'HUAYHUA', 'ESPINOZA', 'SILVER ALFONSO', '', '', '', '', '', 'AA. HH. JUAN PARRA DE RIEGO MZ E LT 5', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '969652957', 'SI'),
(90, '74141967', 'BARZOLA', 'LAURA', 'JASMIN GIOVANA', '', '', '', '', '', 'AV. JULIO SUMAR N° 138', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(91, '19821050', 'CARBAJAL', 'ARIAS', 'YONY HUGO', '', '', '', '', '', 'AV. INDEPENDENCIA N° 599', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '961871007', 'SI'),
(92, '44455902', 'VELASQUEZ ', 'CHUPAN', 'JOEL ANDRES', '', '', '', '', '', 'JR. PORVENIR N° 231', '', '', 'COCHAS CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '947324944', 'SI'),
(93, '45768004', 'OTAIRO', 'PARRAGA', 'ABEL RICHARD', '', '', '', '', '', 'CARRETERA CENTRAL N° 912', '', '', 'SAN AGUSTIN DE CAJAS', 'HUANCAYO', '', '', NULL, NULL, 'SI', '943054435', 'SI'),
(94, '71921087', 'TAPARA', 'LLACUA', 'JHORDY FRANCHESCOLI', '', '', '', '', '', 'JR. REAL Y ARTERIAL ', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '956958327', 'SI'),
(95, '44263315', 'CALCINA', 'LOPEZ', 'AURELHIO JHONATTAN', '', '', '', '', '', 'AV. HUANCAVELICA N° 740', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '944848290', 'SI'),
(96, '20088381', 'CALDERON', 'PINZAS', 'ANA PATRICIA', '', '', '', '', '', 'PSJ. ATLANTIS N°170 SECTOR 9', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '974290950', 'SI'),
(97, '40245040', 'SALDAÑA', 'TAPIA', 'RAQUEL CEFORA', '', '', '', '', '', 'JR. ALAN GARCIA N° 240 SECTOR 04', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '975890229', 'SI'),
(98, '46398806', 'GOMEZ', 'ZANABRIA', 'MARICRUZ MEDALI', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 1330 SECTOR 4', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(99, '41712234', 'SALAZAR ', 'GARAY', 'SILVIA LUZ', '', '', '', '', '', 'JR. HUAMACHUCO N° 770', '', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '935552415', 'SI'),
(100, '19916611', 'LINDO', 'GALVAN', 'RUBEN WALTER', '', '', '', '', '', 'JR. 8 DE DICIEMBRE ', 'ANEXO HUAYAO', '', 'CHUPACA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999265226', 'SI'),
(101, '75970781', 'MESTANZA', 'VILCAPOMA', 'ROSARIO', '', '', '', '', '', 'AV. ALFHA N° 266', 'COOPERATIVA SANTA ISABEL', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '927225914', 'SI'),
(102, '20046609', 'ALEJO', 'TAYPE', 'ELIZABET LEONOR', '', '', '', '', '', 'JR. ALISOS N° 345', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '917806799', 'SI'),
(103, '47744555', 'FIOL', 'RIVAS', 'ABELARDO', '', '', '', '', '', 'JR. PARRA DE RIEGO N° 628', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '942873573', 'SI'),
(104, '19914814', 'COSME', 'RICSE', 'MARCELINO ANTONIO', '', '', '', '', '', 'PSJ. COSME N° 102', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '947441488', 'SI'),
(105, '40010258', 'TARDIO', 'LOAYZA ', 'LUZMILA', '', '', '', '', '', 'PROLONGACIÓN PIURA N° 1331', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '978919381', 'SI'),
(106, '75191385', 'CALLO', 'ROJAS', 'ALICIA PILAR', '', '', '', '', '', 'JR. NEMESIO RAEZ N° 1050', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '923704147', 'SI'),
(107, '73047185', 'DAVID', 'CIERTO', 'LYAN KATHERINE', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 244', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '935938391', 'SI'),
(108, '43017035', 'CONDOR', 'MADRID', 'FLOR DE MARIA', '', '', '', '', '', 'JR. JULIAN HUANAY N° 122', 'SECTOR 10', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '953933375', 'SI'),
(109, '73112442', 'MEDRANO', 'CORILLOCLLA', 'LESLY NAHOMI', '', '', '', '', '', 'PSJ. VISTA ALEGRE N° 131', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(110, '48134522', 'CHUQUILLANQUI ', 'SOTO', 'YEFERSON PAOLO', '', '', '', '', '', 'AV. PASEO LA BREÑA N° 519', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924130314', 'SI'),
(111, '20102982', 'SOLANO', 'VELARDE', 'NANCY VILMA', '', '', '', '', '', 'JR. LA UNION N° 289', 'VILCACOTO', '', 'PALIAN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '989799256', 'SI'),
(112, '46893928', 'HUAMANI', 'MOLINA', 'GUSTAVO ALEJANDRO', '', '', '', '', '', 'JR. JULIO LLANOS N° 364', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '929458781', 'SI'),
(113, '44297541', 'CHUCO', 'AGUIRRE', 'JOSE LUIS', '', '', '', '', '', 'CALLE CHAVIN N° 308', '3 ESQUINAS', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '938433474', 'SI'),
(114, '46831932', 'MANRIQUE', 'ORTIZ ', 'POOL VLADIMIR', '1994-11-08', '', '', '', '', 'JR. PARRA DE RIEGO N°581', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '976130738', 'SI'),
(115, '80002859', 'POMAHUALOI', 'VILCHEZ', 'MILO MILLER', '', '', '', '', '', 'AV. RAMON CASTILLA N° 152', 'ANEXO PACCHA', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(116, '43449337', 'CHUCO', 'AGUIRRE', 'MIGUEL ANGEL', '', '', '', '', '', 'CALLE CHAVIN N° 308', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '978280828', 'SI'),
(117, '20019795', 'VARGAS', 'DE LA CRUZ ', 'VLADIMIR LUIS', '', '', '', '', '', 'JR. JULIO C. TELLO N° 1022', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '917947567', 'SI'),
(118, '19847160', 'TINEO', 'VELITA', 'ANTONIO', '', '', '', '', '', 'JR. PARRA DE RIEGO N°581', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '936466421', 'SI'),
(119, '19943634', 'COCHACHI', 'SOLANO', 'ESTEBAN GERARDO', '', '', '', '', '', 'PSJ. ROJAS N° 182', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '984330704', 'SI'),
(120, '47576938', 'GONZALES ', 'PRADO ', 'ROSA', '', '', '', '', '', 'PSJ. LOS ANGELES N° 284', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '936034640', 'SI'),
(121, '74234731', 'DE LA CRUZ', 'CANTARO', 'JESSI', '', '', '', '', '', 'JR. LA HERRADURA ', 'PSJ. LOS NOGALES ', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922976656', 'SI'),
(122, '47726338', 'JULCA', 'CENIZARIO', 'CINTHYA', '', '', '', '', '', 'AV. PROGRESO N° 826', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(123, '20011425', 'NAULA', 'LLANCO', 'GISELA', '', '', '', '', '', 'PSJ. EL SOL N° S/N ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '969444504', 'SI'),
(124, '42673599', 'GOMEZ ', 'SEDANO', 'JUAN CARLOS', '', '', '', '', '', 'PSJ. SANTA ROSA N° S/N', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(125, '40272188', 'TERREL', 'ROSALES', 'ISAIAS SEBASTIAN', '', '', '', '', '', 'PSJ. LAS TURQUESAS N° 100', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '983989756', 'SI'),
(126, '19917677', 'HUAMANI', 'QUISPE', 'PEDRO JACINTO', '', '', '', '', '', 'JR. YAUYOS N° 259', 'PARQUE INDUSTRIAL - AV. HUANCAVELICA', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '983640511', 'SI'),
(127, '75047268', 'TERREROS ', 'CHAVEZ', 'ALVARO OMAR', '', '', '', '', '', 'CALLE REAL N° 378', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922181903', 'SI'),
(128, '43760865', 'NINALAYA ', 'CHUQUILLANQUI', 'RICHARD', '', '', '', '', '', 'PSJ. LAS MONTAÑAS N° 143', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '939340139', 'SI'),
(129, '29400964', 'MORENO', 'GIRONDO', 'ROSA MARINA', '', '', '', '', '', 'JR. B. LEGUIA N°360 ', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(130, '74627137', 'CAMASCA', 'HUAROC', 'CLAUDIA LISSETH', '', '', '', '', '', 'JR. ALEJANDRO O. DEUSTUA N° 411', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '977662803', 'SI'),
(131, '70771878', 'SANDOVAL', 'WONG', 'GILMER JOEL', '1996-07-14', '', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'JR. RICARDO MENENDEZ S/N', 'PSJ. C-5', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '3', 'COBRADOR', NULL, NULL, 'SI', '921129432', 'SI'),
(132, '15427062', 'SACAYCO ', 'MELO', 'JULIO CESAR', '1971-12-18', '', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', 'CALLE LA AMISTAD N°329', 'JUSTICIA PAZ Y VIDA', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '48', '', NULL, NULL, 'SI', '917471435', 'SI'),
(133, '44398011', 'FLORES ', 'TINCOPA', 'WILLIAM', '1987-02-19', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'JR.JOSE MARIA ARGUEDAS MZJLT . 3', 'JUSTICIA PAZ Y VIDA', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '31 AÑOS ', 'TRANSPORTISTA', NULL, NULL, 'SI', '961313801', 'SI'),
(134, '46447422', 'GOMEZ', 'MORENO ', 'CHRISTOPHER', '1990-04-13', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR. CHICLAYO N343', '', 'FAMILIAR', 'TAMBO ', 'HUANCAYO ', '29', '', NULL, NULL, 'SI', '926986052', 'SI'),
(135, '40489116', 'VIDALON ', 'EIZAGUIRRE', 'GINO JORGE ERNESTO', '1978-09-17', '1', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR.AREQUIPA 746', 'COLEGIO DE CARTON ', 'FAMILIAR', 'CHILCA ', 'HUANCAYO', '20 AÑOS ', '', NULL, NULL, 'SI', '945806000', 'SI'),
(136, '80005737', 'ALVAREZ', 'HILARIO', 'DAVID ALI', '1976-04-02', '0', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'AH. NTA SRA DE COCHARCAS BLOCK M MZ 6', 'PIO PATA', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '40 AÑOS', '', NULL, '5ddfe0dac125d.jpeg', 'NO', '943965706', 'SI'),
(137, '29400964', 'MORENO', 'GIRONDA', 'ROSA', '1965-11-12', '2', 'UNIVERSITARIA', 'CASADO', 'AREQUIPA', 'JR.AUGUSTO B . LEGUIA 630', 'MERCADO CHILCA', 'FAMILIAR', 'CHICLA', 'HUANCAYO', '30AÑOS', '', NULL, NULL, 'SI', '976728077', 'SI'),
(138, '43771995', 'BREÑA', 'ESPEJO', 'MARGOTH YOVANA', '1986-09-23', '3', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'JR. INCA RIPAC N° 1625', 'ASENTAMIENTO JUAN PARRA ', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '30', '', NULL, '5de12f7fe3e93.jpeg', 'SI', '943941332', 'SI'),
(139, '41591874', 'LAZARO', 'FALCON ', 'MIGUEL HECTOR ', '1981-12-01', '', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'CA. LOS CLAVELES N. 151 AA.VV. BRISAS DEL TAM', 'PARADERO DE VIRGO ', 'FAMILIAR', 'TAMBO ', 'HUANCAYO', '5AÑOS', '', NULL, NULL, 'SI', '949479111', 'SI'),
(140, '20076463', 'ANGULO', 'CARDENAS', 'ERNESTO', '1974-02-22', '1', 'SUPERIOR', 'CASADO', 'HUANCAYO', 'PSJ SAENZ PEÑA 519', 'COLISEO WANKA', 'FAMILIAR', 'CHILCA', 'HUANCAYO', '20 AÑOS ', '', NULL, NULL, 'SI', '954138105', 'SI'),
(141, '19947288', 'palacios', 'alvarado', 'yony david ', '1966-03-26', '', 'SUPERIOR', 'SOLTERO', 'huancayo', 'chavez y real s/n', 'banco QAPQAP', 'PROPIA', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '947999036', 'SI'),
(142, '19836636', 'sandoval ', 'povis ', 'gilmer factor', '1958-12-27', '1', 'SUPERIOR', 'CONVIVIENTE', 'huancayo', 'ricardo mendez lote c. manzana 5', '', 'PROPIA', 'TAMBO ', 'HUANCAYO', '20 AÑOS ', '', NULL, NULL, 'SI', '927774396', 'SI'),
(143, '46198930', 'HOLGUIN', 'RIVAS', 'JOSE LUIS', '', '1', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'JR. PARRA DEL RIEGO N° 728', 'HUANCAVELICA', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '10', '', NULL, NULL, 'NO', '945899979', 'SI'),
(144, '46551735', 'CRUZ ', 'ZUÑIGA', 'ANGEL RIDER ', '1985-02-13', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'AV.JOSE MARIA ARGUEDAS 596', '', 'ALQUILADA', 'HUANCAYO', 'HUANCAYO', '15AÑOS', '', NULL, NULL, 'SI', '948634749', 'SI'),
(145, '71037256', 'RODRIGO ', 'YARANGA ', 'DEYSI ', '1992-07-27', '', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'CA.LOS CLAVELES N 151 BRISAS DEL MANTARO ', 'PARADERO DE VIRGO ', 'FAMILIAR', 'TAMBO ', 'HUANCAYO ', '26 AÑOS ', '', NULL, NULL, 'SI', '958045498', 'SI'),
(146, '44320818', 'LEYVA', 'CARDENAS ', 'CRISTIAN JESUS', '1984-01-24', '1', 'SUPERIOR', 'DIVORCIADO', 'HUANCAYO', 'AV. MAXIMO GORKI 525', 'JUSTICIA PAZ Y VIDA', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '10 AÑOS ', '', NULL, NULL, 'SI', '931085563', 'SI'),
(147, '20029620', 'HUAMANI ', 'SAIRE', 'JUSTO ROMAN', '1961-09-09', '1', 'DOCTORADO', 'CASADO', 'HUANCAYO', 'AV. LA MEJORADA ', '', 'PROPIA', 'EL TAMBO', 'HUANCAYO', '20', '', NULL, NULL, 'NO', '967656142', 'SI'),
(148, '46497378', 'MARQUEZ', 'NESTARES', 'JESSICA YANINA', '', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO ', 'JR.SEBASTIAN LORENTE 558', 'MERCADO DEL TAMBO ', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '10AÑOS', '', NULL, NULL, 'SI', '964400100', 'SI'),
(149, '74149327', 'ORIHUELA ', 'HUAYNALAYA', 'TOPSY GABY', '1993-05-26', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR.ANTONIO LOBATO 951', '', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999332398', 'SI'),
(150, '42036675', 'LAZARO', 'FALCON', 'BENITA CONSUELO', '1983-07-10', '', '', 'DIVORCIADO', 'HUANCAYO', 'AV. 1 DE MAYO 851', 'JUSTICIA PAZ Y VIDA', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '928311573', 'SI'),
(151, '952812847', 'CORAHUA', 'RASHUAMAN', 'EVER ROMAN', '1986-01-01', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'jr.bruno terreros 1509', 'PARADERO DE VIRGO ', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '952812847', 'SI'),
(152, '20644224', 'VELAZCO', 'BRAVO', 'ALEJANDRO ULISES', '1958-12-05', '0', 'SUPERIOR', 'SOLTERO', 'JAUJA', 'AV. HEROES DE LA BREÑA', 'JAUJA', 'FAMILIAR', 'JAUJA', 'JAUJA', '10', '', NULL, NULL, 'NO', '954034976', 'SI'),
(153, '29400964', 'MORENO', 'GIRONDA', 'ROSA MARINA', '1965-11-12', '2', 'SUPERIOR', 'CASADO', 'AREQUIPA', 'AV.AUGUSTO B.LEGUIA 630 CHILCA', 'MERCADO CHILCA', 'PROPIA', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '976728077', 'SI');

--
-- Volcado de datos para la tabla `conyugue`
--

INSERT INTO `conyugue` (`idconyugue`, `apellido_pat`, `apellido_mat`, `nombre`, `dni`, `sexo`, `nacimiento`, `direccion`, `ocupacion`, `dir_trabajo`, `parentesco`, `tipo`, `habilitado`, `clientes_idcliente`) VALUES
(1, 'SALAZAR', 'ROJAS', 'GEORGE JAME', '70231170', 'M', '1993-09-13', 'JR. RICARDO MENENDEZ', 'CONDUCTOR', 'RUTA VIRGO', 'CONOCIDO', 'CONYUGUE', 'SI', 131),
(3, 'LAZARO ', 'FALCON ', 'BENITA CONSUELO', '42036675', 'F', '1982-07-10', 'AV. 1 DE MAYO N° 851 AA HH 44', 'COMERCIANTE', 'JUSTICIA PAZ Y VIDA - CANCHON', 'ESPOSO', 'CONYUGUE', 'SI', 146);

--
-- Volcado de datos para la tabla `negocio`
--

INSERT INTO `negocio` (`idnegocio`, `norm_tipo`, `norm_tipo_local`, `norm_tipo_negocio`, `tiempo`, `trans_tipo`, `trans_placa`, `trans_empresa`, `trans_direccion`, `trans_soat`, `trans_soat_cad`, `trans_tarjeta`, `trans_tarjeta_cad`, `tipo`, `url_croquis`, `clientes_idcliente`) VALUES
(1, '', '', '', '10 AÑOS ', 'FORMAL', '44398011', 'VIRGO SAC', 'JUSTICIA PAZ Y VIDA - CANCHON ', 'SI', '', 'SI', '', 'TRANSPORTE', NULL, 133);

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `privilegios`, `apellido_pat`, `apellido_mat`, `nombre`, `doc_nro`, `usuario`, `pass`, `nacimiento`, `grado`, `estado_civil`, `lugar_nacimiento`, `comentarios`, `telefono`, `direccion`, `referencia`, `distrito`, `provincia`, `correo`, `url_foto`, `habilitado`) VALUES
(1, 'ROOT', 'LOARDO', 'NUÑEZ', 'ORLANDO', '20115680', 'root', 'admin', '2019-11-02', 'UNIVERSITARIA', 'SOLTERO', 'OTROS', '-', '-', '-', '-', '-', '-', 'root@gmail.com', NULL, 'SI'),
(2, 'ADMINISTRADOR', 'ESTRADA', 'ROJAS', 'JACKELINE IVONNE', '73222381', 'JESTRADA@ADMINISTRADOR', '73222381JIAER*', '1994-05-15', 'BACHILLER', 'SOLTERO', 'TARMA', '', '923321711', 'AV. RAMON CASTILLA N°306', '', 'CONCEPCION', 'CONCEPCION', 'admin@gmail.com', NULL, 'SI'),
(3, 'CAJA', 'GRANDOS', 'FERNANDEZ', 'LUIS ALFREDO', '74892786', 'LGRANADOS@CAJA', '74892786', '1997-07-19', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', '', '986570509', 'JR. YAUYOS N° 259', '', 'EL TAMBO', 'HUANCAYO', 'CAJA@gmail.com', NULL, 'SI'),
(4, 'ASESOR', 'HINOSTROZA', 'RODRIGUEZ', 'ELIANA LIZ', '47174763', 'EHINOSTROZA@ASESOR', '47174763', '1992-01-12', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', '', '933341599', 'AV. MARISCAL CASTILLA N° 1051', '', 'EL TAMBO', 'HUANCAYO', 'ASESOR@gmail.com', NULL, 'SI'),
(6, 'ASESOR', 'GOMEZ', 'MORENO', 'KEVIN STEVE', '77269413', 'KGOMEZ@ASESOR', '77269413', '1995-12-02', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', '', '914894331', 'JR. B LEGUIA N° 630', '', 'CHILCA', 'HUANCAYO', 'ASESOR@gmail.com', NULL, 'SI'),
(7, 'CAJA', 'ESTRADA', 'ROJAS', 'JACKELINE IVONNE', '73222381', 'JESTRADA@CAJA', '73222381JIAER*', '1994-05-15', 'BACHILLER', 'SOLTERO', 'HUANCAYO', '', '923321711', 'AV. RAMON CASTILLA N° 306', 'CONCEPCION', 'CONCEPCION', 'CONCEPCION', '', NULL, 'SI'),
(8, 'ASESOR', 'GRANADOS', 'FERNANDEZ', 'LUIS', '74892786', 'LGRANADOS@ASESOR', '74892786', '0000-00-00', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', '', '916570509', 'JR. PARRA DE RIEGO N°581', '', 'EL TAMBO', 'HUANCAYO', '', NULL, 'SI');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
