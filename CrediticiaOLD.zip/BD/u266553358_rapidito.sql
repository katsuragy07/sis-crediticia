-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 10.1.2.125:3306
-- Tiempo de generación: 19-12-2019 a las 15:47:35
-- Versión del servidor: 10.2.24-MariaDB
-- Versión de PHP: 7.2.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `u266553358_rapidito`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aperturas`
--

CREATE TABLE `aperturas` (
  `idapertura` int(11) NOT NULL,
  `fecha_apertura` datetime DEFAULT NULL,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_apertura` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `monto_cierre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cajas_idcaja` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `aperturas`
--

INSERT INTO `aperturas` (`idapertura`, `fecha_apertura`, `fecha_cierre`, `monto_apertura`, `monto_cierre`, `cajas_idcaja`, `usuarios_idusuario`) VALUES
(2, '2019-11-25 10:50:13', '2019-11-25 19:32:04', '1225.60', '225.6', 2, 7),
(3, '2019-11-25 16:20:37', '2019-11-25 19:32:07', '300', '0', 3, 7),
(4, '2019-11-25 19:13:40', '2019-11-25 19:32:09', '300', '0', 4, 7),
(5, '2019-11-26 15:32:11', '2019-11-26 19:06:28', '0000', '39.6', 5, 7),
(6, '2019-11-26 19:05:34', '2019-11-26 19:06:31', '900', '0', 6, 7),
(7, '2019-11-27 09:33:39', '2019-11-27 19:35:17', '39.6', '140', 5, 7),
(8, '2019-11-27 09:33:59', '2019-11-27 19:35:20', '0', '0', 6, 7),
(9, '2019-11-27 17:46:17', '2019-11-27 19:35:23', '1000', '500', 7, 7),
(10, '2019-11-28 15:02:54', '2019-11-30 09:19:15', '140', '195', 5, 7),
(11, '2019-11-28 17:48:06', '2019-11-30 09:19:18', '500', '100', 7, 7),
(12, '2019-11-30 09:41:11', '2019-12-04 16:22:48', '195', '526.6', 5, 7),
(13, '2019-12-04 17:29:14', NULL, '0000', NULL, 8, 3),
(22, '2019-12-06 14:58:51', '2019-12-06 15:05:54', '225.6', '0', 2, 7),
(23, '2019-12-06 14:58:57', '2019-12-06 15:05:59', '526.6', '0', 5, 7),
(24, '2019-12-09 09:48:50', NULL, '0', NULL, 5, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aprobaciones`
--

CREATE TABLE `aprobaciones` (
  `idaprobacion` int(11) NOT NULL,
  `fecha_reg` datetime NOT NULL,
  `fecha_mod` datetime DEFAULT NULL,
  `fecha_aprob` datetime DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `aprobaciones`
--

INSERT INTO `aprobaciones` (`idaprobacion`, `fecha_reg`, `fecha_mod`, `fecha_aprob`, `creditos_idcredito`, `usuarios_idusuario`) VALUES
(5, '2019-11-25 10:15:30', NULL, '2019-11-25 10:26:55', 6, 2),
(6, '2019-11-25 10:16:20', NULL, '2019-11-25 10:26:30', 7, 2),
(8, '2019-11-25 10:47:12', NULL, '2019-11-25 10:48:18', 8, 2),
(15, '2019-11-26 15:25:04', NULL, '2019-11-26 18:59:54', 39, 2),
(16, '2019-11-27 09:29:55', NULL, '2019-11-27 09:32:16', 36, 2),
(18, '2019-11-27 09:41:41', NULL, '2019-11-27 17:44:08', 35, 2),
(19, '2019-11-27 19:07:24', NULL, '2019-11-29 10:25:30', 40, 2),
(23, '2019-11-28 17:51:52', NULL, '2019-11-28 17:52:44', 44, 2),
(24, '2019-11-28 18:19:39', NULL, '2019-11-28 18:25:12', 45, 2),
(25, '2019-11-28 18:28:32', NULL, '2019-11-28 18:35:47', 46, 2),
(26, '2019-11-29 09:21:00', NULL, '2019-11-29 17:14:13', 47, 2),
(29, '2019-11-29 11:31:05', NULL, '2019-11-29 11:34:13', 50, 2),
(30, '2019-11-29 11:31:54', NULL, '2019-11-29 11:52:15', 51, 2),
(31, '2019-11-29 15:17:42', NULL, '2019-11-29 15:34:00', 52, 2),
(32, '2019-11-29 15:19:04', NULL, '2019-11-29 15:35:17', 53, 2),
(33, '2019-11-29 19:08:24', NULL, '2019-11-29 19:31:17', 54, 2),
(35, '2019-11-30 09:33:12', NULL, '2019-11-30 09:37:39', 43, 2),
(38, '2019-12-03 09:40:45', NULL, '2019-12-03 09:41:41', 57, 2),
(39, '2019-12-04 11:49:57', NULL, '2019-12-04 12:34:42', 58, 2),
(41, '2019-12-04 17:27:02', NULL, '2019-12-04 17:28:44', 55, 2),
(42, '2019-12-04 17:58:59', NULL, '2019-12-04 18:00:23', 61, 2),
(43, '2019-12-05 09:24:01', NULL, '2019-12-05 18:10:16', 62, 2),
(45, '2019-12-05 17:11:51', NULL, '2019-12-05 17:13:07', 64, 2),
(47, '2019-12-07 09:30:44', NULL, '2019-12-09 09:57:28', 66, 2),
(48, '2019-12-09 09:06:53', NULL, '2019-12-09 16:26:54', 65, 2),
(51, '2019-12-09 18:31:22', NULL, '2019-12-09 18:31:46', 60, 2),
(52, '2019-12-09 18:58:44', NULL, '2019-12-10 10:16:02', 69, 2),
(53, '2019-12-09 19:17:50', NULL, '2019-12-09 19:18:48', 70, 2),
(54, '2019-12-10 09:40:55', NULL, '2019-12-10 18:22:44', 71, 2),
(58, '2019-12-11 09:54:27', NULL, '2019-12-11 11:57:14', 76, 2),
(60, '2019-12-11 15:44:13', NULL, '2019-12-11 17:54:57', 78, 2),
(61, '2019-12-11 17:52:08', NULL, '2019-12-11 17:53:00', 73, 2),
(62, '2019-12-12 15:08:51', NULL, '2019-12-12 16:04:17', 79, 2),
(63, '2019-12-12 17:30:29', NULL, '2019-12-12 17:30:49', 77, 2),
(64, '2019-12-13 10:00:43', NULL, '2019-12-13 10:02:24', 81, 2),
(65, '2019-12-13 10:21:54', NULL, '2019-12-13 18:17:52', 82, 2),
(68, '2019-12-13 16:09:32', NULL, '2019-12-13 16:10:16', 85, 2),
(69, '2019-12-14 13:02:09', NULL, '2019-12-14 13:04:05', 84, 2),
(72, '2019-12-17 12:04:29', NULL, '2019-12-17 17:53:57', 88, 2),
(75, '2019-12-18 15:07:37', NULL, '2019-12-18 17:47:53', 89, 2),
(76, '2019-12-18 15:07:54', NULL, '2019-12-18 17:45:34', 90, 2),
(77, '2019-12-18 15:28:44', NULL, '2019-12-18 15:29:07', 92, 2),
(78, '2019-12-18 18:08:58', NULL, '2019-12-18 18:33:37', 93, 2),
(79, '2019-12-18 18:32:39', NULL, NULL, 94, NULL),
(80, '2019-12-19 09:59:38', NULL, '2019-12-19 10:06:32', 95, 2),
(81, '2019-12-19 10:16:24', NULL, '2019-12-19 10:16:44', 91, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aval`
--

CREATE TABLE `aval` (
  `idconyugue` int(11) NOT NULL,
  `apellido_pat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dni` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `sexo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `ocupacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dir_trabajo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `parentesco` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `habilitado` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billetaje`
--

CREATE TABLE `billetaje` (
  `idbilletaje` int(11) NOT NULL,
  `cant_200` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_100` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_50` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_20` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_10` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_5` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_2` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_1` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_5` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_2` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_0_1` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `billetaje`
--

INSERT INTO `billetaje` (`idbilletaje`, `cant_200`, `cant_100`, `cant_50`, `cant_20`, `cant_10`, `cant_5`, `cant_2`, `cant_1`, `cant_0_5`, `cant_0_2`, `cant_0_1`) VALUES
(6, '', '', '', '', '', '', '', '', '', '', ''),
(7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, '', '', '', '', '', '', '', '', '', '', ''),
(10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cajas`
--

CREATE TABLE `cajas` (
  `idcaja` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `capital` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  `billetaje_idbilletaje` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `cajas`
--

INSERT INTO `cajas` (`idcaja`, `nombre`, `capital`, `estado`, `fecha_creacion`, `usuarios_idusuario`, `billetaje_idbilletaje`) VALUES
(2, 'JACKELINE IVONNE ESTRADA ROJAS', '0', 'DESHABILITADO', '2019-11-25 10:48:57', 7, 6),
(3, 'JACKELINE IVONNE ESTRADA ROJAS', '0', 'DESHABILITADO', '2019-11-25 16:13:33', 7, 7),
(4, 'JACKELINE IVONNE ESTRADA ROJAS', '0', 'DESHABILITADO', '2019-11-25 16:43:06', 7, 8),
(5, 'Caja Principal', '2136.2', 'ABIERTO', '2019-11-26 15:31:16', 7, 9),
(6, 'JACKELINE IVONNE ESTRADA ROJAS ', '0', 'DESHABILITADO', '2019-11-26 19:04:38', 7, 10),
(7, 'JACKELINE IVONNE ESTRADA ROJAS ', '100', 'DESHABILITADO', '2019-11-27 17:44:47', 7, 11),
(8, 'Caja 2', '250', 'ABIERTO', '2019-11-28 18:24:23', 3, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `idcliente` int(11) NOT NULL,
  `dni` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_pat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `hijos` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `grado_ins` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado_civ` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `lugar_nac` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `referencia` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo_viv` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `distrito` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `provincia` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tiempo_viv` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `comentario` text COLLATE utf8_spanish_ci DEFAULT NULL,
  `url_foto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `url_domicilio` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `inscripcion` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `habilitado` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idcliente`, `dni`, `apellido_pat`, `apellido_mat`, `nombre`, `nacimiento`, `hijos`, `grado_ins`, `estado_civ`, `lugar_nac`, `direccion`, `referencia`, `tipo_viv`, `distrito`, `provincia`, `tiempo_viv`, `comentario`, `url_foto`, `url_domicilio`, `inscripcion`, `telefono`, `habilitado`) VALUES
(4, '19890483', 'MEZA ', 'HUALPARUCA', 'SILVERIO', '1955-06-20', '0', 'SECUNDARIA', 'CASADO', 'HUANCAYO', 'MARISCAL CASTILLA N° 1994', '', 'PROPIA', 'CHILCA', 'HUANCAYO', '10 AÑOS', '', '', '', 'SI', '00000', 'SI'),
(5, '44393845', 'MUÑOZ', 'CASAS ', 'ROGELIO', '1987-04-29', '0', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'AV. HUANCAVELICA N°638', '', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '2', '', '', NULL, 'SI', '989890000', 'SI'),
(6, '47726338', 'PERALTA ', 'RIVEROS', 'ANDY', '1988-08-21', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR. AREQUIPA N° 473', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967656142', 'SI'),
(7, '20081139', 'RAMOS', 'JOAQUIN ', 'ROLANDO', '', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR. ALEJANDRO O. DEUSTUA N° 399', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964635110', 'SI'),
(8, '41722469', 'CHAVEZ ', 'VERASTEGUI', 'WILSON TORIBIO', '1962-12-12', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'PSJ. LAS LOMAS N°499', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(9, '41245294', 'ESPINOZA', 'ORREGO ', 'RONALD ANTHONY', '', '', 'TECNICA', 'SOLTERO', 'HUANCAYO', 'AV. PALIAN N° 840', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(10, '20115680', 'LOARDO', 'NUÑEZ', 'ORLANDO ALEX', '1978-02-15', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'JR. AREQUIPA N° 499', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999993593', 'SI'),
(11, '20115680', 'MACHUCA', 'BORJA', 'FELIX SOLANO', '1987-07-22', '', '', '', '', 'JR. PROGRESO S/N', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(12, '40625365', 'ARAUJO', 'SANTOS', 'CARLOS VICENTE', '', '', '', '', '', 'JR. ALEJANDRO O. DEUSTUA N° 943', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '975233122', 'SI'),
(13, '44279299', 'CHAVEZ', 'JACOBE', 'JOSE LUIS', '', '', '', '', '', 'JR. AREQUIPA N° 499', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924039022', 'SI'),
(14, '23265947', 'RAMOS ', 'ENRIQUE', 'PROSPERO', '', '', '', '', '', 'AV. HUANCAVELICA N°685', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(15, '41684212', 'ROJAS ', 'GAMBOA DE NOGALES', 'GLADYS MARISOL', '', '', '', '', '', 'MANCHEGO MUÑOZ N° 352', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '921377102', 'SI'),
(16, '41219351', 'YARANGA', 'QUISPE', 'LEANDRO', '', '', '', '', '', 'JR HUANCAS N° 1281', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964408872', 'SI'),
(17, '80083301', 'ARROYO ', 'HUAYNATE', 'ROSSY HAYDEE', '', '', '', '', '', 'PSJ LAS ISLAS N° 516 AA. HH.', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '920510025', 'SI'),
(18, '20550103', 'ROMERO', 'HURTADO ', 'INOCENCIA YOLANDA', '', '', '', '', '', 'CALLE CIRCUITO LOS HÉROES N° 202', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '925430862', 'SI'),
(19, '20093764', 'CAMPOS ', 'LOPEZ ', 'ROSARIO ISABEL', '', '', '', '', '', 'AV. CENTENARIO', '', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '987564466', 'SI'),
(20, '20048513', 'CAMAVILCA', 'CHAVEZ', 'JUDITH SARITA', '', '', '', '', '', 'CALLE 3 MZ C LT 16 - VILLA PERIODISTA', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '997959136', 'SI'),
(21, '43810115', 'MAITA', 'RAFAEL', 'JANED AQUILINA', '', '', '', '', '', 'JR. HUANCAS N° 1394', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '914838485', 'SI'),
(22, '47645796', 'CCENTE', 'GOMEZ', 'LIZ', '', '', '', '', '', 'JR. AREQUIPA N° 473', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967656142', 'SI'),
(23, '44639440', 'CAHUANA', 'OCHOA', 'JOSEP ANDRES', '', '', '', '', '', 'JR. LIBERTAD N° 605', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '942139239', 'SI'),
(24, '19820682', 'DE LA PEÑA', 'MARILU', 'MERCEDES', '', '', '', '', '', 'AV. CATALINA HUANCA N° 371', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '989252301', 'SI'),
(25, '19920893', 'BUENDIA ', 'YALLI', 'EPIFANIA', '', '', '', '', '', 'JR. LOS HUANCAS N°496', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '928751106', 'SI'),
(26, '44439463', 'MONTES', 'BALTAZAR ', 'JESENIA JULIZA', '', '', '', '', '', 'JR. JOSE OLAYA N° 177', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '960756995', 'SI'),
(27, '19803612', 'TORRES ', 'AVILA', 'CARLOS HUMBERTO', '', '', '', '', '', 'JR AGUIRRE MORALES N° 1188', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '949573976', 'SI'),
(28, '04011304', 'LOPE', 'MEDRANO', 'SILVIA DORIS', '', '', '', '', '', 'PSJ. CHUCUITO MZ5 LT 0 ', '', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '953671127', 'SI'),
(29, '44628543', 'RIOS ', 'ROJAS', 'KARINA', '', '', '', '', '', 'JR. DIAMANTE AZUL N° 153', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '921184887', 'SI'),
(30, '20006336', 'CALLUPE ', 'OJEDA', 'RUTH ELIANA', '', '', '', '', '', 'JR. LIBERTAD N°535', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999720255', 'SI'),
(31, '47367578', 'ROMERO', 'HERRERA', 'PILAR', '', '', '', '', '', 'JR. HIDRA MZ E LOTE 6', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '956439973', 'SI'),
(32, '19928508', 'SALVATIERRA ', 'VELIZ', 'GILDA ELIANA', '', '', '', '', '', 'JR. AREQUIPA N° 731', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964754900', 'SI'),
(33, '43480244', 'HUAROC ', 'POCOMUCHA ', 'KRISBET', '', '', '', '', '', 'JR. SANTOS CHOCANO N° 951', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '989815297', 'SI'),
(34, '47860194', 'REYMUNDO', 'CARRERA', 'CLARA', '', '', '', '', '', 'PSJ. HUGO CHAVEZ MZ O LT 22', '', '', 'PALIAN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964596957', 'SI'),
(35, '46497378', 'MARQUEZ', 'NESTARES ', 'JESSICA YANINA', '', '', '', '', '', 'JR. SEBASTIAN LORENTE N° 558', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964400100', 'SI'),
(36, '77662005', 'MARQUINA', 'DE ARMERO', 'RODRIGO ORLANDO', '', '', '', '', '', 'PSJ. GULLIVAN N° 102', '', '', 'PALIAN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '988572561', 'SI'),
(37, '20075856', 'ALCOCER', 'BARRIENTOS', 'MIRIAM', '', '', '', '', '', 'JR. NECOCHEA MZ B LT 4 - LA PRADERA', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '968920148', 'SI'),
(38, '42493451', 'CABELLO', 'GARCIA', 'LUIS FERNANDO', '', '', '', '', '', 'AV. FERROCARRIL N° 475', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '981811161', 'SI'),
(39, '19927787', 'POMA', 'CANCHUMANI', 'ESTEBAN VICTOR', '', '', '', '', '', 'AV. 12 DE OCTUBRE N° 402', '', '', 'CULLPA ALTA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '926993108', 'SI'),
(40, '06179596', 'FERNANDEZ', 'SAMANIEGO', ' MARUJA CECILIA', '', '', '', '', '', 'JR. AREQUIPA N° 658 ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '985431389', 'SI'),
(41, '44462205', 'RIOS', 'ORTIZ', 'CESAR AUGUSTO', '', '', '', '', '', 'JR. 13 DE NOVIEMBRE N° 1125', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '954600050', 'SI'),
(42, '10256859', 'ARIAS', 'TORRES', 'JOSE', '', '', '', '', '', 'JR. COLINA N° 689', '', '', 'JAUJA', 'JAUJA', '', '', NULL, NULL, 'SI', '943965936', 'SI'),
(43, '19923319', 'BAUTISTA', 'QUISPEALAYA', 'ADELAIDA CASIMIRA', '', '', '', '', '', 'JR. 1 DE MAYO ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '969244508', 'SI'),
(44, '19909471', 'SALDAÑA', 'RAMIREZ', 'JOSE LUIS', '', '', '', '', '', 'CALLE LAS QUEBRADAS N° 140', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '994775704', 'SI'),
(45, '20012238', 'TORRES', 'MARAVI', 'RODOLFO VICTOR', '', '', '', '', '', 'JR. PARRA DE RIEGO N°540', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924043748', 'SI'),
(46, '19931799', 'CARDENAS ', 'DE SORIANO ', 'SOLEDAD JULIA', '', '', '', '', '', 'PSJ. ELIAS AGUIRRE N° 220', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '949305855', 'SI'),
(47, '21249666', 'TANTAVILCA', 'MARTINEZ', 'MARIA CECILIA', '', '', '', '', '', 'JR. AREQUIPA N° 658', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '998974503', 'SI'),
(48, '42645968', 'MOLINA', 'SANCHOMA', 'ITALO RAUL', '', '', '', '', '', 'PSJ. SAN ANTONIO N° 181', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967309797', 'SI'),
(49, '19838386', 'ZARABIA', 'CONDORI', 'LEONOR', '', '', '', '', '', 'PSJ. BRASIL N° 521', '', '', 'SAÑOS CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '937169980', 'SI'),
(50, '42735885', 'VELASQUEZ ', 'CAMPODONICO', 'JUANA JACKELINE', '', '', '', '', '', 'JR. JOSE OLAYA N° 925', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '946826537', 'SI'),
(51, '19991160', 'HUAMAN', 'GARAY', 'MARIO', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 1043', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '914023283', 'SI'),
(52, '72478132', 'HUAMAN', 'VARGAS ', 'JHAMMEL ORLANDO', '', '', '', '', '', 'CALLE SANTA ROSA MZ Y LT 10 ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '953574039', 'SI'),
(53, '19861956', 'ÑAÑEZ', 'CARO', 'JUAN ANTONIO', '', '', '', '', '', 'CALLE LAS QUEBRADAS N° 140', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964998654', 'SI'),
(54, '80017198', 'POMA ', 'DE LA CRUZ ', 'HERMAN', '', '', '', '', '', 'AV. 12 DE OCTUBRE N° 402', '', '', 'CULLPA ALTA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '926993108', 'SI'),
(55, '19990234', 'GORA', 'RIVERA', 'LIDA MARITZA', '', '', '', '', '', 'CALLE LAS ORQUIDEAS MZ B-2 LT 16', '', '', 'HUAMANCACA CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '948698054', 'SI'),
(56, '19914795', 'PARRA', 'RIVERA', 'LUIS ENRIQUE ', '', '', '', '', '', 'JR. BLANDA N° 125 - MILLOTINGO', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '916730788', 'SI'),
(57, '23522393', 'PERALTA', 'CANALES', 'AGUSTIN', '', '', '', '', '', 'AV. LEONCIO PRADO N° 1179', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '064214127', 'SI'),
(58, '47923529', 'COLONIO', 'NUÑEZ', 'JHONY PAUL', '', '', '', '', '', 'JR. PANAMA N° 1048', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922312579', 'SI'),
(59, '19818737', 'MARQUEZ', 'RODRIGUEZ', 'LUIS CARLOS', '', '', '', '', '', 'PSJ. SAN CARLOS N° 474', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '935070432', 'SI'),
(60, '46155602', 'CAMPO', 'CESPEDES', 'RAQUEL ESTELA', '', '', '', '', '', 'PSJ. COCHARCAS N° 12', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '923739175', 'SI'),
(61, '77130164', 'SANCHEZ', 'DE LA CRUZ ', 'CINTHYA CONSUELO', '', '', '', '', '', 'JR. PARRA DE RIEGO N°581', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(62, '40792615', 'SANTOS', 'CRISTOBAL', 'SULEMA', '', '', '', '', '', 'JR. AMATISTA N° 160 - CIUDAD UNIVERSITARIA', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '957900973', 'SI'),
(63, '44196870', 'POMAYLLE', 'RIVERA', 'LUZ ROXANA', '', '', '', '', '', 'JR. LOS SAUCES N° S/N', '', '', 'SAN AGUSTIN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '964998654', 'SI'),
(64, '48120308', 'BAQUERIZO', 'CALLUPE', 'LUIS KEVIN', '', '', '', '', '', 'CALLE LIBERTAD N° 535', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '963958011', 'SI'),
(65, '20020660', 'CORILLOCLLA ', 'PROSOPIO ', 'EULALIA JULIA', '', '', '', '', '', 'PROLONGACIÓN LIMA N° 2275', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '979606043', 'SI'),
(66, '19963613', 'PAREDES', 'VARGAS', 'YENDER JOSE', '', '', '', '', '', 'AV. SAN MARTIN N° 936', '', '', 'SAN AGUSTIN DE CAJAS', 'HUANCAYO', '', '', NULL, NULL, 'SI', '939254928', 'SI'),
(67, '20099052', 'MEDINA', 'YANCE', 'EMILIANA', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 354', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '921018107', 'SI'),
(68, '48434295', 'LAUREL', 'CASTRO', 'JOSE COOPER', '', '', '', '', '', 'JR. HUANCAS N° 1521', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934409741', 'SI'),
(69, '41675575', 'ACUÑA ', 'SOTO', 'JESSICA KARINA', '', '', '', '', '', 'JR. HUASCAR S/N ', '', '', 'HUAMANCACA CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '9473351211', 'SI'),
(70, '19986232', 'REYNOSO', 'LARA', 'ANSELMO', '', '', '', '', '', 'JR. JOSE OLAYA N° 173', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '925810884', 'SI'),
(71, '20021621', 'PALOMINO', 'SANTIAGO', 'AMELIA', '', '', '', '', '', 'AV. CENTENARIO N° 557', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '998050770', 'SI'),
(72, '62460985', 'RIOS', 'TAMARA', 'WENDY', '', '', '', '', '', 'PSJ. LOS JASMINES N° 352 SEC. 19', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '976513567', 'SI'),
(73, '20064407', 'HIDALGO', 'SEGURA', 'RONALD ALFREDO', '', '', '', '', '', 'JR. TACNA N° 630', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(74, '48192121', 'PALACIOS', 'GONZALES', 'ANGEL GABRIEL', '', '', '', '', '', 'JR. LIMA N° 681 SECTOR 17', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '957527635', 'SI'),
(75, '44411762', 'LAURA', 'CHANCAY', 'EDITH PILAR', '', '', '', '', '', 'AV. JULIO SUMAR N° 138', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '936567160', 'SI'),
(76, '41662049', 'ZAMUDIO', 'SANCHEZ', 'CARLOS ADMUNDO', '', '', '', '', '', 'JR. PATRIOTA N° 589', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '988664536', 'SI'),
(77, '71066313', 'YALICO', 'QUINTANA', 'KERLI YORDANA', '', '', '', '', '', 'AV. 26 DE JULIO N° 4156', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934142364', 'SI'),
(78, '20011679', 'HURTADO', 'DE PUCHOC', 'ALEJANDRA SABINA', '', '', '', '', '', 'JR. LOS ROBLES N° 2130', '', '', 'SAÑOS CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934142364', 'SI'),
(79, '45379197', 'QUINTANA', 'DE MARIN', 'ROSITA ELVIRA', '', '', '', '', '', 'AV. 26 DE JULIO N° 4156', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '934142364', 'SI'),
(80, '20590400', 'MARIN', 'DE QUINTANILLA', 'SILVIA BERTHA', '', '', '', '', '', 'AV. 26 DE JULIO N° 4156', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(81, '19858994', 'HUAYHUA', 'DE LA CRUZ', 'RAUL LUIS', '', '', '', '', '', 'JR. OSWALDO BARRENTO N° 10', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '967447282', 'SI'),
(82, '08146479', 'ROSALES', 'ROJAS', 'REYNALDA', '', '', '', '', '', 'JR. OSWALDO BARRENTO N° 1365', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '943701095', 'SI'),
(83, '47562825', 'MOLINA', 'BALVIN', 'ERLINDA', '', '', '', '', '', 'JR. OSWALDO BARRENTO N° 10', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922513231', 'SI'),
(84, '46347763', 'RAMOS', 'SANTOS', 'AMAYRA VANESSA', '', '', '', '', '', 'JR. LIMA N° 681 SECTOR 17', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924958669', 'SI'),
(85, '19931588', 'MANGO ', 'DE CONDOR', 'TEODORA', '', '', '', '', '', 'JR. JOSE OLAYA N° 458', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '978786097', 'SI'),
(86, '76234021', 'MARIN', 'ASTETE', 'JEAMPIERE FIDEL', '', '', '', '', '', 'AV. RAMON CASTILLA N° 797', '', '', 'CONCEPCION', 'CONCEPCION', '', '', NULL, NULL, 'SI', '916413228', 'SI'),
(87, '44418079', 'BARZOLA', 'BARRETO', 'JESUS RICARDO', '', '', '', '', '', 'JR. JORGE CHAVEZ BLOCK L SECTOR 19', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '986485322', 'SI'),
(88, '48216271', 'CARBAJAL', 'PALOMINO', 'GISSETT LEYDI', '', '', '', '', '', 'AV. HUANCAVELICA N° 740', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '949475807', 'SI'),
(89, '46711885', 'HUAYHUA', 'ESPINOZA', 'SILVER ALFONSO', '', '', '', '', '', 'AA. HH. JUAN PARRA DE RIEGO MZ E LT 5', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '969652957', 'SI'),
(90, '74141967', 'BARZOLA', 'LAURA', 'JASMIN GIOVANA', '', '', '', '', '', 'AV. JULIO SUMAR N° 138', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(91, '19821050', 'CARBAJAL', 'ARIAS', 'YONY HUGO', '', '', '', '', '', 'AV. INDEPENDENCIA N° 599', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '961871007', 'SI'),
(92, '44455902', 'VELASQUEZ ', 'CHUPAN', 'JOEL ANDRES', '', '', '', '', '', 'JR. PORVENIR N° 231', '', '', 'COCHAS CHICO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '947324944', 'SI'),
(93, '45768004', 'OTAIRO', 'PARRAGA', 'ABEL RICHARD', '', '', '', '', '', 'CARRETERA CENTRAL N° 912', '', '', 'SAN AGUSTIN DE CAJAS', 'HUANCAYO', '', '', NULL, NULL, 'SI', '943054435', 'SI'),
(94, '71921087', 'TAPARA', 'LLACUA', 'JHORDY FRANCHESCOLI', '', '', '', '', '', 'JR. REAL Y ARTERIAL ', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '956958327', 'SI'),
(95, '44263315', 'CALCINA', 'LOPEZ', 'AURELHIO JHONATTAN', '', '', '', '', '', 'AV. HUANCAVELICA N° 740', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '944848290', 'SI'),
(96, '20088381', 'CALDERON', 'PINZAS', 'ANA PATRICIA', '', '', '', '', '', 'PSJ. ATLANTIS N°170 SECTOR 9', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '974290950', 'SI'),
(97, '40245040', 'SALDAÑA', 'TAPIA', 'RAQUEL CEFORA', '', '', '', '', '', 'JR. ALAN GARCIA N° 240 SECTOR 04', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '975890229', 'SI'),
(98, '46398806', 'GOMEZ', 'ZANABRIA', 'MARICRUZ MEDALI', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 1330 SECTOR 4', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(99, '41712234', 'SALAZAR ', 'GARAY', 'SILVIA LUZ', '', '', '', '', '', 'JR. HUAMACHUCO N° 770', '', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '935552415', 'SI'),
(100, '19916611', 'LINDO', 'GALVAN', 'RUBEN WALTER', '', '', '', '', '', 'JR. 8 DE DICIEMBRE ', 'ANEXO HUAYAO', '', 'CHUPACA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999265226', 'SI'),
(101, '75970781', 'MESTANZA', 'VILCAPOMA', 'ROSARIO', '', '', '', '', '', 'AV. ALFHA N° 266', 'COOPERATIVA SANTA ISABEL', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '927225914', 'SI'),
(102, '20046609', 'ALEJO', 'TAYPE', 'ELIZABET LEONOR', '', '', '', '', '', 'JR. ALISOS N° 345', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '917806799', 'SI'),
(103, '47744555', 'FIOL', 'RIVAS', 'ABELARDO', '', '', '', '', '', 'JR. PARRA DE RIEGO N° 628', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '942873573', 'SI'),
(104, '19914814', 'COSME', 'RICSE', 'MARCELINO ANTONIO', '', '', '', '', '', 'PSJ. COSME N° 102', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '947441488', 'SI'),
(105, '40010258', 'TARDIO', 'LOAYZA ', 'LUZMILA', '', '', '', '', '', 'PROLONGACIÓN PIURA N° 1331', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '978919381', 'SI'),
(106, '75191385', 'CALLO', 'ROJAS', 'ALICIA PILAR', '', '', '', '', '', 'JR. NEMESIO RAEZ N° 1050', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '923704147', 'SI'),
(107, '73047185', 'DAVID', 'CIERTO', 'LYAN KATHERINE', '', '', '', '', '', 'JR. ANTONIO LOBATO N° 244', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '935938391', 'SI'),
(108, '43017035', 'CONDOR', 'MADRID', 'FLOR DE MARIA', '', '', '', '', '', 'JR. JULIAN HUANAY N° 122', 'SECTOR 10', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '953933375', 'SI'),
(109, '73112442', 'MEDRANO', 'CORILLOCLLA', 'LESLY NAHOMI', '', '', '', '', '', 'PSJ. VISTA ALEGRE N° 131', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(110, '48134522', 'CHUQUILLANQUI ', 'SOTO', 'YEFERSON PAOLO', '', '', '', '', '', 'AV. PASEO LA BREÑA N° 519', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '924130314', 'SI'),
(111, '20102982', 'SOLANO', 'VELARDE', 'NANCY VILMA', '', '', '', '', '', 'JR. LA UNION N° 289', 'VILCACOTO', '', 'PALIAN', 'HUANCAYO', '', '', NULL, NULL, 'SI', '989799256', 'SI'),
(112, '46893928', 'HUAMANI', 'MOLINA', 'GUSTAVO ALEJANDRO', '', '', '', '', '', 'JR. JULIO LLANOS N° 364', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '929458781', 'SI'),
(113, '44297541', 'CHUCO', 'AGUIRRE', 'JOSE LUIS', '', '', '', '', '', 'CALLE CHAVIN N° 308', '3 ESQUINAS', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '938433474', 'SI'),
(114, '46831932', 'MANRIQUE', 'ORTIZ ', 'POOL VLADIMIR', '1994-11-08', '', '', '', '', 'JR. PARRA DE RIEGO N°581', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '976130738', 'SI'),
(115, '80002859', 'POMAHUALOI', 'VILCHEZ', 'MILO MILLER', '', '', '', '', '', 'AV. RAMON CASTILLA N° 152', 'ANEXO PACCHA', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(116, '43449337', 'CHUCO', 'AGUIRRE', 'MIGUEL ANGEL', '', '', '', '', '', 'CALLE CHAVIN N° 308', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '978280828', 'SI'),
(117, '20019795', 'VARGAS', 'DE LA CRUZ ', 'VLADIMIR LUIS', '', '', '', '', '', 'JR. JULIO C. TELLO N° 1022', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '917947567', 'SI'),
(118, '19847160', 'TINEO', 'VELITA', 'ANTONIO', '', '', '', '', '', 'JR. PARRA DE RIEGO N°581', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '936466421', 'SI'),
(119, '19943634', 'COCHACHI', 'SOLANO', 'ESTEBAN GERARDO', '', '', '', '', '', 'PSJ. ROJAS N° 182', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '984330704', 'SI'),
(120, '47576938', 'GONZALES ', 'PRADO ', 'ROSA', '', '', '', '', '', 'PSJ. LOS ANGELES N° 284', '', '', 'HUANCAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '936034640', 'SI'),
(121, '74234731', 'DE LA CRUZ', 'CANTARO', 'JESSI', '', '', '', '', '', 'JR. LA HERRADURA ', 'PSJ. LOS NOGALES ', '', 'PILCOMAYO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922976656', 'SI'),
(122, '47726338', 'JULCA', 'CENIZARIO', 'CINTHYA', '', '', '', '', '', 'AV. PROGRESO N° 826', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(123, '20011425', 'NAULA', 'LLANCO', 'GISELA', '', '', '', '', '', 'PSJ. EL SOL N° S/N ', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '969444504', 'SI'),
(124, '42673599', 'GOMEZ ', 'SEDANO', 'JUAN CARLOS', '', '', '', '', '', 'PSJ. SANTA ROSA N° S/N', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(125, '40272188', 'TERREL', 'ROSALES', 'ISAIAS SEBASTIAN', '', '', '', '', '', 'PSJ. LAS TURQUESAS N° 100', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '983989756', 'SI'),
(126, '19917677', 'HUAMANI', 'QUISPE', 'PEDRO JACINTO', '', '', '', '', '', 'JR. YAUYOS N° 259', 'PARQUE INDUSTRIAL - AV. HUANCAVELICA', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '983640511', 'SI'),
(127, '75047268', 'TERREROS ', 'CHAVEZ', 'ALVARO OMAR', '', '', '', '', '', 'CALLE REAL N° 378', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '922181903', 'SI'),
(128, '43760865', 'NINALAYA ', 'CHUQUILLANQUI', 'RICHARD', '', '', '', '', '', 'PSJ. LAS MONTAÑAS N° 143', '', '', 'PIO PATA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '939340139', 'SI'),
(129, '29400964', 'MORENO', 'GIRONDO', 'ROSA MARINA', '', '', '', '', '', 'JR. B. LEGUIA N°360 ', '', '', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '000000000', 'SI'),
(130, '74627137', 'CAMASCA', 'HUAROC', 'CLAUDIA LISSETH', '', '', '', '', '', 'JR. ALEJANDRO O. DEUSTUA N° 411', '', '', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '977662803', 'SI'),
(131, '70771878', 'SANDOVAL', 'WONG', 'GILMER JOEL', '1996-07-14', '', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'JR. RICARDO MENENDEZ S/N', 'PSJ. C-5', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '3', 'COBRADOR', NULL, NULL, 'SI', '921129432', 'SI'),
(132, '15427062', 'SACAYCO ', 'MELO', 'JULIO CESAR', '1971-12-18', '', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', 'CALLE LA AMISTAD N°329', 'JUSTICIA PAZ Y VIDA', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '48', '', NULL, NULL, 'SI', '917471435', 'SI'),
(133, '44398011', 'FLORES ', 'TINCOPA', 'WILLIAM', '1987-02-19', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'JR.JOSE MARIA ARGUEDAS MZJLT . 3', 'JUSTICIA PAZ Y VIDA', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '31 AÑOS ', 'TRANSPORTISTA', NULL, NULL, 'SI', '961313801', 'SI'),
(134, '46447422', 'GOMEZ', 'MORENO ', 'CHRISTOPHER', '1990-04-13', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR. CHICLAYO N343', '', 'FAMILIAR', 'TAMBO ', 'HUANCAYO ', '29', '', NULL, NULL, 'SI', '926986052', 'SI'),
(135, '40489116', 'VIDALON ', 'EIZAGUIRRE', 'GINO JORGE ERNESTO', '1978-09-17', '1', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR.AREQUIPA 746', 'COLEGIO DE CARTON ', 'FAMILIAR', 'CHILCA ', 'HUANCAYO', '20 AÑOS ', '', NULL, NULL, 'SI', '945806000', 'SI'),
(136, '80005737', 'ALVAREZ', 'HILARIO', 'DAVID ALI', '1976-04-02', '0', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'AH. NTA SRA DE COCHARCAS BLOCK M MZ 6', 'PIO PATA', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '40 AÑOS', '', NULL, '5ddfe0dac125d.jpeg', 'NO', '943965706', 'SI'),
(137, '29400964', 'MORENO', 'GIRONDA', 'ROSA', '1965-11-12', '2', 'UNIVERSITARIA', 'CASADO', 'AREQUIPA', 'JR.AUGUSTO B . LEGUIA 630', 'MERCADO CHILCA', 'FAMILIAR', 'CHICLA', 'HUANCAYO', '30AÑOS', '', NULL, NULL, 'SI', '976728077', 'SI'),
(138, '43771995', 'BREÑA', 'ESPEJO', 'MARGOTH YOVANA', '1986-09-23', '3', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'JR. INCA RIPAC N° 1625', 'ASENTAMIENTO JUAN PARRA ', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '30', '', NULL, '5de12f7fe3e93.jpeg', 'SI', '943941332', 'SI'),
(139, '41591874', 'LAZARO', 'FALCON ', 'MIGUEL HECTOR ', '1981-12-01', '', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'CA. LOS CLAVELES N. 151 AA.VV. BRISAS DEL TAM', 'PARADERO DE VIRGO ', 'FAMILIAR', 'TAMBO ', 'HUANCAYO', '5AÑOS', '', NULL, NULL, 'SI', '949479111', 'SI'),
(140, '20076463', 'ANGULO', 'CARDENAS', 'ERNESTO', '1974-02-22', '1', 'SUPERIOR', 'CASADO', 'HUANCAYO', 'PSJ SAENZ PEÑA 519', 'COLISEO WANKA', 'FAMILIAR', 'CHILCA', 'HUANCAYO', '20 AÑOS ', '', NULL, NULL, 'SI', '954138105', 'SI'),
(141, '19947288', 'palacios', 'alvarado', 'yony david ', '1966-03-26', '', 'SUPERIOR', 'SOLTERO', 'huancayo', 'chavez y real s/n', 'banco QAPQAP', 'PROPIA', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '947999036', 'SI'),
(142, '19836636', 'sandoval ', 'povis ', 'gilmer factor', '1958-12-27', '1', 'SUPERIOR', 'CONVIVIENTE', 'huancayo', 'ricardo mendez lote c. manzana 5', '', 'PROPIA', 'TAMBO ', 'HUANCAYO', '20 AÑOS ', '', NULL, NULL, 'SI', '927774396', 'SI'),
(143, '46198930', 'HOLGUIN', 'RIVAS', 'JOSE LUIS', '', '1', 'SECUNDARIA', 'SOLTERO', 'HUANCAYO', 'JR. PARRA DEL RIEGO N° 728', 'HUANCAVELICA', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '10', '', NULL, NULL, 'NO', '945899979', 'SI'),
(144, '46551735', 'CRUZ ', 'ZUÑIGA', 'ANGEL RIDER ', '1985-02-13', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'AV.JOSE MARIA ARGUEDAS 596', '', 'ALQUILADA', 'HUANCAYO', 'HUANCAYO', '15AÑOS', '', NULL, NULL, 'SI', '948634749', 'SI'),
(145, '71037256', 'RODRIGO ', 'YARANGA ', 'DEYSI ', '1992-07-27', '', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'CA.LOS CLAVELES N 151 BRISAS DEL MANTARO ', 'PARADERO DE VIRGO ', 'FAMILIAR', 'TAMBO ', 'HUANCAYO ', '26 AÑOS ', '', NULL, NULL, 'SI', '958045498', 'SI'),
(146, '44320818', 'LEYVA', 'CARDENAS ', 'CRISTIAN JESUS', '1984-01-24', '1', 'SUPERIOR', 'DIVORCIADO', 'HUANCAYO', 'AV. MAXIMO GORKI 525', 'JUSTICIA PAZ Y VIDA', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '10 AÑOS ', '', NULL, NULL, 'SI', '931085563', 'SI'),
(147, '20029620', 'HUAMANI ', 'SAIRE', 'JUSTO ROMAN', '1961-09-09', '1', 'DOCTORADO', 'CASADO', 'HUANCAYO', 'AV. LA MEJORADA ', '', 'PROPIA', 'EL TAMBO', 'HUANCAYO', '20', '', NULL, NULL, 'NO', '967656142', 'SI'),
(148, '46497378', 'MARQUEZ', 'NESTARES', 'JESSICA YANINA', '', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO ', 'JR.SEBASTIAN LORENTE 558', 'MERCADO DEL TAMBO ', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '10AÑOS', '', NULL, NULL, 'SI', '964400100', 'SI'),
(149, '74149327', 'ORIHUELA ', 'HUAYNALAYA', 'TOPSY GABY', '1993-05-26', '', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', 'JR.ANTONIO LOBATO 951', '', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '999332398', 'SI'),
(150, '42036675', 'LAZARO', 'FALCON', 'BENITA CONSUELO', '1983-07-10', '', '', 'DIVORCIADO', 'HUANCAYO', 'AV. 1 DE MAYO 851', 'JUSTICIA PAZ Y VIDA', 'ALQUILADA', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '928311573', 'SI'),
(151, '952812847', 'CORAHUA', 'RASHUAMAN', 'EVER ROMAN', '1986-01-01', '1', 'SUPERIOR', 'CONVIVIENTE', 'HUANCAYO', 'jr.bruno terreros 1509', 'PARADERO DE VIRGO ', 'FAMILIAR', 'EL TAMBO', 'HUANCAYO', '', '', NULL, NULL, 'SI', '952812847', 'SI'),
(152, '20644224', 'VELAZCO', 'BRAVO', 'ALEJANDRO ULISES', '1958-12-05', '0', 'SUPERIOR', 'SOLTERO', 'JAUJA', 'AV. HEROES DE LA BREÑA', 'JAUJA', 'FAMILIAR', 'JAUJA', 'JAUJA', '10', '', NULL, NULL, 'NO', '954034976', 'SI'),
(153, '29400964', 'MORENO', 'GIRONDA', 'ROSA MARINA', '1965-11-12', '2', 'SUPERIOR', 'CASADO', 'AREQUIPA', 'AV.AUGUSTO B.LEGUIA 630 CHILCA', 'MERCADO CHILCA', 'PROPIA', 'CHILCA', 'HUANCAYO', '', '', NULL, NULL, 'SI', '976728077', 'SI');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consumo`
--

CREATE TABLE `consumo` (
  `idconsumo` int(11) NOT NULL,
  `dedicacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tiempo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `ingreso` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `lugar_trabajo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `profesion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conyugue`
--

CREATE TABLE `conyugue` (
  `idconyugue` int(11) NOT NULL,
  `apellido_pat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dni` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `sexo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `ocupacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `dir_trabajo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `parentesco` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `habilitado` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `conyugue`
--

INSERT INTO `conyugue` (`idconyugue`, `apellido_pat`, `apellido_mat`, `nombre`, `dni`, `sexo`, `nacimiento`, `direccion`, `ocupacion`, `dir_trabajo`, `parentesco`, `tipo`, `habilitado`, `clientes_idcliente`) VALUES
(1, 'SALAZAR', 'ROJAS', 'GEORGE JAME', '70231170', 'M', '1993-09-13', 'JR. RICARDO MENENDEZ', 'CONDUCTOR', 'RUTA VIRGO', 'CONOCIDO', 'CONYUGUE', 'SI', 131),
(3, 'LAZARO ', 'FALCON ', 'BENITA CONSUELO', '42036675', 'F', '1982-07-10', 'AV. 1 DE MAYO N° 851 AA HH 44', 'COMERCIANTE', 'JUSTICIA PAZ Y VIDA - CANCHON', 'ESPOSO', 'CONYUGUE', 'SI', 146);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `creditos`
--

CREATE TABLE `creditos` (
  `idcredito` int(11) NOT NULL,
  `monto_prop` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `n_cuotas` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `n_cuotas_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `interes` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `interes_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `frecuencia` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `m_cuotas` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `m_cuotas_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `m_interes` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `m_interes_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `m_total` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `m_total_aprob` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_reg` datetime NOT NULL,
  `estado` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `clientes_idcliente` int(11) NOT NULL,
  `conyugue_id` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `aval_id` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `creditos`
--

INSERT INTO `creditos` (`idcredito`, `monto_prop`, `monto_aprob`, `n_cuotas`, `n_cuotas_aprob`, `interes`, `interes_aprob`, `frecuencia`, `fecha_inicio`, `m_cuotas`, `m_cuotas_aprob`, `m_interes`, `m_interes_aprob`, `m_total`, `m_total_aprob`, `fecha_reg`, `estado`, `clientes_idcliente`, `conyugue_id`, `aval_id`) VALUES
(6, '600', '600', '25', '25', '10', '10', 'DIARIO', '2019-11-26', '26.4', '26.4', '60', '60', '660', '660', '2019-11-25 10:15:22', 'DESEMBOLSADO', 125, '', ''),
(7, '400', '400', '25', '25', '10', '10', 'DIARIO', '2019-11-26', '17.6', '17.6', '40', '40', '440', '440', '2019-11-25 10:16:16', 'DESEMBOLSADO', 124, '', ''),
(8, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-11-26', '13.2', '13.2', '30', '30', '330', '330', '2019-11-25 10:46:54', 'DESEMBOLSADO', 131, '1', ''),
(16, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-11-26', '13.2', '13.2', '30', '30', '330', '330', '2019-11-25 19:10:39', 'REGISTRADO', 54, '', ''),
(31, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-11-27', '13.2', '13.2', '30', '30', '330', '330', '2019-11-25 19:57:12', 'REGISTRADO', 132, '', ''),
(35, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-11-28', '13.2', '13.2', '30', '30', '330', '330', '2019-11-26 09:23:01', 'DESEMBOLSADO', 133, '', ''),
(36, '500', '500', '25', '25', '10', '10', 'DIARIO', '2019-11-28', '22', '22', '50', '50', '550', '550', '2019-11-26 09:25:58', 'DESEMBOLSADO', 85, '', ''),
(39, '600', '600', '25', '25', '10', '10', 'DIARIO', '2019-11-27', '26.4', '26.4', '60', '60', '660', '660', '2019-11-26 15:20:11', 'DESEMBOLSADO', 39, '1', ''),
(40, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-11-29', '13.2', '13.2', '30', '30', '330', '330', '2019-11-27 19:07:17', 'DESEMBOLSADO', 134, '', ''),
(43, '600', '600', '25', '25', '10', '10', 'DIARIO', '2019-12-02', '26.4', '26.4', '60', '60', '660', '660', '2019-11-28 10:10:13', 'DESEMBOLSADO', 122, '', ''),
(44, '400', '400', '25', '25', '10', '10', 'DIARIO', '2019-11-29', '17.6', '17.6', '40', '40', '440', '440', '2019-11-28 17:51:44', 'DESEMBOLSADO', 136, '', ''),
(45, '800', '800', '8', '8', '20', '20', 'SEMANAL', '2019-12-05', '120', '120', '160', '160', '960', '960', '2019-11-28 18:19:24', 'DESEMBOLSADO', 107, '', ''),
(46, '300', '300', '8', '8', '20', '20', 'SEMANAL', '2019-12-05', '45', '45', '60', '60', '360', '360', '2019-11-28 18:21:59', 'DESEMBOLSADO', 81, '', ''),
(47, '500', '500', '25', '25', '10', '10', 'DIARIO', '2019-11-30', '22', '22', '50', '50', '550', '550', '2019-11-29 09:20:49', 'DESEMBOLSADO', 129, '', ''),
(48, '300', NULL, '25', NULL, '10', NULL, 'DIARIO', '2019-11-30', '13.2', NULL, '30', NULL, '330', NULL, '2019-11-29 09:32:15', 'REGISTRADO', 134, '', ''),
(50, '500', '500', '4', '4', '10', '10', 'SEMANAL', '2019-12-07', '137.5', '137.5', '50', '50', '550', '550', '2019-11-29 11:30:53', 'DESEMBOLSADO', 65, '', ''),
(51, '250', '250', '4', '4', '10', '10', 'SEMANAL', '2019-12-07', '68.8', '68.8', '25', '25', '275', '275', '2019-11-29 11:31:36', 'DESEMBOLSADO', 112, '', ''),
(52, '355', '355', '25', '25', '10', '10', 'DIARIO', '2019-11-30', '15.7', '15.7', '35.5', '35.5', '390.5', '390.5', '2019-11-29 15:17:26', 'DESEMBOLSADO', 116, '', ''),
(53, '440', '440', '25', '25', '10', '10', 'DIARIO', '2019-11-30', '19.4', '19.4', '44', '44', '484', '484', '2019-11-29 15:18:57', 'DESEMBOLSADO', 113, '', ''),
(54, '300', '300', '2', '2', '10', '10', 'QUINCENAL', '2019-12-14', '165', '165', '30', '30', '330', '330', '2019-11-29 19:08:12', 'DESEMBOLSADO', 115, '', ''),
(55, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-05', '13.2', '13.2', '30', '30', '330', '330', '2019-12-02 09:23:06', 'DESEMBOLSADO', 139, '', ''),
(57, '181.5', '181.5', '4', '4', '10', '10', 'SEMANAL', '2019-12-14', '50', '50', '18.2', '18.2', '199.7', '199.7', '2019-12-03 09:40:32', 'DESEMBOLSADO', 108, '', ''),
(58, '800', '800', '25', '25', '5', '5', 'DIARIO', '2019-12-05', '33.6', '33.6', '40', '40', '840', '840', '2019-12-04 11:49:44', 'DESEMBOLSADO', 61, '', ''),
(60, '800', '800', '40', '40', '15', '15', 'DIARIO', '2019-12-10', '23', '23', '120', '120', '920', '920', '2019-12-04 17:11:42', 'DESEMBOLSADO', 53, '', ''),
(61, '156', '156', '17', '17', '10', '10', 'DIARIO', '2019-12-05', '10.1', '10.1', '15.6', '15.6', '171.6', '171.6', '2019-12-04 17:58:51', 'DESEMBOLSADO', 82, '', ''),
(62, '600', '600', '4', '4', '10', '10', 'SEMANAL', '2019-12-12', '165', '165', '60', '60', '660', '660', '2019-12-05 09:22:36', 'DESEMBOLSADO', 92, '', ''),
(64, '400', '400', '25', '25', '10', '10', 'DIARIO', '2019-12-06', '17.6', '17.6', '40', '40', '440', '440', '2019-12-05 17:11:40', 'DESEMBOLSADO', 130, '', ''),
(65, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-10', '13.2', '13.2', '30', '30', '330', '330', '2019-12-06 09:27:31', 'DESEMBOLSADO', 140, '', ''),
(66, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-10', '13.2', '13.2', '30', '30', '330', '330', '2019-12-07 09:30:37', 'DESEMBOLSADO', 141, '', ''),
(69, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-11', '13.2', '13.2', '30', '30', '330', '330', '2019-12-09 18:58:37', 'DESEMBOLSADO', 142, '', ''),
(70, '260', '260', '3', '3', '20', '20', 'QUINCENAL', '2019-12-23', '104', '104', '52', '52', '312', '312', '2019-12-09 19:17:43', 'DESEMBOLSADO', 143, '', ''),
(71, '1000', '1000', '8', '8', '20', '20', 'SEMANAL', '2019-12-17', '150', '150', '200', '200', '1200', '1200', '2019-12-10 09:40:49', 'DESEMBOLSADO', 114, '', ''),
(72, '400', NULL, '4', NULL, '10', NULL, 'SEMANAL', '2019-12-18', '110', NULL, '40', NULL, '440', NULL, '2019-12-10 18:11:44', 'REGISTRADO', 56, '', ''),
(73, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-12', '13.2', '13.2', '30', '30', '330', '330', '2019-12-10 18:14:08', 'DESEMBOLSADO', 144, '', ''),
(76, '600', '600', '25', '25', '10', '10', 'DIARIO', '2019-12-13', '26.4', '26.4', '60', '60', '660', '660', '2019-12-11 09:54:12', 'DESEMBOLSADO', 127, '', ''),
(77, '500', '500', '25', '25', '10', '10', 'DIARIO', '2019-12-12', '22', '22', '50', '50', '550', '550', '2019-12-11 15:10:28', 'DESEMBOLSADO', 146, '3', ''),
(78, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-12', '13.2', '13.2', '30', '30', '330', '330', '2019-12-11 15:44:02', 'DESEMBOLSADO', 145, '', ''),
(79, '600', '600', '4', '4', '10', '10', 'SEMANAL', '2019-12-19', '165', '165', '60', '60', '660', '660', '2019-12-12 15:08:45', 'DESEMBOLSADO', 104, '', ''),
(80, '400', NULL, '4', NULL, '10', NULL, 'SEMANAL', '2019-12-20', '110', NULL, '40', NULL, '440', NULL, '2019-12-12 19:03:45', 'REGISTRADO', 56, '', ''),
(81, '500', '500', '1', '1', '10', '10', 'MENSUAL', '2020-01-19', '550', '550', '50', '50', '550', '550', '2019-12-13 10:00:38', 'DESEMBOLSADO', 147, '', ''),
(82, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-14', '13.2', '13.2', '30', '30', '330', '330', '2019-12-13 10:21:45', 'DESEMBOLSADO', 117, '', ''),
(83, '400', NULL, '8', NULL, '20', NULL, 'SEMANAL', '2019-12-23', '60', NULL, '80', NULL, '480', NULL, '2019-12-13 15:22:47', 'REGISTRADO', 35, '', ''),
(84, '1500', '1500', '50', '50', '20', '20', 'DIARIO', '2019-12-16', '36', '36', '300', '300', '1800', '1800', '2019-12-13 15:27:21', 'DESEMBOLSADO', 149, '', ''),
(85, '400', '400', '4', '4', '10', '10', 'SEMANAL', '2019-12-20', '110', '110', '40', '40', '440', '440', '2019-12-13 16:08:12', 'DESEMBOLSADO', 56, '', ''),
(86, '400', NULL, '8', NULL, '20', NULL, 'SEMANAL', '0019-12-17', '60', NULL, '80', NULL, '480', NULL, '2019-12-16 15:29:22', 'REGISTRADO', 148, '', ''),
(88, '500', '500', '4', '4', '10', '10', 'SEMANAL', '2019-12-24', '137.5', '137.5', '50', '50', '550', '550', '2019-12-17 12:04:23', 'DESEMBOLSADO', 59, '', ''),
(89, '500', '500', '4', '4', '10', '10', 'SEMANAL', '2019-12-26', '137.5', '137.5', '50', '50', '550', '550', '2019-12-17 18:52:56', 'DESEMBOLSADO', 150, '', ''),
(90, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-19', '13.2', '13.2', '30', '30', '330', '330', '2019-12-17 18:53:49', 'DESEMBOLSADO', 132, '', ''),
(91, '300', '300', '25', '25', '10', '10', 'DIARIO', '2019-12-20', '13.2', '13.2', '30', '30', '330', '330', '2019-12-18 09:15:05', 'DESEMBOLSADO', 151, '', ''),
(92, '400', '400', '25', '25', '10', '10', 'DIARIO', '2019-12-19', '17.6', '17.6', '40', '40', '440', '440', '2019-12-18 15:05:34', 'DESEMBOLSADO', 123, '', ''),
(93, '150', '150', '4', '4', '10', '10', 'SEMANAL', '2019-12-26', '41.3', '41.3', '15', '15', '165', '165', '2019-12-18 18:08:48', 'DESEMBOLSADO', 152, '', ''),
(94, '500', NULL, '25', NULL, '10', NULL, 'DIARIO', '2019-12-21', '22', NULL, '50', NULL, '550', NULL, '2019-12-18 18:32:27', 'PREAPROBADO', 129, '', ''),
(95, '300', '300', '4', '4', '10', '10', 'SEMANAL', '2019-12-26', '82.5', '82.5', '30', '30', '330', '330', '2019-12-19 09:41:38', 'DESEMBOLSADO', 120, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `desembolso`
--

CREATE TABLE `desembolso` (
  `iddesembolso` int(11) NOT NULL,
  `fecha_reg` datetime NOT NULL,
  `fecha_desem` datetime DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `desembolso`
--

INSERT INTO `desembolso` (`iddesembolso`, `fecha_reg`, `fecha_desem`, `creditos_idcredito`, `usuarios_idusuario`) VALUES
(3, '2019-11-25 10:26:30', '2019-11-25 10:50:49', 7, 7),
(4, '2019-11-25 10:26:55', '2019-11-25 10:51:13', 6, 7),
(5, '2019-11-25 10:48:18', '2019-11-25 16:21:31', 8, 7),
(8, '2019-11-26 18:59:54', '2019-11-26 19:05:59', 39, 7),
(9, '2019-11-27 09:32:16', '2019-11-27 17:46:52', 36, 7),
(11, '2019-11-27 17:44:08', '2019-11-28 18:32:16', 35, 7),
(13, '2019-11-28 17:52:44', '2019-11-28 17:54:41', 44, 7),
(14, '2019-11-28 18:25:12', '2019-11-28 18:33:37', 45, 7),
(15, '2019-11-28 18:35:47', '2019-11-28 18:36:40', 46, 7),
(16, '2019-11-29 10:25:30', '2019-11-29 10:26:58', 40, 7),
(17, '2019-11-29 11:34:13', '2019-11-29 11:39:00', 50, 7),
(18, '2019-11-29 11:52:15', '2019-11-29 11:53:10', 51, 7),
(19, '2019-11-29 15:34:00', '2019-11-29 15:34:40', 52, 3),
(20, '2019-11-29 15:35:17', '2019-11-29 15:54:06', 53, 3),
(21, '2019-11-29 17:14:13', '2019-11-29 17:14:23', 47, 3),
(22, '2019-11-29 19:31:17', '2019-11-29 19:32:32', 54, 3),
(23, '2019-11-30 09:37:39', '2019-11-30 09:42:44', 43, 3),
(24, '2019-12-03 09:41:41', '2019-12-03 09:43:44', 57, 7),
(25, '2019-12-04 12:34:42', '2019-12-04 12:35:31', 58, 7),
(26, '2019-12-04 17:28:44', '2019-12-04 17:30:07', 55, 3),
(27, '2019-12-04 18:00:23', '2019-12-04 18:01:39', 61, 3),
(28, '2019-12-05 17:13:07', '2019-12-05 17:17:33', 64, 3),
(29, '2019-12-05 18:10:16', '2019-12-05 18:12:09', 62, 3),
(31, '2019-12-09 09:57:28', '2019-12-09 09:58:02', 66, 7),
(32, '2019-12-09 16:26:54', '2019-12-09 16:29:10', 65, 7),
(33, '2019-12-09 18:31:46', '2019-12-09 18:33:14', 60, 7),
(34, '2019-12-09 19:18:48', '2019-12-09 19:19:23', 70, 7),
(35, '2019-12-10 10:16:02', '2019-12-10 10:16:28', 69, 7),
(36, '2019-12-10 18:22:44', '2019-12-10 18:40:10', 71, 3),
(37, '2019-12-11 11:57:14', '2019-12-11 11:58:36', 76, 7),
(38, '2019-12-11 17:53:00', '2019-12-11 17:54:19', 73, 3),
(39, '2019-12-11 17:54:57', '2019-12-11 17:57:34', 78, 7),
(40, '2019-12-12 16:04:17', '2019-12-12 16:05:40', 79, 7),
(42, '2019-12-12 17:30:49', '2019-12-12 17:31:04', 77, 3),
(43, '2019-12-13 10:02:24', '2019-12-13 10:03:26', 81, 7),
(44, '2019-12-13 16:10:16', '2019-12-13 16:11:55', 85, 3),
(45, '2019-12-13 18:17:52', '2019-12-13 18:18:08', 82, 3),
(47, '2019-12-14 13:04:05', '2019-12-14 13:04:27', 84, 7),
(48, '2019-12-17 17:53:57', '2019-12-17 17:55:33', 88, 3),
(50, '2019-12-18 15:29:07', '2019-12-18 15:29:23', 92, 3),
(51, '2019-12-18 17:45:34', '2019-12-18 17:46:37', 90, 3),
(52, '2019-12-18 17:47:53', '2019-12-18 17:53:09', 89, 3),
(53, '2019-12-18 18:33:37', '2019-12-18 18:34:02', 93, 3),
(54, '2019-12-19 10:06:32', '2019-12-19 10:07:18', 95, 7),
(55, '2019-12-19 10:16:44', '2019-12-19 10:17:14', 91, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos`
--

CREATE TABLE `movimientos` (
  `idmovimiento` int(11) NOT NULL,
  `tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `concepto` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_mov` datetime NOT NULL,
  `autoriza` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo_comprobante` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nro_comprobante` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `detalle` text COLLATE utf8_spanish_ci DEFAULT NULL,
  `cajas_idcaja` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `movimientos`
--

INSERT INTO `movimientos` (`idmovimiento`, `tipo`, `monto`, `concepto`, `fecha_mov`, `autoriza`, `tipo_comprobante`, `nro_comprobante`, `detalle`, `cajas_idcaja`, `usuarios_idusuario`) VALUES
(16, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-11-25 10:50:49', 'ADMINISTRADOR', 'VOUCHER', '3', NULL, 2, 7),
(17, 'EGRESO', '600', 'DESEMBOLSO DE CREDITO', '2019-11-25 10:51:13', 'ADMINISTRADOR', 'VOUCHER', '4', NULL, 2, 7),
(18, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-11-25 16:21:31', 'ADMINISTRADOR', 'VOUCHER', '5', NULL, 3, 7),
(19, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-11-25 19:13:52', 'ADMINISTRADOR', 'VOUCHER', '6', NULL, 4, 7),
(20, 'INGRESO', '26.4', 'PAGO DE CUOTA DE CREDITO', '2019-11-26 15:33:03', 'CAJERO', 'VOUCHER', '42', NULL, 5, 7),
(21, 'INGRESO', '13.2', 'PAGO DE CUOTA DE CREDITO', '2019-11-26 18:55:28', 'CAJERO', 'VOUCHER', '67', NULL, 5, 7),
(22, 'EGRESO', '600', 'DESEMBOLSO DE CREDITO', '2019-11-26 19:05:59', 'ADMINISTRADOR', 'VOUCHER', '8', NULL, 6, 7),
(23, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-11-26 19:06:11', 'ADMINISTRADOR', 'VOUCHER', '7', NULL, 6, 7),
(24, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-11-27 17:46:52', 'ADMINISTRADOR', 'VOUCHER', '9', NULL, 7, 7),
(25, 'INGRESO', '15.2', 'PAGO DE CUOTA DE CREDITO', '2019-11-27 19:30:47', 'CAJERO', 'VOUCHER', '92', NULL, 5, 7),
(26, 'INGRESO', '15.2', 'PAGO DE CUOTA DE CREDITO', '2019-11-27 19:31:16', 'CAJERO', 'VOUCHER', '92', NULL, 5, 7),
(27, 'INGRESO', '27.4', 'PAGO DE CUOTA DE CREDITO', '2019-11-27 19:32:05', 'CAJERO', 'VOUCHER', '117', NULL, 5, 7),
(28, 'INGRESO', '13.2', 'PAGO DE CUOTA DE CREDITO', '2019-11-27 19:32:51', 'CAJERO', 'VOUCHER', '67', NULL, 5, 7),
(29, 'INGRESO', '15.2', 'PAGO DE CUOTA DE CREDITO', '2019-11-27 19:33:49', 'CAJERO', 'VOUCHER', '92', NULL, 5, 7),
(30, 'INGRESO', '14.2', 'PAGO DE CUOTA DE CREDITO', '2019-11-27 19:34:05', 'CAJERO', 'VOUCHER', '93', NULL, 5, 7),
(31, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-11-28 17:48:29', 'ADMINISTRADOR', 'VOUCHER', '12', NULL, 7, 7),
(32, 'INGRESO', '1000', 'PARA DESEMBOLSOS', '2019-11-28 17:54:24', 'JACKELINE ESTRADA', '00001', 'RECIBO', 'DESEMBOLSOS DEL DIA', 5, 7),
(33, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-11-28 17:54:41', 'ADMINISTRADOR', 'VOUCHER', '13', NULL, 5, 7),
(34, 'INGRESO', '1000', 'Habilitación de efectivo', '2019-11-28 18:30:21', 'administrador', 'RECIBO', '000002', 'DESEMBOLSO PARA REFINANCIACION', 5, 7),
(35, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-11-28 18:32:16', 'ADMINISTRADOR', 'VOUCHER', '11', NULL, 5, 7),
(36, 'EGRESO', '800', 'DESEMBOLSO DE CREDITO', '2019-11-28 18:33:37', 'ADMINISTRADOR', 'VOUCHER', '14', NULL, 5, 7),
(37, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-11-28 18:36:40', 'ADMINISTRADOR', 'VOUCHER', '15', NULL, 5, 7),
(38, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-11-29 10:26:58', 'ADMINISTRADOR', 'VOUCHER', '16', NULL, 5, 7),
(39, 'INGRESO', '1500', 'PARA DESEMBOLSOS', '2019-11-29 11:38:37', 'JACKELINE ESTRADA', 'RECIBO', '00003', 'PARA DESEMBOLSO', 5, 7),
(40, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-11-29 11:39:00', 'ADMINISTRADOR', 'VOUCHER', '17', NULL, 5, 7),
(41, 'EGRESO', '250', 'DESEMBOLSO DE CREDITO', '2019-11-29 11:53:10', 'ADMINISTRADOR', 'VOUCHER', '18', NULL, 5, 7),
(42, 'EGRESO', '355', 'DESEMBOLSO DE CREDITO', '2019-11-29 15:34:40', 'ADMINISTRADOR', 'VOUCHER', '19', NULL, 5, 3),
(43, 'INGRESO', '1000', 'PARA DESEMBOLSOS', '2019-11-29 15:53:36', 'JACKELINE ESTRADA', 'RECIBO', '00005', 'PARA DESEMBOLSO', 5, 3),
(44, 'EGRESO', '440', 'DESEMBOLSO DE CREDITO', '2019-11-29 15:54:06', 'ADMINISTRADOR', 'VOUCHER', '20', NULL, 5, 3),
(45, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-11-29 17:14:23', 'ADMINISTRADOR', 'VOUCHER', '21', NULL, 5, 3),
(46, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-11-29 19:32:32', 'ADMINISTRADOR', 'VOUCHER', '22', NULL, 5, 3),
(47, 'INGRESO', '500', 'habilitacion para desembolso', '2019-11-30 09:42:00', '', 'RECIBO', '00006', '', 5, 3),
(48, 'EGRESO', '600', 'DESEMBOLSO DE CREDITO', '2019-11-30 09:42:44', 'ADMINISTRADOR', 'VOUCHER', '23', NULL, 5, 3),
(49, 'INGRESO', '1413.1', 'habilitacion para desembolso', '2019-12-03 09:43:28', 'JACKELINE ESTRADA', 'RECIBO', 'RECIBO', 'DESEMBOLSO 03/12/2019', 5, 7),
(50, 'EGRESO', '181.5', 'DESEMBOLSO DE CREDITO', '2019-12-03 09:43:44', 'ADMINISTRADOR', 'VOUCHER', '24', NULL, 5, 7),
(51, 'EGRESO', '800', 'DESEMBOLSO DE CREDITO', '2019-12-04 12:35:31', 'ADMINISTRADOR', 'VOUCHER', '25', NULL, 5, 7),
(52, 'INGRESO', '300', 'PARA DESEMBOLSOS', '2019-12-04 17:29:44', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'DESEMBOLSO', 8, 3),
(53, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-04 17:30:07', 'ADMINISTRADOR', 'VOUCHER', '26', NULL, 8, 3),
(54, 'INGRESO', '200', 'PARA DESEMBOLSOS', '2019-12-04 18:01:23', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'DESEMBOLSO', 8, 3),
(55, 'EGRESO', '156', 'DESEMBOLSO DE CREDITO', '2019-12-04 18:01:39', 'ADMINISTRADOR', 'VOUCHER', '27', NULL, 8, 3),
(56, 'INGRESO', '1000', 'PARA DESEMBOLSOS', '2019-12-05 17:17:08', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'DESEMBOLSO', 8, 3),
(57, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-12-05 17:17:33', 'ADMINISTRADOR', 'VOUCHER', '28', NULL, 8, 3),
(58, 'EGRESO', '600', 'DESEMBOLSO DE CREDITO', '2019-12-05 18:12:09', 'ADMINISTRADOR', 'VOUCHER', '29', NULL, 8, 3),
(59, 'INGRESO', '300', 'EXTORNO DE DESEMBOLSO', '2019-12-06 14:48:58', 'ADMINISTRADOR', 'VOUCHER', '6', NULL, 8, 2),
(60, 'INGRESO', '300', 'EXTORNO DE DESEMBOLSO', '2019-12-06 14:49:31', 'ADMINISTRADOR', 'VOUCHER', '7', NULL, 8, 2),
(61, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-09 09:58:02', 'ADMINISTRADOR', 'VOUCHER', '31', NULL, 5, 7),
(62, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-09 16:29:10', 'ADMINISTRADOR', 'VOUCHER', '32', NULL, 5, 7),
(63, 'INGRESO', '1000', 'PARA DESEMBOLSOS', '2019-12-09 18:33:03', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'DESEMBOLSO', 5, 7),
(64, 'EGRESO', '800', 'DESEMBOLSO DE CREDITO', '2019-12-09 18:33:14', 'ADMINISTRADOR', 'VOUCHER', '33', NULL, 5, 7),
(65, 'EGRESO', '260', 'DESEMBOLSO DE CREDITO', '2019-12-09 19:19:23', 'ADMINISTRADOR', 'VOUCHER', '34', NULL, 5, 7),
(66, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-10 10:16:28', 'ADMINISTRADOR', 'VOUCHER', '35', NULL, 5, 7),
(67, 'INGRESO', '1000', 'DESEMBOLSO', '2019-12-10 18:24:38', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'DESEMBOLSO\r\n', 8, 3),
(68, 'EGRESO', '1000', 'DESEMBOLSO DE CREDITO', '2019-12-10 18:40:10', 'ADMINISTRADOR', 'VOUCHER', '36', NULL, 8, 3),
(69, 'INGRESO', '2500', 'PARA DESEMBOLSOS', '2019-12-11 11:58:06', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'PARA DESEMBOLSO', 5, 7),
(70, 'EGRESO', '600', 'DESEMBOLSO DE CREDITO', '2019-12-11 11:58:36', 'ADMINISTRADOR', 'VOUCHER', '37', NULL, 5, 7),
(71, 'INGRESO', '1000', 'habilitacion para desembolso', '2019-12-11 17:54:01', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'desembolso', 8, 3),
(72, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-11 17:54:19', 'ADMINISTRADOR', 'VOUCHER', '38', NULL, 8, 3),
(73, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-11 17:57:34', 'ADMINISTRADOR', 'VOUCHER', '39', NULL, 5, 7),
(74, 'EGRESO', '600', 'DESEMBOLSO DE CREDITO', '2019-12-12 16:05:40', 'ADMINISTRADOR', 'VOUCHER', '40', NULL, 5, 7),
(75, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-12-12 17:18:24', 'ADMINISTRADOR', 'VOUCHER', '41', NULL, 8, 3),
(76, 'INGRESO', '500', 'EXTORNO DE DESEMBOLSO', '2019-12-12 17:22:57', 'ADMINISTRADOR', 'VOUCHER', '41', NULL, 8, 2),
(77, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-12-12 17:31:04', 'ADMINISTRADOR', 'VOUCHER', '42', NULL, 8, 3),
(78, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-12-13 10:03:26', 'ADMINISTRADOR', 'VOUCHER', '43', NULL, 5, 7),
(79, 'INGRESO', '2000', 'PARA DESEMBOLSOS', '2019-12-13 16:11:40', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'DESEMBOLSAR', 8, 3),
(80, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-12-13 16:11:55', 'ADMINISTRADOR', 'VOUCHER', '44', NULL, 8, 3),
(81, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-13 18:18:08', 'ADMINISTRADOR', 'VOUCHER', '45', NULL, 8, 3),
(82, 'INGRESO', '2500', 'PARA DESEMBOLSOS', '2019-12-14 13:03:33', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'desembolso', 5, 7),
(83, 'EGRESO', '1500', 'DESEMBOLSO DE CREDITO', '2019-12-14 13:04:27', 'ADMINISTRADOR', 'VOUCHER', '47', NULL, 5, 7),
(84, 'INGRESO', '1000', 'PARA DESEMBOLSOS', '2019-12-17 17:53:30', 'JACKELINE ESTRADA', 'RECIBO', '00006', 'DESEMBOLSO', 8, 3),
(85, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-12-17 17:55:33', 'ADMINISTRADOR', 'VOUCHER', '48', NULL, 8, 3),
(86, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-12-18 15:17:16', 'ADMINISTRADOR', 'VOUCHER', '49', NULL, 8, 3),
(87, 'INGRESO', '400', 'EXTORNO DE DESEMBOLSO', '2019-12-18 15:25:02', 'ADMINISTRADOR', 'VOUCHER', '49', NULL, 5, 2),
(88, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-12-18 15:26:09', 'ADMINISTRADOR', 'VOUCHER', '49', NULL, 8, 3),
(89, 'INGRESO', '400', 'EXTORNO DE DESEMBOLSO', '2019-12-18 15:27:31', 'ADMINISTRADOR', 'VOUCHER', '49', NULL, 8, 2),
(90, 'EGRESO', '400', 'DESEMBOLSO DE CREDITO', '2019-12-18 15:29:23', 'ADMINISTRADOR', 'VOUCHER', '50', NULL, 8, 3),
(91, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-18 17:46:37', 'ADMINISTRADOR', 'VOUCHER', '51', NULL, 8, 3),
(92, 'EGRESO', '500', 'DESEMBOLSO DE CREDITO', '2019-12-18 17:53:09', 'ADMINISTRADOR', 'VOUCHER', '52', NULL, 8, 3),
(93, 'INGRESO', '400', 'EXTORNO DE DESEMBOLSO', '2019-12-18 17:54:26', 'ADMINISTRADOR', 'VOUCHER', '12', NULL, 5, 2),
(94, 'EGRESO', '150', 'DESEMBOLSO DE CREDITO', '2019-12-18 18:34:02', 'ADMINISTRADOR', 'VOUCHER', '53', NULL, 8, 3),
(95, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-19 10:07:18', 'ADMINISTRADOR', 'VOUCHER', '54', NULL, 5, 7),
(96, 'EGRESO', '300', 'DESEMBOLSO DE CREDITO', '2019-12-19 10:17:14', 'ADMINISTRADOR', 'VOUCHER', '55', NULL, 5, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `negocio`
--

CREATE TABLE `negocio` (
  `idnegocio` int(11) NOT NULL,
  `norm_tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `norm_tipo_local` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `norm_tipo_negocio` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tiempo` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `trans_tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_placa` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_empresa` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_soat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_soat_cad` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `trans_tarjeta` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `trans_tarjeta_cad` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `url_croquis` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `clientes_idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `negocio`
--

INSERT INTO `negocio` (`idnegocio`, `norm_tipo`, `norm_tipo_local`, `norm_tipo_negocio`, `tiempo`, `trans_tipo`, `trans_placa`, `trans_empresa`, `trans_direccion`, `trans_soat`, `trans_soat_cad`, `trans_tarjeta`, `trans_tarjeta_cad`, `tipo`, `url_croquis`, `clientes_idcliente`) VALUES
(1, '', '', '', '10 AÑOS ', 'FORMAL', '44398011', 'VIRGO SAC', 'JUSTICIA PAZ Y VIDA - CANCHON ', 'SI', '', 'SI', '', 'TRANSPORTE', NULL, 133);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `idpago` int(11) NOT NULL,
  `n_cuota_programada` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_programada` date NOT NULL,
  `cuota_programada` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `mora` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`idpago`, `n_cuota_programada`, `fecha_programada`, `cuota_programada`, `monto`, `fecha`, `mora`, `creditos_idcredito`, `usuarios_idusuario`) VALUES
(17, '1', '2019-11-26', '17.6', NULL, NULL, '23', 7, NULL),
(18, '2', '2019-11-27', '17.6', NULL, NULL, '22', 7, NULL),
(19, '3', '2019-11-28', '17.6', NULL, NULL, '21', 7, NULL),
(20, '4', '2019-11-29', '17.6', NULL, NULL, '20', 7, NULL),
(21, '5', '2019-11-30', '17.6', NULL, NULL, '19', 7, NULL),
(22, '6', '2019-12-02', '17.6', NULL, NULL, '17', 7, NULL),
(23, '7', '2019-12-03', '17.6', NULL, NULL, '16', 7, NULL),
(24, '8', '2019-12-04', '17.6', NULL, NULL, '15', 7, NULL),
(25, '9', '2019-12-05', '17.6', NULL, NULL, '14', 7, NULL),
(26, '10', '2019-12-06', '17.6', NULL, NULL, '13', 7, NULL),
(27, '11', '2019-12-07', '17.6', NULL, NULL, '12', 7, NULL),
(28, '12', '2019-12-09', '17.6', NULL, NULL, '10', 7, NULL),
(29, '13', '2019-12-10', '17.6', NULL, NULL, '9', 7, NULL),
(30, '14', '2019-12-11', '17.6', NULL, NULL, '8', 7, NULL),
(31, '15', '2019-12-12', '17.6', NULL, NULL, '7', 7, NULL),
(32, '16', '2019-12-13', '17.6', NULL, NULL, '6', 7, NULL),
(33, '17', '2019-12-14', '17.6', NULL, NULL, '5', 7, NULL),
(34, '18', '2019-12-16', '17.6', NULL, NULL, '3', 7, NULL),
(35, '19', '2019-12-17', '17.6', NULL, NULL, '2', 7, NULL),
(36, '20', '2019-12-18', '17.6', NULL, NULL, '1', 7, NULL),
(37, '21', '2019-12-19', '17.6', NULL, NULL, '0', 7, NULL),
(38, '22', '2019-12-20', '17.6', NULL, NULL, '0', 7, NULL),
(39, '23', '2019-12-21', '17.6', NULL, NULL, '0', 7, NULL),
(40, '24', '2019-12-23', '17.6', NULL, NULL, '0', 7, NULL),
(41, '25', '2019-12-26', '17.6', NULL, NULL, '0', 7, NULL),
(42, '1', '2019-11-26', '26.4', '26.4', '2019-11-26 15:33:03', '0', 6, 7),
(43, '2', '2019-11-27', '26.4', NULL, NULL, '22', 6, NULL),
(44, '3', '2019-11-28', '26.4', NULL, NULL, '21', 6, NULL),
(45, '4', '2019-11-29', '26.4', NULL, NULL, '20', 6, NULL),
(46, '5', '2019-11-30', '26.4', NULL, NULL, '19', 6, NULL),
(47, '6', '2019-12-02', '26.4', NULL, NULL, '17', 6, NULL),
(48, '7', '2019-12-03', '26.4', NULL, NULL, '16', 6, NULL),
(49, '8', '2019-12-04', '26.4', NULL, NULL, '15', 6, NULL),
(50, '9', '2019-12-05', '26.4', NULL, NULL, '14', 6, NULL),
(51, '10', '2019-12-06', '26.4', NULL, NULL, '13', 6, NULL),
(52, '11', '2019-12-07', '26.4', NULL, NULL, '12', 6, NULL),
(53, '12', '2019-12-09', '26.4', NULL, NULL, '10', 6, NULL),
(54, '13', '2019-12-10', '26.4', NULL, NULL, '9', 6, NULL),
(55, '14', '2019-12-11', '26.4', NULL, NULL, '8', 6, NULL),
(56, '15', '2019-12-12', '26.4', NULL, NULL, '7', 6, NULL),
(57, '16', '2019-12-13', '26.4', NULL, NULL, '6', 6, NULL),
(58, '17', '2019-12-14', '26.4', NULL, NULL, '5', 6, NULL),
(59, '18', '2019-12-16', '26.4', NULL, NULL, '3', 6, NULL),
(60, '19', '2019-12-17', '26.4', NULL, NULL, '2', 6, NULL),
(61, '20', '2019-12-18', '26.4', NULL, NULL, '1', 6, NULL),
(62, '21', '2019-12-19', '26.4', NULL, NULL, '0', 6, NULL),
(63, '22', '2019-12-20', '26.4', NULL, NULL, '0', 6, NULL),
(64, '23', '2019-12-21', '26.4', NULL, NULL, '0', 6, NULL),
(65, '24', '2019-12-23', '26.4', NULL, NULL, '0', 6, NULL),
(66, '25', '2019-12-26', '26.4', NULL, NULL, '0', 6, NULL),
(67, '1', '2019-11-26', '13.2', '13.2', '2019-11-27 19:32:51', '0', 8, 7),
(68, '2', '2019-11-27', '13.2', NULL, NULL, '22', 8, NULL),
(69, '3', '2019-11-28', '13.2', NULL, NULL, '21', 8, NULL),
(70, '4', '2019-11-29', '13.2', NULL, NULL, '20', 8, NULL),
(71, '5', '2019-11-30', '13.2', NULL, NULL, '19', 8, NULL),
(72, '6', '2019-12-02', '13.2', NULL, NULL, '17', 8, NULL),
(73, '7', '2019-12-03', '13.2', NULL, NULL, '16', 8, NULL),
(74, '8', '2019-12-04', '13.2', NULL, NULL, '15', 8, NULL),
(75, '9', '2019-12-05', '13.2', NULL, NULL, '14', 8, NULL),
(76, '10', '2019-12-06', '13.2', NULL, NULL, '13', 8, NULL),
(77, '11', '2019-12-07', '13.2', NULL, NULL, '12', 8, NULL),
(78, '12', '2019-12-09', '13.2', NULL, NULL, '10', 8, NULL),
(79, '13', '2019-12-10', '13.2', NULL, NULL, '9', 8, NULL),
(80, '14', '2019-12-11', '13.2', NULL, NULL, '8', 8, NULL),
(81, '15', '2019-12-12', '13.2', NULL, NULL, '7', 8, NULL),
(82, '16', '2019-12-13', '13.2', NULL, NULL, '6', 8, NULL),
(83, '17', '2019-12-14', '13.2', NULL, NULL, '5', 8, NULL),
(84, '18', '2019-12-16', '13.2', NULL, NULL, '3', 8, NULL),
(85, '19', '2019-12-17', '13.2', NULL, NULL, '2', 8, NULL),
(86, '20', '2019-12-18', '13.2', NULL, NULL, '1', 8, NULL),
(87, '21', '2019-12-19', '13.2', NULL, NULL, '0', 8, NULL),
(88, '22', '2019-12-20', '13.2', NULL, NULL, '0', 8, NULL),
(89, '23', '2019-12-21', '13.2', NULL, NULL, '0', 8, NULL),
(90, '24', '2019-12-23', '13.2', NULL, NULL, '0', 8, NULL),
(91, '25', '2019-12-26', '13.2', NULL, NULL, '0', 8, NULL),
(117, '1', '2019-11-27', '26.4', '27.4', '2019-11-27 19:32:05', '1', 39, 7),
(118, '2', '2019-11-28', '26.4', NULL, NULL, '21', 39, NULL),
(119, '3', '2019-11-29', '26.4', NULL, NULL, '20', 39, NULL),
(120, '4', '2019-11-30', '26.4', NULL, NULL, '19', 39, NULL),
(121, '5', '2019-12-02', '26.4', NULL, NULL, '17', 39, NULL),
(122, '6', '2019-12-03', '26.4', NULL, NULL, '16', 39, NULL),
(123, '7', '2019-12-04', '26.4', NULL, NULL, '15', 39, NULL),
(124, '8', '2019-12-05', '26.4', NULL, NULL, '14', 39, NULL),
(125, '9', '2019-12-06', '26.4', NULL, NULL, '13', 39, NULL),
(126, '10', '2019-12-07', '26.4', NULL, NULL, '12', 39, NULL),
(127, '11', '2019-12-09', '26.4', NULL, NULL, '10', 39, NULL),
(128, '12', '2019-12-10', '26.4', NULL, NULL, '9', 39, NULL),
(129, '13', '2019-12-11', '26.4', NULL, NULL, '8', 39, NULL),
(130, '14', '2019-12-12', '26.4', NULL, NULL, '7', 39, NULL),
(131, '15', '2019-12-13', '26.4', NULL, NULL, '6', 39, NULL),
(132, '16', '2019-12-14', '26.4', NULL, NULL, '5', 39, NULL),
(133, '17', '2019-12-16', '26.4', NULL, NULL, '3', 39, NULL),
(134, '18', '2019-12-17', '26.4', NULL, NULL, '2', 39, NULL),
(135, '19', '2019-12-18', '26.4', NULL, NULL, '1', 39, NULL),
(136, '20', '2019-12-19', '26.4', NULL, NULL, '0', 39, NULL),
(137, '21', '2019-12-20', '26.4', NULL, NULL, '0', 39, NULL),
(138, '22', '2019-12-21', '26.4', NULL, NULL, '0', 39, NULL),
(139, '23', '2019-12-23', '26.4', NULL, NULL, '0', 39, NULL),
(140, '24', '2019-12-26', '26.4', NULL, NULL, '0', 39, NULL),
(141, '25', '2019-12-27', '26.4', NULL, NULL, '0', 39, NULL),
(167, '1', '2019-11-28', '22', NULL, NULL, '21', 36, NULL),
(168, '2', '2019-11-29', '22', NULL, NULL, '20', 36, NULL),
(169, '3', '2019-11-30', '22', NULL, NULL, '19', 36, NULL),
(170, '4', '2019-12-02', '22', NULL, NULL, '17', 36, NULL),
(171, '5', '2019-12-03', '22', NULL, NULL, '16', 36, NULL),
(172, '6', '2019-12-04', '22', NULL, NULL, '15', 36, NULL),
(173, '7', '2019-12-05', '22', NULL, NULL, '14', 36, NULL),
(174, '8', '2019-12-06', '22', NULL, NULL, '13', 36, NULL),
(175, '9', '2019-12-07', '22', NULL, NULL, '12', 36, NULL),
(176, '10', '2019-12-09', '22', NULL, NULL, '10', 36, NULL),
(177, '11', '2019-12-10', '22', NULL, NULL, '9', 36, NULL),
(178, '12', '2019-12-11', '22', NULL, NULL, '8', 36, NULL),
(179, '13', '2019-12-12', '22', NULL, NULL, '7', 36, NULL),
(180, '14', '2019-12-13', '22', NULL, NULL, '6', 36, NULL),
(181, '15', '2019-12-14', '22', NULL, NULL, '5', 36, NULL),
(182, '16', '2019-12-16', '22', NULL, NULL, '3', 36, NULL),
(183, '17', '2019-12-17', '22', NULL, NULL, '2', 36, NULL),
(184, '18', '2019-12-18', '22', NULL, NULL, '1', 36, NULL),
(185, '19', '2019-12-19', '22', NULL, NULL, '0', 36, NULL),
(186, '20', '2019-12-20', '22', NULL, NULL, '0', 36, NULL),
(187, '21', '2019-12-21', '22', NULL, NULL, '0', 36, NULL),
(188, '22', '2019-12-23', '22', NULL, NULL, '0', 36, NULL),
(189, '23', '2019-12-26', '22', NULL, NULL, '0', 36, NULL),
(190, '24', '2019-12-27', '22', NULL, NULL, '0', 36, NULL),
(191, '25', '2019-12-28', '22', NULL, NULL, '0', 36, NULL),
(210, '1', '2019-11-29', '17.6', NULL, NULL, '20', 44, NULL),
(211, '2', '2019-11-30', '17.6', NULL, NULL, '19', 44, NULL),
(212, '3', '2019-12-02', '17.6', NULL, NULL, '17', 44, NULL),
(213, '4', '2019-12-03', '17.6', NULL, NULL, '16', 44, NULL),
(214, '5', '2019-12-04', '17.6', NULL, NULL, '15', 44, NULL),
(215, '6', '2019-12-05', '17.6', NULL, NULL, '14', 44, NULL),
(216, '7', '2019-12-06', '17.6', NULL, NULL, '13', 44, NULL),
(217, '8', '2019-12-07', '17.6', NULL, NULL, '12', 44, NULL),
(218, '9', '2019-12-09', '17.6', NULL, NULL, '10', 44, NULL),
(219, '10', '2019-12-10', '17.6', NULL, NULL, '9', 44, NULL),
(220, '11', '2019-12-11', '17.6', NULL, NULL, '8', 44, NULL),
(221, '12', '2019-12-12', '17.6', NULL, NULL, '7', 44, NULL),
(222, '13', '2019-12-13', '17.6', NULL, NULL, '6', 44, NULL),
(223, '14', '2019-12-14', '17.6', NULL, NULL, '5', 44, NULL),
(224, '15', '2019-12-16', '17.6', NULL, NULL, '3', 44, NULL),
(225, '16', '2019-12-17', '17.6', NULL, NULL, '2', 44, NULL),
(226, '17', '2019-12-18', '17.6', NULL, NULL, '1', 44, NULL),
(227, '18', '2019-12-19', '17.6', NULL, NULL, '0', 44, NULL),
(228, '19', '2019-12-20', '17.6', NULL, NULL, '0', 44, NULL),
(229, '20', '2019-12-21', '17.6', NULL, NULL, '0', 44, NULL),
(230, '21', '2019-12-23', '17.6', NULL, NULL, '0', 44, NULL),
(231, '22', '2019-12-26', '17.6', NULL, NULL, '0', 44, NULL),
(232, '23', '2019-12-27', '17.6', NULL, NULL, '0', 44, NULL),
(233, '24', '2019-12-28', '17.6', NULL, NULL, '0', 44, NULL),
(234, '25', '2019-12-30', '17.6', NULL, NULL, '0', 44, NULL),
(235, '1', '2019-11-28', '13.2', NULL, NULL, '21', 35, NULL),
(236, '2', '2019-11-29', '13.2', NULL, NULL, '20', 35, NULL),
(237, '3', '2019-11-30', '13.2', NULL, NULL, '19', 35, NULL),
(238, '4', '2019-12-02', '13.2', NULL, NULL, '17', 35, NULL),
(239, '5', '2019-12-03', '13.2', NULL, NULL, '16', 35, NULL),
(240, '6', '2019-12-04', '13.2', NULL, NULL, '15', 35, NULL),
(241, '7', '2019-12-05', '13.2', NULL, NULL, '14', 35, NULL),
(242, '8', '2019-12-06', '13.2', NULL, NULL, '13', 35, NULL),
(243, '9', '2019-12-07', '13.2', NULL, NULL, '12', 35, NULL),
(244, '10', '2019-12-09', '13.2', NULL, NULL, '10', 35, NULL),
(245, '11', '2019-12-10', '13.2', NULL, NULL, '9', 35, NULL),
(246, '12', '2019-12-11', '13.2', NULL, NULL, '8', 35, NULL),
(247, '13', '2019-12-12', '13.2', NULL, NULL, '7', 35, NULL),
(248, '14', '2019-12-13', '13.2', NULL, NULL, '6', 35, NULL),
(249, '15', '2019-12-14', '13.2', NULL, NULL, '5', 35, NULL),
(250, '16', '2019-12-16', '13.2', NULL, NULL, '3', 35, NULL),
(251, '17', '2019-12-17', '13.2', NULL, NULL, '2', 35, NULL),
(252, '18', '2019-12-18', '13.2', NULL, NULL, '1', 35, NULL),
(253, '19', '2019-12-19', '13.2', NULL, NULL, '0', 35, NULL),
(254, '20', '2019-12-20', '13.2', NULL, NULL, '0', 35, NULL),
(255, '21', '2019-12-21', '13.2', NULL, NULL, '0', 35, NULL),
(256, '22', '2019-12-23', '13.2', NULL, NULL, '0', 35, NULL),
(257, '23', '2019-12-26', '13.2', NULL, NULL, '0', 35, NULL),
(258, '24', '2019-12-27', '13.2', NULL, NULL, '0', 35, NULL),
(259, '25', '2019-12-28', '13.2', NULL, NULL, '0', 35, NULL),
(260, '1', '2019-12-05', '120', NULL, NULL, '14', 45, NULL),
(261, '2', '2019-12-13', '120', NULL, NULL, '6', 45, NULL),
(262, '3', '2019-12-21', '120', NULL, NULL, '0', 45, NULL),
(263, '4', '2020-01-01', '120', NULL, NULL, '0', 45, NULL),
(264, '5', '2020-01-09', '120', NULL, NULL, '0', 45, NULL),
(265, '6', '2020-01-17', '120', NULL, NULL, '0', 45, NULL),
(266, '7', '2020-01-25', '120', NULL, NULL, '0', 45, NULL),
(267, '8', '2020-02-03', '120', NULL, NULL, '0', 45, NULL),
(268, '1', '2019-12-05', '45', NULL, NULL, '14', 46, NULL),
(269, '2', '2019-12-13', '45', NULL, NULL, '6', 46, NULL),
(270, '3', '2019-12-21', '45', NULL, NULL, '0', 46, NULL),
(271, '4', '2020-01-01', '45', NULL, NULL, '0', 46, NULL),
(272, '5', '2020-01-09', '45', NULL, NULL, '0', 46, NULL),
(273, '6', '2020-01-17', '45', NULL, NULL, '0', 46, NULL),
(274, '7', '2020-01-25', '45', NULL, NULL, '0', 46, NULL),
(275, '8', '2020-02-03', '45', NULL, NULL, '0', 46, NULL),
(276, '1', '2019-11-29', '13.2', NULL, NULL, '20', 40, NULL),
(277, '2', '2019-11-30', '13.2', NULL, NULL, '19', 40, NULL),
(278, '3', '2019-12-02', '13.2', NULL, NULL, '17', 40, NULL),
(279, '4', '2019-12-03', '13.2', NULL, NULL, '16', 40, NULL),
(280, '5', '2019-12-04', '13.2', NULL, NULL, '15', 40, NULL),
(281, '6', '2019-12-05', '13.2', NULL, NULL, '14', 40, NULL),
(282, '7', '2019-12-06', '13.2', NULL, NULL, '13', 40, NULL),
(283, '8', '2019-12-07', '13.2', NULL, NULL, '12', 40, NULL),
(284, '9', '2019-12-09', '13.2', NULL, NULL, '10', 40, NULL),
(285, '10', '2019-12-10', '13.2', NULL, NULL, '9', 40, NULL),
(286, '11', '2019-12-11', '13.2', NULL, NULL, '8', 40, NULL),
(287, '12', '2019-12-12', '13.2', NULL, NULL, '7', 40, NULL),
(288, '13', '2019-12-13', '13.2', NULL, NULL, '6', 40, NULL),
(289, '14', '2019-12-14', '13.2', NULL, NULL, '5', 40, NULL),
(290, '15', '2019-12-16', '13.2', NULL, NULL, '3', 40, NULL),
(291, '16', '2019-12-17', '13.2', NULL, NULL, '2', 40, NULL),
(292, '17', '2019-12-18', '13.2', NULL, NULL, '1', 40, NULL),
(293, '18', '2019-12-19', '13.2', NULL, NULL, '0', 40, NULL),
(294, '19', '2019-12-20', '13.2', NULL, NULL, '0', 40, NULL),
(295, '20', '2019-12-21', '13.2', NULL, NULL, '0', 40, NULL),
(296, '21', '2019-12-23', '13.2', NULL, NULL, '0', 40, NULL),
(297, '22', '2019-12-26', '13.2', NULL, NULL, '0', 40, NULL),
(298, '23', '2019-12-27', '13.2', NULL, NULL, '0', 40, NULL),
(299, '24', '2019-12-28', '13.2', NULL, NULL, '0', 40, NULL),
(300, '25', '2019-12-30', '13.2', NULL, NULL, '0', 40, NULL),
(301, '1', '2019-12-07', '137.5', NULL, NULL, '12', 50, NULL),
(302, '2', '2019-12-16', '137.5', NULL, NULL, '3', 50, NULL),
(303, '3', '2019-12-26', '137.5', NULL, NULL, '0', 50, NULL),
(304, '4', '2020-01-03', '137.5', NULL, NULL, '0', 50, NULL),
(305, '1', '2019-12-07', '68.8', NULL, NULL, '12', 51, NULL),
(306, '2', '2019-12-16', '68.8', NULL, NULL, '3', 51, NULL),
(307, '3', '2019-12-26', '68.8', NULL, NULL, '0', 51, NULL),
(308, '4', '2020-01-03', '68.8', NULL, NULL, '0', 51, NULL),
(309, '1', '2019-11-30', '15.7', NULL, NULL, '19', 52, NULL),
(310, '2', '2019-12-02', '15.7', NULL, NULL, '17', 52, NULL),
(311, '3', '2019-12-03', '15.7', NULL, NULL, '16', 52, NULL),
(312, '4', '2019-12-04', '15.7', NULL, NULL, '15', 52, NULL),
(313, '5', '2019-12-05', '15.7', NULL, NULL, '14', 52, NULL),
(314, '6', '2019-12-06', '15.7', NULL, NULL, '13', 52, NULL),
(315, '7', '2019-12-07', '15.7', NULL, NULL, '12', 52, NULL),
(316, '8', '2019-12-09', '15.7', NULL, NULL, '10', 52, NULL),
(317, '9', '2019-12-10', '15.7', NULL, NULL, '9', 52, NULL),
(318, '10', '2019-12-11', '15.7', NULL, NULL, '8', 52, NULL),
(319, '11', '2019-12-12', '15.7', NULL, NULL, '7', 52, NULL),
(320, '12', '2019-12-13', '15.7', NULL, NULL, '6', 52, NULL),
(321, '13', '2019-12-14', '15.7', NULL, NULL, '5', 52, NULL),
(322, '14', '2019-12-16', '15.7', NULL, NULL, '3', 52, NULL),
(323, '15', '2019-12-17', '15.7', NULL, NULL, '2', 52, NULL),
(324, '16', '2019-12-18', '15.7', NULL, NULL, '1', 52, NULL),
(325, '17', '2019-12-19', '15.7', NULL, NULL, '0', 52, NULL),
(326, '18', '2019-12-20', '15.7', NULL, NULL, '0', 52, NULL),
(327, '19', '2019-12-21', '15.7', NULL, NULL, '0', 52, NULL),
(328, '20', '2019-12-23', '15.7', NULL, NULL, '0', 52, NULL),
(329, '21', '2019-12-26', '15.7', NULL, NULL, '0', 52, NULL),
(330, '22', '2019-12-27', '15.7', NULL, NULL, '0', 52, NULL),
(331, '23', '2019-12-28', '15.7', NULL, NULL, '0', 52, NULL),
(332, '24', '2019-12-30', '15.7', NULL, NULL, '0', 52, NULL),
(333, '25', '2019-12-31', '15.7', NULL, NULL, '0', 52, NULL),
(334, '1', '2019-11-30', '19.4', NULL, NULL, '19', 53, NULL),
(335, '2', '2019-12-02', '19.4', NULL, NULL, '17', 53, NULL),
(336, '3', '2019-12-03', '19.4', NULL, NULL, '16', 53, NULL),
(337, '4', '2019-12-04', '19.4', NULL, NULL, '15', 53, NULL),
(338, '5', '2019-12-05', '19.4', NULL, NULL, '14', 53, NULL),
(339, '6', '2019-12-06', '19.4', NULL, NULL, '13', 53, NULL),
(340, '7', '2019-12-07', '19.4', NULL, NULL, '12', 53, NULL),
(341, '8', '2019-12-09', '19.4', NULL, NULL, '10', 53, NULL),
(342, '9', '2019-12-10', '19.4', NULL, NULL, '9', 53, NULL),
(343, '10', '2019-12-11', '19.4', NULL, NULL, '8', 53, NULL),
(344, '11', '2019-12-12', '19.4', NULL, NULL, '7', 53, NULL),
(345, '12', '2019-12-13', '19.4', NULL, NULL, '6', 53, NULL),
(346, '13', '2019-12-14', '19.4', NULL, NULL, '5', 53, NULL),
(347, '14', '2019-12-16', '19.4', NULL, NULL, '3', 53, NULL),
(348, '15', '2019-12-17', '19.4', NULL, NULL, '2', 53, NULL),
(349, '16', '2019-12-18', '19.4', NULL, NULL, '1', 53, NULL),
(350, '17', '2019-12-19', '19.4', NULL, NULL, '0', 53, NULL),
(351, '18', '2019-12-20', '19.4', NULL, NULL, '0', 53, NULL),
(352, '19', '2019-12-21', '19.4', NULL, NULL, '0', 53, NULL),
(353, '20', '2019-12-23', '19.4', NULL, NULL, '0', 53, NULL),
(354, '21', '2019-12-26', '19.4', NULL, NULL, '0', 53, NULL),
(355, '22', '2019-12-27', '19.4', NULL, NULL, '0', 53, NULL),
(356, '23', '2019-12-28', '19.4', NULL, NULL, '0', 53, NULL),
(357, '24', '2019-12-30', '19.4', NULL, NULL, '0', 53, NULL),
(358, '25', '2019-12-31', '19.4', NULL, NULL, '0', 53, NULL),
(359, '1', '2019-11-30', '22', NULL, NULL, '19', 47, NULL),
(360, '2', '2019-12-02', '22', NULL, NULL, '17', 47, NULL),
(361, '3', '2019-12-03', '22', NULL, NULL, '16', 47, NULL),
(362, '4', '2019-12-04', '22', NULL, NULL, '15', 47, NULL),
(363, '5', '2019-12-05', '22', NULL, NULL, '14', 47, NULL),
(364, '6', '2019-12-06', '22', NULL, NULL, '13', 47, NULL),
(365, '7', '2019-12-07', '22', NULL, NULL, '12', 47, NULL),
(366, '8', '2019-12-09', '22', NULL, NULL, '10', 47, NULL),
(367, '9', '2019-12-10', '22', NULL, NULL, '9', 47, NULL),
(368, '10', '2019-12-11', '22', NULL, NULL, '8', 47, NULL),
(369, '11', '2019-12-12', '22', NULL, NULL, '7', 47, NULL),
(370, '12', '2019-12-13', '22', NULL, NULL, '6', 47, NULL),
(371, '13', '2019-12-14', '22', NULL, NULL, '5', 47, NULL),
(372, '14', '2019-12-16', '22', NULL, NULL, '3', 47, NULL),
(373, '15', '2019-12-17', '22', NULL, NULL, '2', 47, NULL),
(374, '16', '2019-12-18', '22', NULL, NULL, '1', 47, NULL),
(375, '17', '2019-12-19', '22', NULL, NULL, '0', 47, NULL),
(376, '18', '2019-12-20', '22', NULL, NULL, '0', 47, NULL),
(377, '19', '2019-12-21', '22', NULL, NULL, '0', 47, NULL),
(378, '20', '2019-12-23', '22', NULL, NULL, '0', 47, NULL),
(379, '21', '2019-12-26', '22', NULL, NULL, '0', 47, NULL),
(380, '22', '2019-12-27', '22', NULL, NULL, '0', 47, NULL),
(381, '23', '2019-12-28', '22', NULL, NULL, '0', 47, NULL),
(382, '24', '2019-12-30', '22', NULL, NULL, '0', 47, NULL),
(383, '25', '2019-12-31', '22', NULL, NULL, '0', 47, NULL),
(384, '1', '2019-12-14', '165', NULL, NULL, '5', 54, NULL),
(385, '2', '2020-01-03', '165', NULL, NULL, '0', 54, NULL),
(386, '1', '2019-12-02', '26.4', NULL, NULL, '17', 43, NULL),
(387, '2', '2019-12-03', '26.4', NULL, NULL, '16', 43, NULL),
(388, '3', '2019-12-04', '26.4', NULL, NULL, '15', 43, NULL),
(389, '4', '2019-12-05', '26.4', NULL, NULL, '14', 43, NULL),
(390, '5', '2019-12-06', '26.4', NULL, NULL, '13', 43, NULL),
(391, '6', '2019-12-07', '26.4', NULL, NULL, '12', 43, NULL),
(392, '7', '2019-12-09', '26.4', NULL, NULL, '10', 43, NULL),
(393, '8', '2019-12-10', '26.4', NULL, NULL, '9', 43, NULL),
(394, '9', '2019-12-11', '26.4', NULL, NULL, '8', 43, NULL),
(395, '10', '2019-12-12', '26.4', NULL, NULL, '7', 43, NULL),
(396, '11', '2019-12-13', '26.4', NULL, NULL, '6', 43, NULL),
(397, '12', '2019-12-14', '26.4', NULL, NULL, '5', 43, NULL),
(398, '13', '2019-12-16', '26.4', NULL, NULL, '3', 43, NULL),
(399, '14', '2019-12-17', '26.4', NULL, NULL, '2', 43, NULL),
(400, '15', '2019-12-18', '26.4', NULL, NULL, '1', 43, NULL),
(401, '16', '2019-12-19', '26.4', NULL, NULL, '0', 43, NULL),
(402, '17', '2019-12-20', '26.4', NULL, NULL, '0', 43, NULL),
(403, '18', '2019-12-21', '26.4', NULL, NULL, '0', 43, NULL),
(404, '19', '2019-12-23', '26.4', NULL, NULL, '0', 43, NULL),
(405, '20', '2019-12-26', '26.4', NULL, NULL, '0', 43, NULL),
(406, '21', '2019-12-27', '26.4', NULL, NULL, '0', 43, NULL),
(407, '22', '2019-12-28', '26.4', NULL, NULL, '0', 43, NULL),
(408, '23', '2019-12-30', '26.4', NULL, NULL, '0', 43, NULL),
(409, '24', '2019-12-31', '26.4', NULL, NULL, '0', 43, NULL),
(410, '25', '2020-01-01', '26.4', NULL, NULL, '0', 43, NULL),
(411, '1', '2019-12-14', '50', NULL, NULL, '5', 57, NULL),
(412, '2', '2019-12-23', '50', NULL, NULL, '0', 57, NULL),
(413, '3', '2020-01-02', '50', NULL, NULL, '0', 57, NULL),
(414, '4', '2020-01-10', '50', NULL, NULL, '0', 57, NULL),
(415, '1', '2019-12-05', '33.6', NULL, NULL, '14', 58, NULL),
(416, '2', '2019-12-06', '33.6', NULL, NULL, '13', 58, NULL),
(417, '3', '2019-12-07', '33.6', NULL, NULL, '12', 58, NULL),
(418, '4', '2019-12-09', '33.6', NULL, NULL, '10', 58, NULL),
(419, '5', '2019-12-10', '33.6', NULL, NULL, '9', 58, NULL),
(420, '6', '2019-12-11', '33.6', NULL, NULL, '8', 58, NULL),
(421, '7', '2019-12-12', '33.6', NULL, NULL, '7', 58, NULL),
(422, '8', '2019-12-13', '33.6', NULL, NULL, '6', 58, NULL),
(423, '9', '2019-12-14', '33.6', NULL, NULL, '5', 58, NULL),
(424, '10', '2019-12-16', '33.6', NULL, NULL, '3', 58, NULL),
(425, '11', '2019-12-17', '33.6', NULL, NULL, '2', 58, NULL),
(426, '12', '2019-12-18', '33.6', NULL, NULL, '1', 58, NULL),
(427, '13', '2019-12-19', '33.6', NULL, NULL, '0', 58, NULL),
(428, '14', '2019-12-20', '33.6', NULL, NULL, '0', 58, NULL),
(429, '15', '2019-12-21', '33.6', NULL, NULL, '0', 58, NULL),
(430, '16', '2019-12-23', '33.6', NULL, NULL, '0', 58, NULL),
(431, '17', '2019-12-26', '33.6', NULL, NULL, '0', 58, NULL),
(432, '18', '2019-12-27', '33.6', NULL, NULL, '0', 58, NULL),
(433, '19', '2019-12-28', '33.6', NULL, NULL, '0', 58, NULL),
(434, '20', '2019-12-30', '33.6', NULL, NULL, '0', 58, NULL),
(435, '21', '2019-12-31', '33.6', NULL, NULL, '0', 58, NULL),
(436, '22', '2020-01-01', '33.6', NULL, NULL, '0', 58, NULL),
(437, '23', '2020-01-02', '33.6', NULL, NULL, '0', 58, NULL),
(438, '24', '2020-01-03', '33.6', NULL, NULL, '0', 58, NULL),
(439, '25', '2020-01-04', '33.6', NULL, NULL, '0', 58, NULL),
(440, '1', '2019-12-05', '13.2', NULL, NULL, '14', 55, NULL),
(441, '2', '2019-12-06', '13.2', NULL, NULL, '13', 55, NULL),
(442, '3', '2019-12-07', '13.2', NULL, NULL, '12', 55, NULL),
(443, '4', '2019-12-09', '13.2', NULL, NULL, '10', 55, NULL),
(444, '5', '2019-12-10', '13.2', NULL, NULL, '9', 55, NULL),
(445, '6', '2019-12-11', '13.2', NULL, NULL, '8', 55, NULL),
(446, '7', '2019-12-12', '13.2', NULL, NULL, '7', 55, NULL),
(447, '8', '2019-12-13', '13.2', NULL, NULL, '6', 55, NULL),
(448, '9', '2019-12-14', '13.2', NULL, NULL, '5', 55, NULL),
(449, '10', '2019-12-16', '13.2', NULL, NULL, '3', 55, NULL),
(450, '11', '2019-12-17', '13.2', NULL, NULL, '2', 55, NULL),
(451, '12', '2019-12-18', '13.2', NULL, NULL, '1', 55, NULL),
(452, '13', '2019-12-19', '13.2', NULL, NULL, '0', 55, NULL),
(453, '14', '2019-12-20', '13.2', NULL, NULL, '0', 55, NULL),
(454, '15', '2019-12-21', '13.2', NULL, NULL, '0', 55, NULL),
(455, '16', '2019-12-23', '13.2', NULL, NULL, '0', 55, NULL),
(456, '17', '2019-12-26', '13.2', NULL, NULL, '0', 55, NULL),
(457, '18', '2019-12-27', '13.2', NULL, NULL, '0', 55, NULL),
(458, '19', '2019-12-28', '13.2', NULL, NULL, '0', 55, NULL),
(459, '20', '2019-12-30', '13.2', NULL, NULL, '0', 55, NULL),
(460, '21', '2019-12-31', '13.2', NULL, NULL, '0', 55, NULL),
(461, '22', '2020-01-01', '13.2', NULL, NULL, '0', 55, NULL),
(462, '23', '2020-01-02', '13.2', NULL, NULL, '0', 55, NULL),
(463, '24', '2020-01-03', '13.2', NULL, NULL, '0', 55, NULL),
(464, '25', '2020-01-04', '13.2', NULL, NULL, '0', 55, NULL),
(465, '1', '2019-12-05', '10.1', NULL, NULL, '14', 61, NULL),
(466, '2', '2019-12-06', '10.1', NULL, NULL, '13', 61, NULL),
(467, '3', '2019-12-07', '10.1', NULL, NULL, '12', 61, NULL),
(468, '4', '2019-12-09', '10.1', NULL, NULL, '10', 61, NULL),
(469, '5', '2019-12-10', '10.1', NULL, NULL, '9', 61, NULL),
(470, '6', '2019-12-11', '10.1', NULL, NULL, '8', 61, NULL),
(471, '7', '2019-12-12', '10.1', NULL, NULL, '7', 61, NULL),
(472, '8', '2019-12-13', '10.1', NULL, NULL, '6', 61, NULL),
(473, '9', '2019-12-14', '10.1', NULL, NULL, '5', 61, NULL),
(474, '10', '2019-12-16', '10.1', NULL, NULL, '3', 61, NULL),
(475, '11', '2019-12-17', '10.1', NULL, NULL, '2', 61, NULL),
(476, '12', '2019-12-18', '10.1', NULL, NULL, '1', 61, NULL),
(477, '13', '2019-12-19', '10.1', NULL, NULL, '0', 61, NULL),
(478, '14', '2019-12-20', '10.1', NULL, NULL, '0', 61, NULL),
(479, '15', '2019-12-21', '10.1', NULL, NULL, '0', 61, NULL),
(480, '16', '2019-12-23', '10.1', NULL, NULL, '0', 61, NULL),
(481, '17', '2019-12-26', '10.1', NULL, NULL, '0', 61, NULL),
(482, '1', '2019-12-06', '17.6', NULL, NULL, '13', 64, NULL),
(483, '2', '2019-12-07', '17.6', NULL, NULL, '12', 64, NULL),
(484, '3', '2019-12-09', '17.6', NULL, NULL, '10', 64, NULL),
(485, '4', '2019-12-10', '17.6', NULL, NULL, '9', 64, NULL),
(486, '5', '2019-12-11', '17.6', NULL, NULL, '8', 64, NULL),
(487, '6', '2019-12-12', '17.6', NULL, NULL, '7', 64, NULL),
(488, '7', '2019-12-13', '17.6', NULL, NULL, '6', 64, NULL),
(489, '8', '2019-12-14', '17.6', NULL, NULL, '5', 64, NULL),
(490, '9', '2019-12-16', '17.6', NULL, NULL, '3', 64, NULL),
(491, '10', '2019-12-17', '17.6', NULL, NULL, '2', 64, NULL),
(492, '11', '2019-12-18', '17.6', NULL, NULL, '1', 64, NULL),
(493, '12', '2019-12-19', '17.6', NULL, NULL, '0', 64, NULL),
(494, '13', '2019-12-20', '17.6', NULL, NULL, '0', 64, NULL),
(495, '14', '2019-12-21', '17.6', NULL, NULL, '0', 64, NULL),
(496, '15', '2019-12-23', '17.6', NULL, NULL, '0', 64, NULL),
(497, '16', '2019-12-26', '17.6', NULL, NULL, '0', 64, NULL),
(498, '17', '2019-12-27', '17.6', NULL, NULL, '0', 64, NULL),
(499, '18', '2019-12-28', '17.6', NULL, NULL, '0', 64, NULL),
(500, '19', '2019-12-30', '17.6', NULL, NULL, '0', 64, NULL),
(501, '20', '2019-12-31', '17.6', NULL, NULL, '0', 64, NULL),
(502, '21', '2020-01-01', '17.6', NULL, NULL, '0', 64, NULL),
(503, '22', '2020-01-02', '17.6', NULL, NULL, '0', 64, NULL),
(504, '23', '2020-01-03', '17.6', NULL, NULL, '0', 64, NULL),
(505, '24', '2020-01-04', '17.6', NULL, NULL, '0', 64, NULL),
(506, '25', '2020-01-06', '17.6', NULL, NULL, '0', 64, NULL),
(507, '1', '2019-12-12', '165', NULL, NULL, '7', 62, NULL),
(508, '2', '2019-12-19', '165', NULL, NULL, '0', 62, NULL),
(509, '3', '2019-12-28', '165', NULL, NULL, '0', 62, NULL),
(510, '4', '2020-01-04', '165', NULL, NULL, '0', 62, NULL),
(511, '1', '2019-12-10', '13.2', NULL, NULL, '9', 66, NULL),
(512, '2', '2019-12-11', '13.2', NULL, NULL, '8', 66, NULL),
(513, '3', '2019-12-12', '13.2', NULL, NULL, '7', 66, NULL),
(514, '4', '2019-12-13', '13.2', NULL, NULL, '6', 66, NULL),
(515, '5', '2019-12-14', '13.2', NULL, NULL, '5', 66, NULL),
(516, '6', '2019-12-16', '13.2', NULL, NULL, '3', 66, NULL),
(517, '7', '2019-12-17', '13.2', NULL, NULL, '2', 66, NULL),
(518, '8', '2019-12-18', '13.2', NULL, NULL, '1', 66, NULL),
(519, '9', '2019-12-19', '13.2', NULL, NULL, '0', 66, NULL),
(520, '10', '2019-12-20', '13.2', NULL, NULL, '0', 66, NULL),
(521, '11', '2019-12-21', '13.2', NULL, NULL, '0', 66, NULL),
(522, '12', '2019-12-23', '13.2', NULL, NULL, '0', 66, NULL),
(523, '13', '2019-12-26', '13.2', NULL, NULL, '0', 66, NULL),
(524, '14', '2019-12-27', '13.2', NULL, NULL, '0', 66, NULL),
(525, '15', '2019-12-28', '13.2', NULL, NULL, '0', 66, NULL),
(526, '16', '2019-12-30', '13.2', NULL, NULL, '0', 66, NULL),
(527, '17', '2019-12-31', '13.2', NULL, NULL, '0', 66, NULL),
(528, '18', '2020-01-01', '13.2', NULL, NULL, '0', 66, NULL),
(529, '19', '2020-01-02', '13.2', NULL, NULL, '0', 66, NULL),
(530, '20', '2020-01-03', '13.2', NULL, NULL, '0', 66, NULL),
(531, '21', '2020-01-04', '13.2', NULL, NULL, '0', 66, NULL),
(532, '22', '2020-01-06', '13.2', NULL, NULL, '0', 66, NULL),
(533, '23', '2020-01-07', '13.2', NULL, NULL, '0', 66, NULL),
(534, '24', '2020-01-08', '13.2', NULL, NULL, '0', 66, NULL),
(535, '25', '2020-01-09', '13.2', NULL, NULL, '0', 66, NULL),
(536, '1', '2019-12-10', '13.2', NULL, NULL, '9', 65, NULL),
(537, '2', '2019-12-11', '13.2', NULL, NULL, '8', 65, NULL),
(538, '3', '2019-12-12', '13.2', NULL, NULL, '7', 65, NULL),
(539, '4', '2019-12-13', '13.2', NULL, NULL, '6', 65, NULL),
(540, '5', '2019-12-14', '13.2', NULL, NULL, '5', 65, NULL),
(541, '6', '2019-12-16', '13.2', NULL, NULL, '3', 65, NULL),
(542, '7', '2019-12-17', '13.2', NULL, NULL, '2', 65, NULL),
(543, '8', '2019-12-18', '13.2', NULL, NULL, '1', 65, NULL),
(544, '9', '2019-12-19', '13.2', NULL, NULL, '0', 65, NULL),
(545, '10', '2019-12-20', '13.2', NULL, NULL, '0', 65, NULL),
(546, '11', '2019-12-21', '13.2', NULL, NULL, '0', 65, NULL),
(547, '12', '2019-12-23', '13.2', NULL, NULL, '0', 65, NULL),
(548, '13', '2019-12-26', '13.2', NULL, NULL, '0', 65, NULL),
(549, '14', '2019-12-27', '13.2', NULL, NULL, '0', 65, NULL),
(550, '15', '2019-12-28', '13.2', NULL, NULL, '0', 65, NULL),
(551, '16', '2019-12-30', '13.2', NULL, NULL, '0', 65, NULL),
(552, '17', '2019-12-31', '13.2', NULL, NULL, '0', 65, NULL),
(553, '18', '2020-01-01', '13.2', NULL, NULL, '0', 65, NULL),
(554, '19', '2020-01-02', '13.2', NULL, NULL, '0', 65, NULL),
(555, '20', '2020-01-03', '13.2', NULL, NULL, '0', 65, NULL),
(556, '21', '2020-01-04', '13.2', NULL, NULL, '0', 65, NULL),
(557, '22', '2020-01-06', '13.2', NULL, NULL, '0', 65, NULL),
(558, '23', '2020-01-07', '13.2', NULL, NULL, '0', 65, NULL),
(559, '24', '2020-01-08', '13.2', NULL, NULL, '0', 65, NULL),
(560, '25', '2020-01-09', '13.2', NULL, NULL, '0', 65, NULL),
(561, '1', '2019-12-10', '23', NULL, NULL, '9', 60, NULL),
(562, '2', '2019-12-11', '23', NULL, NULL, '8', 60, NULL),
(563, '3', '2019-12-12', '23', NULL, NULL, '7', 60, NULL),
(564, '4', '2019-12-13', '23', NULL, NULL, '6', 60, NULL),
(565, '5', '2019-12-14', '23', NULL, NULL, '5', 60, NULL),
(566, '6', '2019-12-16', '23', NULL, NULL, '3', 60, NULL),
(567, '7', '2019-12-17', '23', NULL, NULL, '2', 60, NULL),
(568, '8', '2019-12-18', '23', NULL, NULL, '1', 60, NULL),
(569, '9', '2019-12-19', '23', NULL, NULL, '0', 60, NULL),
(570, '10', '2019-12-20', '23', NULL, NULL, '0', 60, NULL),
(571, '11', '2019-12-21', '23', NULL, NULL, '0', 60, NULL),
(572, '12', '2019-12-23', '23', NULL, NULL, '0', 60, NULL),
(573, '13', '2019-12-26', '23', NULL, NULL, '0', 60, NULL),
(574, '14', '2019-12-27', '23', NULL, NULL, '0', 60, NULL),
(575, '15', '2019-12-28', '23', NULL, NULL, '0', 60, NULL),
(576, '16', '2019-12-30', '23', NULL, NULL, '0', 60, NULL),
(577, '17', '2019-12-31', '23', NULL, NULL, '0', 60, NULL),
(578, '18', '2020-01-01', '23', NULL, NULL, '0', 60, NULL),
(579, '19', '2020-01-02', '23', NULL, NULL, '0', 60, NULL),
(580, '20', '2020-01-03', '23', NULL, NULL, '0', 60, NULL),
(581, '21', '2020-01-04', '23', NULL, NULL, '0', 60, NULL),
(582, '22', '2020-01-06', '23', NULL, NULL, '0', 60, NULL),
(583, '23', '2020-01-07', '23', NULL, NULL, '0', 60, NULL),
(584, '24', '2020-01-08', '23', NULL, NULL, '0', 60, NULL),
(585, '25', '2020-01-09', '23', NULL, NULL, '0', 60, NULL),
(586, '26', '2020-01-10', '23', NULL, NULL, '0', 60, NULL),
(587, '27', '2020-01-11', '23', NULL, NULL, '0', 60, NULL),
(588, '28', '2020-01-13', '23', NULL, NULL, '0', 60, NULL),
(589, '29', '2020-01-14', '23', NULL, NULL, '0', 60, NULL),
(590, '30', '2020-01-15', '23', NULL, NULL, '0', 60, NULL),
(591, '31', '2020-01-16', '23', NULL, NULL, '0', 60, NULL),
(592, '32', '2020-01-17', '23', NULL, NULL, '0', 60, NULL),
(593, '33', '2020-01-18', '23', NULL, NULL, '0', 60, NULL),
(594, '34', '2020-01-20', '23', NULL, NULL, '0', 60, NULL),
(595, '35', '2020-01-21', '23', NULL, NULL, '0', 60, NULL),
(596, '36', '2020-01-22', '23', NULL, NULL, '0', 60, NULL),
(597, '37', '2020-01-23', '23', NULL, NULL, '0', 60, NULL),
(598, '38', '2020-01-24', '23', NULL, NULL, '0', 60, NULL),
(599, '39', '2020-01-25', '23', NULL, NULL, '0', 60, NULL),
(600, '40', '2020-01-27', '23', NULL, NULL, '0', 60, NULL),
(601, '1', '2019-12-23', '104', NULL, NULL, '0', 70, NULL),
(602, '2', '2020-01-09', '104', NULL, NULL, '0', 70, NULL),
(603, '3', '2020-01-24', '104', NULL, NULL, '0', 70, NULL),
(604, '1', '2019-12-11', '13.2', NULL, NULL, '8', 69, NULL),
(605, '2', '2019-12-12', '13.2', NULL, NULL, '7', 69, NULL),
(606, '3', '2019-12-13', '13.2', NULL, NULL, '6', 69, NULL),
(607, '4', '2019-12-14', '13.2', NULL, NULL, '5', 69, NULL),
(608, '5', '2019-12-16', '13.2', NULL, NULL, '3', 69, NULL),
(609, '6', '2019-12-17', '13.2', NULL, NULL, '2', 69, NULL),
(610, '7', '2019-12-18', '13.2', NULL, NULL, '1', 69, NULL),
(611, '8', '2019-12-19', '13.2', NULL, NULL, '0', 69, NULL),
(612, '9', '2019-12-20', '13.2', NULL, NULL, '0', 69, NULL),
(613, '10', '2019-12-21', '13.2', NULL, NULL, '0', 69, NULL),
(614, '11', '2019-12-23', '13.2', NULL, NULL, '0', 69, NULL),
(615, '12', '2019-12-26', '13.2', NULL, NULL, '0', 69, NULL),
(616, '13', '2019-12-27', '13.2', NULL, NULL, '0', 69, NULL),
(617, '14', '2019-12-28', '13.2', NULL, NULL, '0', 69, NULL),
(618, '15', '2019-12-30', '13.2', NULL, NULL, '0', 69, NULL),
(619, '16', '2019-12-31', '13.2', NULL, NULL, '0', 69, NULL),
(620, '17', '2020-01-01', '13.2', NULL, NULL, '0', 69, NULL),
(621, '18', '2020-01-02', '13.2', NULL, NULL, '0', 69, NULL),
(622, '19', '2020-01-03', '13.2', NULL, NULL, '0', 69, NULL),
(623, '20', '2020-01-04', '13.2', NULL, NULL, '0', 69, NULL),
(624, '21', '2020-01-06', '13.2', NULL, NULL, '0', 69, NULL),
(625, '22', '2020-01-07', '13.2', NULL, NULL, '0', 69, NULL),
(626, '23', '2020-01-08', '13.2', NULL, NULL, '0', 69, NULL),
(627, '24', '2020-01-09', '13.2', NULL, NULL, '0', 69, NULL),
(628, '25', '2020-01-10', '13.2', NULL, NULL, '0', 69, NULL),
(629, '1', '2019-12-17', '150', NULL, NULL, '2', 71, NULL),
(630, '2', '2019-12-26', '150', NULL, NULL, '0', 71, NULL),
(631, '3', '2020-01-02', '150', NULL, NULL, '0', 71, NULL),
(632, '4', '2020-01-09', '150', NULL, NULL, '0', 71, NULL),
(633, '5', '2020-01-16', '150', NULL, NULL, '0', 71, NULL),
(634, '6', '2020-01-23', '150', NULL, NULL, '0', 71, NULL),
(635, '7', '2020-01-30', '150', NULL, NULL, '0', 71, NULL),
(636, '8', '2020-02-06', '150', NULL, NULL, '0', 71, NULL),
(637, '1', '2019-12-13', '26.4', NULL, NULL, '6', 76, NULL),
(638, '2', '2019-12-14', '26.4', NULL, NULL, '5', 76, NULL),
(639, '3', '2019-12-16', '26.4', NULL, NULL, '3', 76, NULL),
(640, '4', '2019-12-17', '26.4', NULL, NULL, '2', 76, NULL),
(641, '5', '2019-12-18', '26.4', NULL, NULL, '1', 76, NULL),
(642, '6', '2019-12-19', '26.4', NULL, NULL, '0', 76, NULL),
(643, '7', '2019-12-20', '26.4', NULL, NULL, '0', 76, NULL),
(644, '8', '2019-12-21', '26.4', NULL, NULL, '0', 76, NULL),
(645, '9', '2019-12-23', '26.4', NULL, NULL, '0', 76, NULL),
(646, '10', '2019-12-26', '26.4', NULL, NULL, '0', 76, NULL),
(647, '11', '2019-12-27', '26.4', NULL, NULL, '0', 76, NULL),
(648, '12', '2019-12-28', '26.4', NULL, NULL, '0', 76, NULL),
(649, '13', '2019-12-30', '26.4', NULL, NULL, '0', 76, NULL),
(650, '14', '2019-12-31', '26.4', NULL, NULL, '0', 76, NULL),
(651, '15', '2020-01-01', '26.4', NULL, NULL, '0', 76, NULL),
(652, '16', '2020-01-02', '26.4', NULL, NULL, '0', 76, NULL),
(653, '17', '2020-01-03', '26.4', NULL, NULL, '0', 76, NULL),
(654, '18', '2020-01-04', '26.4', NULL, NULL, '0', 76, NULL),
(655, '19', '2020-01-06', '26.4', NULL, NULL, '0', 76, NULL),
(656, '20', '2020-01-07', '26.4', NULL, NULL, '0', 76, NULL),
(657, '21', '2020-01-08', '26.4', NULL, NULL, '0', 76, NULL),
(658, '22', '2020-01-09', '26.4', NULL, NULL, '0', 76, NULL),
(659, '23', '2020-01-10', '26.4', NULL, NULL, '0', 76, NULL),
(660, '24', '2020-01-11', '26.4', NULL, NULL, '0', 76, NULL),
(661, '25', '2020-01-13', '26.4', NULL, NULL, '0', 76, NULL),
(662, '1', '2019-12-12', '13.2', NULL, NULL, '7', 73, NULL),
(663, '2', '2019-12-13', '13.2', NULL, NULL, '6', 73, NULL),
(664, '3', '2019-12-14', '13.2', NULL, NULL, '5', 73, NULL),
(665, '4', '2019-12-16', '13.2', NULL, NULL, '3', 73, NULL),
(666, '5', '2019-12-17', '13.2', NULL, NULL, '2', 73, NULL),
(667, '6', '2019-12-18', '13.2', NULL, NULL, '1', 73, NULL),
(668, '7', '2019-12-19', '13.2', NULL, NULL, '0', 73, NULL),
(669, '8', '2019-12-20', '13.2', NULL, NULL, '0', 73, NULL),
(670, '9', '2019-12-21', '13.2', NULL, NULL, '0', 73, NULL),
(671, '10', '2019-12-23', '13.2', NULL, NULL, '0', 73, NULL),
(672, '11', '2019-12-26', '13.2', NULL, NULL, '0', 73, NULL),
(673, '12', '2019-12-27', '13.2', NULL, NULL, '0', 73, NULL),
(674, '13', '2019-12-28', '13.2', NULL, NULL, '0', 73, NULL),
(675, '14', '2019-12-30', '13.2', NULL, NULL, '0', 73, NULL),
(676, '15', '2019-12-31', '13.2', NULL, NULL, '0', 73, NULL),
(677, '16', '2020-01-01', '13.2', NULL, NULL, '0', 73, NULL),
(678, '17', '2020-01-02', '13.2', NULL, NULL, '0', 73, NULL),
(679, '18', '2020-01-03', '13.2', NULL, NULL, '0', 73, NULL),
(680, '19', '2020-01-04', '13.2', NULL, NULL, '0', 73, NULL),
(681, '20', '2020-01-06', '13.2', NULL, NULL, '0', 73, NULL),
(682, '21', '2020-01-07', '13.2', NULL, NULL, '0', 73, NULL),
(683, '22', '2020-01-08', '13.2', NULL, NULL, '0', 73, NULL),
(684, '23', '2020-01-09', '13.2', NULL, NULL, '0', 73, NULL),
(685, '24', '2020-01-10', '13.2', NULL, NULL, '0', 73, NULL),
(686, '25', '2020-01-11', '13.2', NULL, NULL, '0', 73, NULL),
(687, '1', '2019-12-12', '13.2', NULL, NULL, '7', 78, NULL),
(688, '2', '2019-12-13', '13.2', NULL, NULL, '6', 78, NULL),
(689, '3', '2019-12-14', '13.2', NULL, NULL, '5', 78, NULL),
(690, '4', '2019-12-16', '13.2', NULL, NULL, '3', 78, NULL),
(691, '5', '2019-12-17', '13.2', NULL, NULL, '2', 78, NULL),
(692, '6', '2019-12-18', '13.2', NULL, NULL, '1', 78, NULL),
(693, '7', '2019-12-19', '13.2', NULL, NULL, '0', 78, NULL),
(694, '8', '2019-12-20', '13.2', NULL, NULL, '0', 78, NULL),
(695, '9', '2019-12-21', '13.2', NULL, NULL, '0', 78, NULL),
(696, '10', '2019-12-23', '13.2', NULL, NULL, '0', 78, NULL),
(697, '11', '2019-12-26', '13.2', NULL, NULL, '0', 78, NULL),
(698, '12', '2019-12-27', '13.2', NULL, NULL, '0', 78, NULL),
(699, '13', '2019-12-28', '13.2', NULL, NULL, '0', 78, NULL),
(700, '14', '2019-12-30', '13.2', NULL, NULL, '0', 78, NULL),
(701, '15', '2019-12-31', '13.2', NULL, NULL, '0', 78, NULL),
(702, '16', '2020-01-01', '13.2', NULL, NULL, '0', 78, NULL),
(703, '17', '2020-01-02', '13.2', NULL, NULL, '0', 78, NULL),
(704, '18', '2020-01-03', '13.2', NULL, NULL, '0', 78, NULL),
(705, '19', '2020-01-04', '13.2', NULL, NULL, '0', 78, NULL),
(706, '20', '2020-01-06', '13.2', NULL, NULL, '0', 78, NULL),
(707, '21', '2020-01-07', '13.2', NULL, NULL, '0', 78, NULL),
(708, '22', '2020-01-08', '13.2', NULL, NULL, '0', 78, NULL),
(709, '23', '2020-01-09', '13.2', NULL, NULL, '0', 78, NULL),
(710, '24', '2020-01-10', '13.2', NULL, NULL, '0', 78, NULL),
(711, '25', '2020-01-11', '13.2', NULL, NULL, '0', 78, NULL),
(712, '1', '2019-12-19', '165', NULL, NULL, '0', 79, NULL),
(713, '2', '2019-12-28', '165', NULL, NULL, '0', 79, NULL),
(714, '3', '2020-01-04', '165', NULL, NULL, '0', 79, NULL),
(715, '4', '2020-01-11', '165', NULL, NULL, '0', 79, NULL),
(741, '1', '2019-12-12', '22', NULL, NULL, '7', 77, NULL),
(742, '2', '2019-12-13', '22', NULL, NULL, '6', 77, NULL),
(743, '3', '2019-12-14', '22', NULL, NULL, '5', 77, NULL),
(744, '4', '2019-12-16', '22', NULL, NULL, '3', 77, NULL),
(745, '5', '2019-12-17', '22', NULL, NULL, '2', 77, NULL),
(746, '6', '2019-12-18', '22', NULL, NULL, '1', 77, NULL),
(747, '7', '2019-12-19', '22', NULL, NULL, '0', 77, NULL),
(748, '8', '2019-12-20', '22', NULL, NULL, '0', 77, NULL),
(749, '9', '2019-12-21', '22', NULL, NULL, '0', 77, NULL),
(750, '10', '2019-12-23', '22', NULL, NULL, '0', 77, NULL),
(751, '11', '2019-12-26', '22', NULL, NULL, '0', 77, NULL),
(752, '12', '2019-12-27', '22', NULL, NULL, '0', 77, NULL),
(753, '13', '2019-12-28', '22', NULL, NULL, '0', 77, NULL),
(754, '14', '2019-12-30', '22', NULL, NULL, '0', 77, NULL),
(755, '15', '2019-12-31', '22', NULL, NULL, '0', 77, NULL),
(756, '16', '2020-01-01', '22', NULL, NULL, '0', 77, NULL),
(757, '17', '2020-01-02', '22', NULL, NULL, '0', 77, NULL),
(758, '18', '2020-01-03', '22', NULL, NULL, '0', 77, NULL),
(759, '19', '2020-01-04', '22', NULL, NULL, '0', 77, NULL),
(760, '20', '2020-01-06', '22', NULL, NULL, '0', 77, NULL),
(761, '21', '2020-01-07', '22', NULL, NULL, '0', 77, NULL),
(762, '22', '2020-01-08', '22', NULL, NULL, '0', 77, NULL),
(763, '23', '2020-01-09', '22', NULL, NULL, '0', 77, NULL),
(764, '24', '2020-01-10', '22', NULL, NULL, '0', 77, NULL),
(765, '25', '2020-01-11', '22', NULL, NULL, '0', 77, NULL),
(766, '1', '2020-01-19', '550', NULL, NULL, '0', 81, NULL),
(767, '1', '2019-12-20', '110', NULL, NULL, '0', 85, NULL),
(768, '2', '2019-12-29', '110', NULL, NULL, '0', 85, NULL),
(769, '3', '2020-01-05', '110', NULL, NULL, '0', 85, NULL),
(770, '4', '2020-01-12', '110', NULL, NULL, '0', 85, NULL),
(771, '1', '2019-12-14', '13.2', NULL, NULL, '5', 82, NULL),
(772, '2', '2019-12-16', '13.2', NULL, NULL, '3', 82, NULL),
(773, '3', '2019-12-17', '13.2', NULL, NULL, '2', 82, NULL),
(774, '4', '2019-12-18', '13.2', NULL, NULL, '1', 82, NULL),
(775, '5', '2019-12-19', '13.2', NULL, NULL, '0', 82, NULL),
(776, '6', '2019-12-20', '13.2', NULL, NULL, '0', 82, NULL),
(777, '7', '2019-12-21', '13.2', NULL, NULL, '0', 82, NULL),
(778, '8', '2019-12-23', '13.2', NULL, NULL, '0', 82, NULL),
(779, '9', '2019-12-26', '13.2', NULL, NULL, '0', 82, NULL),
(780, '10', '2019-12-27', '13.2', NULL, NULL, '0', 82, NULL),
(781, '11', '2019-12-28', '13.2', NULL, NULL, '0', 82, NULL),
(782, '12', '2019-12-30', '13.2', NULL, NULL, '0', 82, NULL),
(783, '13', '2019-12-31', '13.2', NULL, NULL, '0', 82, NULL),
(784, '14', '2020-01-01', '13.2', NULL, NULL, '0', 82, NULL),
(785, '15', '2020-01-02', '13.2', NULL, NULL, '0', 82, NULL),
(786, '16', '2020-01-03', '13.2', NULL, NULL, '0', 82, NULL),
(787, '17', '2020-01-04', '13.2', NULL, NULL, '0', 82, NULL),
(788, '18', '2020-01-06', '13.2', NULL, NULL, '0', 82, NULL),
(789, '19', '2020-01-07', '13.2', NULL, NULL, '0', 82, NULL),
(790, '20', '2020-01-08', '13.2', NULL, NULL, '0', 82, NULL),
(791, '21', '2020-01-09', '13.2', NULL, NULL, '0', 82, NULL),
(792, '22', '2020-01-10', '13.2', NULL, NULL, '0', 82, NULL),
(793, '23', '2020-01-11', '13.2', NULL, NULL, '0', 82, NULL),
(794, '24', '2020-01-13', '13.2', NULL, NULL, '0', 82, NULL),
(795, '25', '2020-01-14', '13.2', NULL, NULL, '0', 82, NULL),
(796, '1', '2019-12-16', '36', NULL, NULL, '3', 84, NULL),
(797, '2', '2019-12-17', '36', NULL, NULL, '2', 84, NULL),
(798, '3', '2019-12-18', '36', NULL, NULL, '1', 84, NULL),
(799, '4', '2019-12-19', '36', NULL, NULL, '0', 84, NULL),
(800, '5', '2019-12-20', '36', NULL, NULL, '0', 84, NULL),
(801, '6', '2019-12-21', '36', NULL, NULL, '0', 84, NULL),
(802, '7', '2019-12-23', '36', NULL, NULL, '0', 84, NULL),
(803, '8', '2019-12-26', '36', NULL, NULL, '0', 84, NULL),
(804, '9', '2019-12-27', '36', NULL, NULL, '0', 84, NULL),
(805, '10', '2019-12-28', '36', NULL, NULL, '0', 84, NULL),
(806, '11', '2019-12-30', '36', NULL, NULL, '0', 84, NULL),
(807, '12', '2019-12-31', '36', NULL, NULL, '0', 84, NULL),
(808, '13', '2020-01-01', '36', NULL, NULL, '0', 84, NULL),
(809, '14', '2020-01-02', '36', NULL, NULL, '0', 84, NULL),
(810, '15', '2020-01-03', '36', NULL, NULL, '0', 84, NULL),
(811, '16', '2020-01-04', '36', NULL, NULL, '0', 84, NULL),
(812, '17', '2020-01-06', '36', NULL, NULL, '0', 84, NULL),
(813, '18', '2020-01-07', '36', NULL, NULL, '0', 84, NULL),
(814, '19', '2020-01-08', '36', NULL, NULL, '0', 84, NULL),
(815, '20', '2020-01-09', '36', NULL, NULL, '0', 84, NULL),
(816, '21', '2020-01-10', '36', NULL, NULL, '0', 84, NULL),
(817, '22', '2020-01-11', '36', NULL, NULL, '0', 84, NULL),
(818, '23', '2020-01-13', '36', NULL, NULL, '0', 84, NULL),
(819, '24', '2020-01-14', '36', NULL, NULL, '0', 84, NULL),
(820, '25', '2020-01-15', '36', NULL, NULL, '0', 84, NULL),
(821, '26', '2020-01-16', '36', NULL, NULL, '0', 84, NULL),
(822, '27', '2020-01-17', '36', NULL, NULL, '0', 84, NULL),
(823, '28', '2020-01-18', '36', NULL, NULL, '0', 84, NULL),
(824, '29', '2020-01-20', '36', NULL, NULL, '0', 84, NULL),
(825, '30', '2020-01-21', '36', NULL, NULL, '0', 84, NULL),
(826, '31', '2020-01-22', '36', NULL, NULL, '0', 84, NULL),
(827, '32', '2020-01-23', '36', NULL, NULL, '0', 84, NULL),
(828, '33', '2020-01-24', '36', NULL, NULL, '0', 84, NULL),
(829, '34', '2020-01-25', '36', NULL, NULL, '0', 84, NULL),
(830, '35', '2020-01-27', '36', NULL, NULL, '0', 84, NULL),
(831, '36', '2020-01-28', '36', NULL, NULL, '0', 84, NULL),
(832, '37', '2020-01-29', '36', NULL, NULL, '0', 84, NULL),
(833, '38', '2020-01-30', '36', NULL, NULL, '0', 84, NULL),
(834, '39', '2020-01-31', '36', NULL, NULL, '0', 84, NULL),
(835, '40', '2020-02-01', '36', NULL, NULL, '0', 84, NULL),
(836, '41', '2020-02-03', '36', NULL, NULL, '0', 84, NULL),
(837, '42', '2020-02-04', '36', NULL, NULL, '0', 84, NULL),
(838, '43', '2020-02-05', '36', NULL, NULL, '0', 84, NULL),
(839, '44', '2020-02-06', '36', NULL, NULL, '0', 84, NULL),
(840, '45', '2020-02-07', '36', NULL, NULL, '0', 84, NULL),
(841, '46', '2020-02-08', '36', NULL, NULL, '0', 84, NULL),
(842, '47', '2020-02-10', '36', NULL, NULL, '0', 84, NULL),
(843, '48', '2020-02-11', '36', NULL, NULL, '0', 84, NULL),
(844, '49', '2020-02-12', '36', NULL, NULL, '0', 84, NULL),
(845, '50', '2020-02-13', '36', NULL, NULL, '0', 84, NULL),
(846, '1', '2019-12-24', '137.5', NULL, NULL, '0', 88, NULL),
(847, '2', '2020-01-01', '137.5', NULL, NULL, '0', 88, NULL),
(848, '3', '2020-01-08', '137.5', NULL, NULL, '0', 88, NULL),
(849, '4', '2020-01-15', '137.5', NULL, NULL, '0', 88, NULL),
(900, '1', '2019-12-19', '17.6', NULL, NULL, '0', 92, NULL),
(901, '2', '2019-12-20', '17.6', NULL, NULL, '0', 92, NULL),
(902, '3', '2019-12-21', '17.6', NULL, NULL, '0', 92, NULL),
(903, '4', '2019-12-23', '17.6', NULL, NULL, '0', 92, NULL),
(904, '5', '2019-12-26', '17.6', NULL, NULL, '0', 92, NULL),
(905, '6', '2019-12-27', '17.6', NULL, NULL, '0', 92, NULL),
(906, '7', '2019-12-28', '17.6', NULL, NULL, '0', 92, NULL),
(907, '8', '2019-12-30', '17.6', NULL, NULL, '0', 92, NULL),
(908, '9', '2019-12-31', '17.6', NULL, NULL, '0', 92, NULL),
(909, '10', '2020-01-01', '17.6', NULL, NULL, '0', 92, NULL),
(910, '11', '2020-01-02', '17.6', NULL, NULL, '0', 92, NULL),
(911, '12', '2020-01-03', '17.6', NULL, NULL, '0', 92, NULL),
(912, '13', '2020-01-04', '17.6', NULL, NULL, '0', 92, NULL),
(913, '14', '2020-01-06', '17.6', NULL, NULL, '0', 92, NULL),
(914, '15', '2020-01-07', '17.6', NULL, NULL, '0', 92, NULL),
(915, '16', '2020-01-08', '17.6', NULL, NULL, '0', 92, NULL),
(916, '17', '2020-01-09', '17.6', NULL, NULL, '0', 92, NULL),
(917, '18', '2020-01-10', '17.6', NULL, NULL, '0', 92, NULL),
(918, '19', '2020-01-11', '17.6', NULL, NULL, '0', 92, NULL),
(919, '20', '2020-01-13', '17.6', NULL, NULL, '0', 92, NULL),
(920, '21', '2020-01-14', '17.6', NULL, NULL, '0', 92, NULL),
(921, '22', '2020-01-15', '17.6', NULL, NULL, '0', 92, NULL),
(922, '23', '2020-01-16', '17.6', NULL, NULL, '0', 92, NULL),
(923, '24', '2020-01-17', '17.6', NULL, NULL, '0', 92, NULL),
(924, '25', '2020-01-18', '17.6', NULL, NULL, '0', 92, NULL),
(925, '1', '2019-12-19', '13.2', NULL, NULL, '0', 90, NULL),
(926, '2', '2019-12-20', '13.2', NULL, NULL, '0', 90, NULL),
(927, '3', '2019-12-21', '13.2', NULL, NULL, '0', 90, NULL),
(928, '4', '2019-12-23', '13.2', NULL, NULL, '0', 90, NULL),
(929, '5', '2019-12-26', '13.2', NULL, NULL, '0', 90, NULL),
(930, '6', '2019-12-27', '13.2', NULL, NULL, '0', 90, NULL),
(931, '7', '2019-12-28', '13.2', NULL, NULL, '0', 90, NULL),
(932, '8', '2019-12-30', '13.2', NULL, NULL, '0', 90, NULL),
(933, '9', '2019-12-31', '13.2', NULL, NULL, '0', 90, NULL),
(934, '10', '2020-01-01', '13.2', NULL, NULL, '0', 90, NULL),
(935, '11', '2020-01-02', '13.2', NULL, NULL, '0', 90, NULL),
(936, '12', '2020-01-03', '13.2', NULL, NULL, '0', 90, NULL),
(937, '13', '2020-01-04', '13.2', NULL, NULL, '0', 90, NULL),
(938, '14', '2020-01-06', '13.2', NULL, NULL, '0', 90, NULL),
(939, '15', '2020-01-07', '13.2', NULL, NULL, '0', 90, NULL),
(940, '16', '2020-01-08', '13.2', NULL, NULL, '0', 90, NULL),
(941, '17', '2020-01-09', '13.2', NULL, NULL, '0', 90, NULL),
(942, '18', '2020-01-10', '13.2', NULL, NULL, '0', 90, NULL),
(943, '19', '2020-01-11', '13.2', NULL, NULL, '0', 90, NULL),
(944, '20', '2020-01-13', '13.2', NULL, NULL, '0', 90, NULL),
(945, '21', '2020-01-14', '13.2', NULL, NULL, '0', 90, NULL),
(946, '22', '2020-01-15', '13.2', NULL, NULL, '0', 90, NULL),
(947, '23', '2020-01-16', '13.2', NULL, NULL, '0', 90, NULL),
(948, '24', '2020-01-17', '13.2', NULL, NULL, '0', 90, NULL),
(949, '25', '2020-01-18', '13.2', NULL, NULL, '0', 90, NULL),
(950, '1', '2019-12-26', '137.5', NULL, NULL, '0', 89, NULL),
(951, '2', '2020-01-02', '137.5', NULL, NULL, '0', 89, NULL),
(952, '3', '2020-01-09', '137.5', NULL, NULL, '0', 89, NULL),
(953, '4', '2020-01-16', '137.5', NULL, NULL, '0', 89, NULL),
(954, '1', '2019-12-26', '41.3', NULL, NULL, '0', 93, NULL),
(955, '2', '2020-01-02', '41.3', NULL, NULL, '0', 93, NULL),
(956, '3', '2020-01-09', '41.3', NULL, NULL, '0', 93, NULL),
(957, '4', '2020-01-16', '41.3', NULL, NULL, '0', 93, NULL),
(958, '1', '2019-12-26', '82.5', NULL, NULL, '0', 95, NULL),
(959, '2', '2020-01-02', '82.5', NULL, NULL, '0', 95, NULL),
(960, '3', '2020-01-09', '82.5', NULL, NULL, '0', 95, NULL),
(961, '4', '2020-01-16', '82.5', NULL, NULL, '0', 95, NULL),
(962, '1', '2019-12-20', '13.2', NULL, NULL, '0', 91, NULL),
(963, '2', '2019-12-21', '13.2', NULL, NULL, '0', 91, NULL),
(964, '3', '2019-12-23', '13.2', NULL, NULL, '0', 91, NULL),
(965, '4', '2019-12-26', '13.2', NULL, NULL, '0', 91, NULL),
(966, '5', '2019-12-27', '13.2', NULL, NULL, '0', 91, NULL),
(967, '6', '2019-12-28', '13.2', NULL, NULL, '0', 91, NULL),
(968, '7', '2019-12-30', '13.2', NULL, NULL, '0', 91, NULL),
(969, '8', '2019-12-31', '13.2', NULL, NULL, '0', 91, NULL),
(970, '9', '2020-01-01', '13.2', NULL, NULL, '0', 91, NULL),
(971, '10', '2020-01-02', '13.2', NULL, NULL, '0', 91, NULL),
(972, '11', '2020-01-03', '13.2', NULL, NULL, '0', 91, NULL),
(973, '12', '2020-01-04', '13.2', NULL, NULL, '0', 91, NULL),
(974, '13', '2020-01-06', '13.2', NULL, NULL, '0', 91, NULL),
(975, '14', '2020-01-07', '13.2', NULL, NULL, '0', 91, NULL),
(976, '15', '2020-01-08', '13.2', NULL, NULL, '0', 91, NULL),
(977, '16', '2020-01-09', '13.2', NULL, NULL, '0', 91, NULL),
(978, '17', '2020-01-10', '13.2', NULL, NULL, '0', 91, NULL),
(979, '18', '2020-01-11', '13.2', NULL, NULL, '0', 91, NULL),
(980, '19', '2020-01-13', '13.2', NULL, NULL, '0', 91, NULL),
(981, '20', '2020-01-14', '13.2', NULL, NULL, '0', 91, NULL),
(982, '21', '2020-01-15', '13.2', NULL, NULL, '0', 91, NULL),
(983, '22', '2020-01-16', '13.2', NULL, NULL, '0', 91, NULL),
(984, '23', '2020-01-17', '13.2', NULL, NULL, '0', 91, NULL),
(985, '24', '2020-01-18', '13.2', NULL, NULL, '0', 91, NULL),
(986, '25', '2020-01-20', '13.2', NULL, NULL, '0', 91, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `idsolicitud` int(11) NOT NULL,
  `fecha_reg` datetime NOT NULL,
  `fecha_mod` datetime DEFAULT NULL,
  `fecha_pre` datetime DEFAULT NULL,
  `creditos_idcredito` int(11) NOT NULL,
  `usuarios_idusuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`idsolicitud`, `fecha_reg`, `fecha_mod`, `fecha_pre`, `creditos_idcredito`, `usuarios_idusuario`) VALUES
(6, '2019-11-25 10:15:22', NULL, '2019-11-25 10:15:30', 6, 8),
(7, '2019-11-25 10:16:16', NULL, '2019-11-25 10:16:20', 7, 8),
(8, '2019-11-25 10:46:54', NULL, '2019-11-25 10:47:12', 8, 6),
(20, '2019-11-25 19:22:08', NULL, NULL, 16, 6),
(21, '2019-11-25 19:22:15', NULL, NULL, 16, 6),
(22, '2019-11-25 19:22:21', NULL, NULL, 16, 6),
(23, '2019-11-25 19:22:23', NULL, NULL, 16, 6),
(24, '2019-11-25 19:22:24', NULL, NULL, 16, 6),
(25, '2019-11-25 19:22:24', NULL, NULL, 16, 6),
(27, '2019-11-25 19:22:38', NULL, NULL, 16, 6),
(28, '2019-11-25 19:24:40', NULL, NULL, 16, 6),
(29, '2019-11-25 19:24:45', NULL, NULL, 16, 6),
(30, '2019-11-25 19:31:38', NULL, NULL, 16, 6),
(31, '2019-11-25 19:57:12', NULL, '2019-11-25 19:57:25', 31, 6),
(32, '2019-11-26 09:10:28', NULL, NULL, 31, 6),
(33, '2019-11-26 09:15:44', NULL, NULL, 31, 6),
(35, '2019-11-26 09:23:01', NULL, '2019-11-27 09:41:41', 35, 6),
(36, '2019-11-26 09:25:58', NULL, '2019-11-27 09:29:55', 36, 4),
(39, '2019-11-26 15:20:11', NULL, '2019-11-26 15:25:04', 39, 8),
(40, '2019-11-27 19:07:17', NULL, '2019-11-27 19:07:24', 40, 6),
(43, '2019-11-28 10:10:13', NULL, '2019-11-30 09:33:12', 43, 4),
(44, '2019-11-28 17:51:44', NULL, '2019-11-28 17:51:52', 44, 4),
(45, '2019-11-28 18:19:24', NULL, '2019-11-28 18:19:39', 45, 4),
(46, '2019-11-28 18:21:59', NULL, '2019-11-28 18:28:32', 46, 4),
(47, '2019-11-29 09:20:49', NULL, '2019-11-29 09:21:00', 47, 6),
(48, '2019-11-29 09:32:15', NULL, '2019-11-29 09:54:06', 48, 6),
(50, '2019-11-29 11:30:53', NULL, '2019-11-29 11:31:05', 50, 4),
(51, '2019-11-29 11:31:36', NULL, '2019-11-29 11:31:54', 51, 4),
(52, '2019-11-29 15:17:26', NULL, '2019-11-29 15:17:42', 52, 4),
(53, '2019-11-29 15:18:57', NULL, '2019-11-29 15:19:04', 53, 4),
(54, '2019-11-29 19:08:12', NULL, '2019-11-29 19:08:24', 54, 4),
(55, '2019-12-02 09:23:06', NULL, '2019-12-04 17:27:02', 55, 6),
(57, '2019-12-03 09:40:32', NULL, '2019-12-03 09:40:45', 57, 4),
(58, '2019-12-04 11:49:44', NULL, '2019-12-04 11:49:57', 58, 4),
(59, '2019-12-04 17:08:50', NULL, NULL, 58, 8),
(60, '2019-12-04 17:11:42', NULL, '2019-12-09 18:31:22', 60, 8),
(61, '2019-12-04 17:58:51', NULL, '2019-12-04 17:58:59', 61, 4),
(62, '2019-12-05 09:22:36', NULL, '2019-12-05 09:24:01', 62, 4),
(64, '2019-12-05 17:11:40', NULL, '2019-12-05 17:11:51', 64, 6),
(65, '2019-12-06 09:27:31', NULL, '2019-12-09 09:06:53', 65, 6),
(66, '2019-12-07 09:30:37', NULL, '2019-12-07 09:30:44', 66, 6),
(69, '2019-12-09 18:58:37', NULL, '2019-12-09 18:58:44', 69, 6),
(70, '2019-12-09 19:17:43', NULL, '2019-12-09 19:17:50', 70, 4),
(71, '2019-12-10 09:40:49', NULL, '2019-12-10 09:40:55', 71, 4),
(72, '2019-12-10 18:11:44', NULL, '2019-12-10 18:12:12', 72, 8),
(73, '2019-12-10 18:14:08', NULL, '2019-12-11 17:52:08', 73, 6),
(76, '2019-12-11 09:54:12', NULL, '2019-12-11 09:54:27', 76, 4),
(77, '2019-12-11 15:10:28', NULL, '2019-12-12 17:30:29', 77, 6),
(78, '2019-12-11 15:44:02', NULL, '2019-12-11 15:44:13', 78, 6),
(79, '2019-12-12 15:08:45', NULL, '2019-12-12 15:08:51', 79, 4),
(80, '2019-12-12 19:03:45', NULL, NULL, 80, 8),
(81, '2019-12-13 10:00:38', NULL, '2019-12-13 10:00:43', 81, 4),
(82, '2019-12-13 10:21:45', NULL, '2019-12-13 10:21:54', 82, 6),
(83, '2019-12-13 15:22:47', NULL, '2019-12-13 15:22:56', 83, 6),
(84, '2019-12-13 15:27:21', NULL, '2019-12-14 13:02:09', 84, 6),
(85, '2019-12-13 16:08:12', NULL, '2019-12-13 16:09:32', 85, 8),
(86, '2019-12-16 15:29:22', NULL, '2019-12-16 15:29:28', 86, 6),
(88, '2019-12-17 12:04:23', NULL, '2019-12-17 12:04:29', 88, 4),
(89, '2019-12-17 18:52:56', NULL, '2019-12-18 15:07:37', 89, 6),
(90, '2019-12-17 18:53:49', NULL, '2019-12-18 15:07:54', 90, 6),
(91, '2019-12-18 09:15:05', NULL, '2019-12-19 10:16:24', 91, 6),
(92, '2019-12-18 15:05:34', NULL, '2019-12-18 15:28:44', 92, 4),
(93, '2019-12-18 18:08:48', NULL, '2019-12-18 18:08:58', 93, 8),
(94, '2019-12-18 18:32:27', NULL, '2019-12-18 18:32:39', 94, 6),
(95, '2019-12-19 09:41:38', NULL, '2019-12-19 09:59:38', 95, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transferencias`
--

CREATE TABLE `transferencias` (
  `idtransferencia` int(11) NOT NULL,
  `tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `monto` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `concepto` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_mov` datetime NOT NULL,
  `autoriza` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `detalle` text COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuarios_idusuario` int(11) NOT NULL,
  `cajas_idcaja` int(11) NOT NULL,
  `cajas_idcaja1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `transferencias`
--

INSERT INTO `transferencias` (`idtransferencia`, `tipo`, `monto`, `concepto`, `fecha_mov`, `autoriza`, `detalle`, `usuarios_idusuario`, `cajas_idcaja`, `cajas_idcaja1`) VALUES
(7, 'TRANSFERENCIA', '225.6', 'Habilitación de efectivo', '2019-12-06 15:00:11', 'administrador', NULL, 7, 2, 8),
(8, 'TRANSFERENCIA', '526.6', 'Habilitación de efectivo', '2019-12-06 15:00:30', 'administrador', NULL, 7, 5, 8),
(9, 'TRANSFERENCIA', '1396.2', 'PARA DESEMBOLSOS', '2019-12-09 09:49:36', 'JACKELINE ESTRADA', NULL, 2, 8, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL,
  `privilegios` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_pat` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `doc_nro` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `pass` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nacimiento` date DEFAULT NULL,
  `grado` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado_civil` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `lugar_nacimiento` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `comentarios` text COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `referencia` varchar(55) COLLATE utf8_spanish_ci DEFAULT NULL,
  `distrito` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `provincia` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(55) COLLATE utf8_spanish_ci DEFAULT NULL,
  `url_foto` varchar(55) COLLATE utf8_spanish_ci DEFAULT NULL,
  `habilitado` varchar(5) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `privilegios`, `apellido_pat`, `apellido_mat`, `nombre`, `doc_nro`, `usuario`, `pass`, `nacimiento`, `grado`, `estado_civil`, `lugar_nacimiento`, `comentarios`, `telefono`, `direccion`, `referencia`, `distrito`, `provincia`, `correo`, `url_foto`, `habilitado`) VALUES
(1, 'ROOT', 'LOARDO', 'NUÑEZ', 'ORLANDO', '20115680', 'root', 'admin', '2019-11-02', 'UNIVERSITARIA', 'SOLTERO', 'OTROS', '-', '-', '-', '-', '-', '-', 'root@gmail.com', NULL, 'SI'),
(2, 'ADMINISTRADOR', 'ESTRADA', 'ROJAS', 'JACKELINE IVONNE', '73222381', 'JESTRADA@ADMINISTRADOR', '73222381JIAER*', '1994-05-15', 'BACHILLER', 'SOLTERO', 'TARMA', '', '923321711', 'AV. RAMON CASTILLA N°306', '', 'CONCEPCION', 'CONCEPCION', 'admin@gmail.com', NULL, 'SI'),
(3, 'CAJA', 'GRANDOS', 'FERNANDEZ', 'LUIS ALFREDO', '74892786', 'LGRANADOS@CAJA', '74892786', '1997-07-19', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', '', '986570509', 'JR. YAUYOS N° 259', '', 'EL TAMBO', 'HUANCAYO', 'CAJA@gmail.com', NULL, 'SI'),
(4, 'ASESOR', 'HINOSTROZA', 'RODRIGUEZ', 'ELIANA LIZ', '47174763', 'EHINOSTROZA@ASESOR', '47174763', '1992-01-12', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', '', '933341599', 'AV. MARISCAL CASTILLA N° 1051', '', 'EL TAMBO', 'HUANCAYO', 'ASESOR@gmail.com', NULL, 'SI'),
(6, 'ASESOR', 'GOMEZ', 'MORENO', 'KEVIN STEVE', '77269413', 'KGOMEZ@ASESOR', '77269413', '1995-12-02', 'UNIVERSITARIA', 'SOLTERO', 'HUANCAYO', '', '914894331', 'JR. B LEGUIA N° 630', '', 'CHILCA', 'HUANCAYO', 'ASESOR@gmail.com', NULL, 'SI'),
(7, 'CAJA', 'ESTRADA', 'ROJAS', 'JACKELINE IVONNE', '73222381', 'JESTRADA@CAJA', '73222381JIAER*', '1994-05-15', 'BACHILLER', 'SOLTERO', 'HUANCAYO', '', '923321711', 'AV. RAMON CASTILLA N° 306', 'CONCEPCION', 'CONCEPCION', 'CONCEPCION', '', NULL, 'SI'),
(8, 'ASESOR', 'GRANADOS', 'FERNANDEZ', 'LUIS', '74892786', 'LGRANADOS@ASESOR', '74892786', '0000-00-00', 'SUPERIOR', 'SOLTERO', 'HUANCAYO', '', '916570509', 'JR. PARRA DE RIEGO N°581', '', 'EL TAMBO', 'HUANCAYO', '', NULL, 'SI');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `aperturas`
--
ALTER TABLE `aperturas`
  ADD PRIMARY KEY (`idapertura`),
  ADD KEY `fk_aperturas_cajas1_idx` (`cajas_idcaja`),
  ADD KEY `fk_aperturas_usuarios1_idx` (`usuarios_idusuario`);

--
-- Indices de la tabla `aprobaciones`
--
ALTER TABLE `aprobaciones`
  ADD PRIMARY KEY (`idaprobacion`),
  ADD KEY `fk_aprobaciones_creditos1_idx` (`creditos_idcredito`),
  ADD KEY `fk_aprobaciones_usuarios1_idx` (`usuarios_idusuario`);

--
-- Indices de la tabla `aval`
--
ALTER TABLE `aval`
  ADD PRIMARY KEY (`idconyugue`),
  ADD KEY `fk_aval_clientes1_idx` (`clientes_idcliente`);

--
-- Indices de la tabla `billetaje`
--
ALTER TABLE `billetaje`
  ADD PRIMARY KEY (`idbilletaje`);

--
-- Indices de la tabla `cajas`
--
ALTER TABLE `cajas`
  ADD PRIMARY KEY (`idcaja`),
  ADD KEY `fk_cajas_usuarios1_idx` (`usuarios_idusuario`),
  ADD KEY `fk_cajas_billetaje1_idx` (`billetaje_idbilletaje`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`idcliente`);

--
-- Indices de la tabla `consumo`
--
ALTER TABLE `consumo`
  ADD PRIMARY KEY (`idconsumo`),
  ADD KEY `fk_consumo_clientes1_idx` (`clientes_idcliente`);

--
-- Indices de la tabla `conyugue`
--
ALTER TABLE `conyugue`
  ADD PRIMARY KEY (`idconyugue`),
  ADD KEY `fk_conyugue_clientes1_idx` (`clientes_idcliente`);

--
-- Indices de la tabla `creditos`
--
ALTER TABLE `creditos`
  ADD PRIMARY KEY (`idcredito`),
  ADD KEY `fk_creditos_clientes1_idx` (`clientes_idcliente`);

--
-- Indices de la tabla `desembolso`
--
ALTER TABLE `desembolso`
  ADD PRIMARY KEY (`iddesembolso`),
  ADD KEY `fk_desembolso_creditos1_idx` (`creditos_idcredito`),
  ADD KEY `fk_desembolso_usuarios1_idx` (`usuarios_idusuario`);

--
-- Indices de la tabla `movimientos`
--
ALTER TABLE `movimientos`
  ADD PRIMARY KEY (`idmovimiento`),
  ADD KEY `fk_movimientos_cajas1_idx` (`cajas_idcaja`),
  ADD KEY `fk_movimientos_usuarios1_idx` (`usuarios_idusuario`);

--
-- Indices de la tabla `negocio`
--
ALTER TABLE `negocio`
  ADD PRIMARY KEY (`idnegocio`),
  ADD KEY `fk_negocio_clientes1_idx` (`clientes_idcliente`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`idpago`),
  ADD KEY `fk_pagos_creditos1_idx` (`creditos_idcredito`),
  ADD KEY `fk_pagos_usuarios1_idx` (`usuarios_idusuario`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`idsolicitud`),
  ADD KEY `fk_solicitudes_creditos1_idx` (`creditos_idcredito`),
  ADD KEY `fk_solicitudes_usuarios1_idx` (`usuarios_idusuario`);

--
-- Indices de la tabla `transferencias`
--
ALTER TABLE `transferencias`
  ADD PRIMARY KEY (`idtransferencia`),
  ADD KEY `fk_transferencias_usuarios1_idx` (`usuarios_idusuario`),
  ADD KEY `fk_transferencias_cajas1_idx` (`cajas_idcaja`),
  ADD KEY `fk_transferencias_cajas2_idx` (`cajas_idcaja1`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `aperturas`
--
ALTER TABLE `aperturas`
  MODIFY `idapertura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `aprobaciones`
--
ALTER TABLE `aprobaciones`
  MODIFY `idaprobacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT de la tabla `aval`
--
ALTER TABLE `aval`
  MODIFY `idconyugue` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `billetaje`
--
ALTER TABLE `billetaje`
  MODIFY `idbilletaje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `cajas`
--
ALTER TABLE `cajas`
  MODIFY `idcaja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `idcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT de la tabla `consumo`
--
ALTER TABLE `consumo`
  MODIFY `idconsumo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `conyugue`
--
ALTER TABLE `conyugue`
  MODIFY `idconyugue` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `creditos`
--
ALTER TABLE `creditos`
  MODIFY `idcredito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT de la tabla `desembolso`
--
ALTER TABLE `desembolso`
  MODIFY `iddesembolso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT de la tabla `movimientos`
--
ALTER TABLE `movimientos`
  MODIFY `idmovimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT de la tabla `negocio`
--
ALTER TABLE `negocio`
  MODIFY `idnegocio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `idpago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=987;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `idsolicitud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT de la tabla `transferencias`
--
ALTER TABLE `transferencias`
  MODIFY `idtransferencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `aperturas`
--
ALTER TABLE `aperturas`
  ADD CONSTRAINT `fk_aperturas_cajas1` FOREIGN KEY (`cajas_idcaja`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_aperturas_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `aprobaciones`
--
ALTER TABLE `aprobaciones`
  ADD CONSTRAINT `fk_aprobaciones_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_aprobaciones_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `aval`
--
ALTER TABLE `aval`
  ADD CONSTRAINT `fk_aval_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cajas`
--
ALTER TABLE `cajas`
  ADD CONSTRAINT `fk_cajas_billetaje1` FOREIGN KEY (`billetaje_idbilletaje`) REFERENCES `billetaje` (`idbilletaje`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cajas_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `consumo`
--
ALTER TABLE `consumo`
  ADD CONSTRAINT `fk_consumo_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `conyugue`
--
ALTER TABLE `conyugue`
  ADD CONSTRAINT `fk_conyugue_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `creditos`
--
ALTER TABLE `creditos`
  ADD CONSTRAINT `fk_creditos_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `desembolso`
--
ALTER TABLE `desembolso`
  ADD CONSTRAINT `fk_desembolso_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_desembolso_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `movimientos`
--
ALTER TABLE `movimientos`
  ADD CONSTRAINT `fk_movimientos_cajas1` FOREIGN KEY (`cajas_idcaja`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_movimientos_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `negocio`
--
ALTER TABLE `negocio`
  ADD CONSTRAINT `fk_negocio_clientes1` FOREIGN KEY (`clientes_idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `fk_pagos_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pagos_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD CONSTRAINT `fk_solicitudes_creditos1` FOREIGN KEY (`creditos_idcredito`) REFERENCES `creditos` (`idcredito`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_solicitudes_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `transferencias`
--
ALTER TABLE `transferencias`
  ADD CONSTRAINT `fk_transferencias_cajas1` FOREIGN KEY (`cajas_idcaja`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_transferencias_cajas2` FOREIGN KEY (`cajas_idcaja1`) REFERENCES `cajas` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_transferencias_usuarios1` FOREIGN KEY (`usuarios_idusuario`) REFERENCES `usuarios` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
